//////////////////////////////////////////////////////////////////////////////
/// @file main_test.cpp
/// @author Benjamin Hampe <benjamin.hampe@gmx.de>
//////////////////////////////////////////////////////////////////////////////

#include <iostream>

#include <jpeg/jpeglib.h>

int main( int argc, char** argv )
{  
   std::cout << "[Test] #include <jpeg/jpeglib.h>" << std::endl;

   return 0;
}
