/// @file main_test.cpp
/// @author Benjamin Hampe <benjamin.hampe@gmx.de>

#include <iostream>

#include <png/png.h>

int main( int argc, char** argv )
{  
   std::cout << "[Test] #include <png/png.h>" << std::endl;

   return 0;
}
