// HC3.h
#pragma once

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC3

#define HASH_ARRAY_2

#include "HC.h"
#include "HCMain.h"

#undef HASH_ARRAY_2

