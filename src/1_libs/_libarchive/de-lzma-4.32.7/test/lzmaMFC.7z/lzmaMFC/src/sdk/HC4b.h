// HC4b.h
#pragma once

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC4b

#define HASH_ARRAY_2
#define HASH_ARRAY_3
#define HASH_BIG

#include "HC.h"
#include "HCMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3
#undef HASH_BIG

