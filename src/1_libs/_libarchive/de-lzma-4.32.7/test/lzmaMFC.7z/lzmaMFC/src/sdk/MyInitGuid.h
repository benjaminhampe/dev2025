// Common/MyInitGuid.h
#pragma once

#ifdef _WIN32
#include <initguid.h>
#else
#define INITGUID
#include "MyGuidDef.h"
#endif
