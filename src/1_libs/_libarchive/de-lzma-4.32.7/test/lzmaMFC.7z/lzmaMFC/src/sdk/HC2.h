// HC2.h
#pragma once

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC2

#include "HCMF.h"
#include "HCMFMain.h"

