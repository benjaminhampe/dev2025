﻿#include "Window_wx.hpp"
#include "App_wx.hpp"

IMPLEMENT_APP(App);
