#include "Window_wx.hpp"

IMPLEMENT_APP(App);
