﻿#ifndef DE_WX_IMAGE_CTRL_HPP
#define DE_WX_IMAGE_CTRL_HPP

#include <wx/wx.h>
#include <wx/dcbuffer.h>

#include <DarkImage.hpp>
#include <de_fontawesome.hpp>

// #include <wx/combobox.h>
// #include <wx/dialog.h>
// #include <wx/filectrl.h>
// #include <wx/filepicker.h>
// #include <wx/filedlg.h>
// #include <wx/image.h>
// #include <wx/panel.h>
// #include <wx/stattext.h>
// #include <wx/textctrl.h>

inline wxColour randomWxColor()
{
   int r = rand() % 255;
   int g = rand() % 255;
   int b = rand() % 255;
   return wxColour(r,g,b);
}

inline wxImage
toWxImage( de::Image const & src )
{
   int w = src.getWidth();
   int h = src.getHeight();
   wxImage dst( wxSize( w,h ) );

   for ( int y = 0; y < h; ++y )
   {
      for ( int x = 0; x < w; ++x )
      {
         uint32_t color = src.getPixel( x,y );
         uint8_t r = de::RGBA_R( color );
         uint8_t g = de::RGBA_G( color );
         uint8_t b = de::RGBA_B( color );
         uint8_t a = de::RGBA_A( color );
         dst.SetRGB( x,y,r,g,b );
         dst.SetAlpha( x,y,a );
      }
   }

   return dst;
}

inline de::Image
fromWxImage( wxImage const & src )
{
   int w = src.GetWidth();
   int h = src.GetHeight();
   de::Image dst( w,h );

   for ( int y = 0; y < h; ++y )
   {
      for ( int x = 0; x < w; ++x )
      {
         uint8_t r = src.GetRed( x,y );
         uint8_t g = src.GetGreen( x,y );
         uint8_t b = src.GetBlue( x,y );
         uint8_t a = src.GetAlpha( x,y );
         dst.setPixel( x,y,de::RGBA(r,g,b,a) );
      }
   }

   return dst;
}

inline wxImage
createWxImageFromColor( int w, int h, uint32_t color )
{
   wxImage dst( wxSize( w,h ) );

   uint8_t r = de::RGBA_R( color );
   uint8_t g = de::RGBA_G( color );
   uint8_t b = de::RGBA_B( color );
   uint8_t a = de::RGBA_A( color );

   for ( int y = 0; y < h; ++y )
   {
      for ( int x = 0; x < w; ++x )
      {
         dst.SetRGB( x,y,r,g,b );
         dst.SetAlpha( x,y,a );
      }
   }

   return dst;
}

class wxImageCtrl : public wxControl
{
public:
   DE_CREATE_LOGGER("wxImageCtrl")

   wxImageCtrl(
      wxWindow* parent,
      wxWindowID id,
      wxPoint const & pos = wxDefaultPosition,
      wxSize const & size = wxDefaultSize,
      long style = wxTAB_TRAVERSAL );

   ~wxImageCtrl();

   enum {
      ID_UPDATE_TIMER = 10234
   };

   void timerEvent( wxTimerEvent& event );
   void backgroundEvent( wxEraseEvent& event );
   void paintEvent( wxPaintEvent & event );
   void resizeEvent( wxSizeEvent & event );
   //void OnButtonClicked( wxCommandEvent & event )
   //int ClientH(float pct) { return (int) (GetClientSize().y * pct / 100); }
   //int ClientW(float pct) { return (int) (GetClientSize().x * pct / 100); }
   void setImage( de::Image const & img );
   void setImage( wxImage const & img );
   void setFillColor( wxColour const & color );
   void setPreserveAspectRatio( bool preserve );
   void setScaleEnabled( bool enabled );
   void setScaleQuality( wxImageResizeQuality quality );
   void updateDstImage();
   void render( wxPaintDC & dc );


   bool m_IsDirty;
   bool m_IsScalingEnabled;
   bool m_IsPreservingAspect;
   wxColour m_FillColor;
   wxImageResizeQuality m_ScaleQuality;
   wxImage m_SrcImg;
   wxImage m_DstImg;
   wxBitmap m_DstBmp;
   wxTimer m_Timer;

private:
   DECLARE_EVENT_TABLE()
};

#endif // Frame_H

