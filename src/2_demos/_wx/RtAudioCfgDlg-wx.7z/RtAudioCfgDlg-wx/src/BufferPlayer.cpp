﻿#include "RtAudioEngine_wxpanel.hpp"

wxImage createEngineImage( int w, int h )
{
   wxBitmap bmp( w, h );
   wxMemoryDC dc;
   dc.SelectObject(bmp);
//   int32_t w = int32_t( GetClientSize().x );
//   int32_t h = int32_t( GetClientSize().y );
//   if ( w < 1 ) { return; }
//   if ( h < 1 ) { return; }
//   DE_DEBUG("Client.w = ", GetClientRect().GetWidth() )
//   DE_DEBUG("Client.w = ", GetClientRect().GetHeight() )
//   DE_DEBUG("GetSize.x = ", w )
//   DE_DEBUG("GetSize.y = ", h )
   wxColour bg(50,50,50);
   wxColour white(255,255,255);
   wxColour black(0,0,0);
   wxColour orange(255,155,55);

   dc.SetPen( wxPen( orange, 1 ) );
   dc.SetBrush( wxBrush( bg, wxBRUSHSTYLE_SOLID ) );
   dc.DrawRectangle( 0, 0, w, h );


   //de::audio::DeviceScanner::dumpDevices();
   wxFont fontMono( 12, wxFONTFAMILY_MODERN, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, false );
   dc.SetFont( fontMono );
   dc.SetTextForeground( white );
//   dc.SetTextForeground( black );
//   dc.SetPen( wxPen( orange ) );
//   dc.SetBrush( wxBrush( white, wxBRUSHSTYLE_SOLID ) );

   //wxSize ts = dc.GetTextExtent( _("RtAudioEngine") );
   int x = 5; // (w - ts.GetWidth())/2;
   int y = 5; // (h - ts.GetHeight())/2;
   dc.DrawText( _("RtAudioEngine"), wxPoint( x,y ) );

   //dc.EndDoc();

   //   de::Image pic( 128, 48 );
   //   pic.fill( 0xFF202020 );
   //   de::Font font( "arial.ttf", 24 );
   //   de::ImagePainter::drawText( pic, 10,0, L"RtAudioEngine", 0xFFFFFFFF, font);
   //   img->setImage( pic );
   //   img->SetMinSize( wxSize( pic.getWidth(), pic.getHeight() ) );

   return bmp.ConvertToImage();
}

wxRtAudioEnginePanel::wxRtAudioEnginePanel(
      wxWindow* parent, 
      wxWindowID id, 
      wxPoint const & pos, 
      wxSize const & size, 
      long style )
   : wxPanel(parent, id, pos, size, style, wxT("wxRtAudioEnginePanel"))
   //, m_rta( nullptr )
{
   //de::audio::DeviceScanner::dumpDevices();
   wxFont fontAwesome( 12, wxFONTFAMILY_UNKNOWN, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, _("fontawesome") );
   wxFont awesome24( 24, wxFONTFAMILY_UNKNOWN, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, _("fontawesome") );
   SetFont( fontAwesome );
   //SetSize(400, 300);
   //Center();
   m_img = new wxImageCtrl( this, wxID_ANY );
   m_img->setImage( createEngineImage( 256, 64 ) );
   m_img->SetMinSize( wxSize( 256,64) );

   m_dialVolume = new wxDial( this, wxID_ANY, _("Volume") );
   m_dialBpm = new wxDial( this, wxID_ANY, _("BPM") );

   m_btnStop = new wxButton( this, wxID_ANY, wxString( wchar_t( fa::stop ) ) );
   m_btnPlay = new wxToggleButton( this, wxID_ANY, wxString( wchar_t( fa::play ) ) );

   m_btnStop->SetFont( awesome24 );
   m_btnPlay->SetFont( awesome24 );

   m_btnStop->SetMinSize( wxSize( 64,64) );
   m_btnPlay->SetMinSize( wxSize( 64,64) );

   m_sldBpm = new wxSlider( this, wxID_ANY, 90, 1, 360, wxDefaultPosition, wxDefaultSize, wxHORIZONTAL | wxSL_MIN_MAX_LABELS | wxSL_AUTOTICKS );
   m_sldBpm->SetMinSize( wxSize( 200,32) );
   m_sldBpm->SetTickFreq( 36 );

   m_sldVolume = new wxSlider( this, wxID_ANY, 1, 0, 100, wxDefaultPosition, wxDefaultSize, wxHORIZONTAL | wxSL_MIN_MAX_LABELS | wxSL_AUTOTICKS );
   m_sldVolume->SetMinSize( wxSize( 200,32) );
   m_sldVolume->SetTickFreq( 10 );

   wxBoxSizer* hSlide1 = new wxBoxSizer( wxHORIZONTAL );
   hSlide1->Add( m_sldBpm, wxSizerFlags().Border(wxALL,2).Expand() );
   wxBoxSizer* hSlide2 = new wxBoxSizer( wxHORIZONTAL );
   hSlide2->Add( m_sldVolume,wxSizerFlags().Border(wxALL,2).Expand() );

   wxBoxSizer* vSlider = new wxBoxSizer( wxVERTICAL );
   vSlider->Add( hSlide1, wxSizerFlags().Border(wxALL,2).Expand() );
   vSlider->Add( hSlide2, wxSizerFlags().Border(wxALL,2).Expand() );

   wxSizerFlags flags = wxSizerFlags().Border(wxALL,2).CenterVertical(); //.FixedMinSize();
   wxBoxSizer* hEngine = new wxBoxSizer( wxHORIZONTAL );
   hEngine->Add( m_img, flags );
   hEngine->Add( m_dialVolume, flags );
   hEngine->Add( m_dialBpm, flags );
   hEngine->Add( m_btnStop, flags );
   hEngine->Add( m_btnPlay, flags );
   hEngine->Add( vSlider, flags );

   //m_Update.btn->Bind( wxEVT_COMMAND_BUTTON_CLICKED, &wxRtAudioEnginePanel::onBtnUpdateDevices, this );
   SetSizerAndFit( hEngine );

//   de::Image img;
//   dbLoadImageXPM( img, speaker16_xpm );
//   m_SampleRate.img->setImage( img );
   m_sldBpm->Bind(wxEVT_SLIDER, &wxRtAudioEnginePanel::onSliderBpm, this );
   m_sldVolume->Bind(wxEVT_SLIDER, &wxRtAudioEnginePanel::onSliderVolume, this );

   m_btnPlay->Bind(wxEVT_BUTTON, &wxRtAudioEnginePanel::onButtonPlay, this );
   m_btnStop->Bind(wxEVT_BUTTON, &wxRtAudioEnginePanel::onButtonStop, this );
}

wxRtAudioEnginePanel::~wxRtAudioEnginePanel()
{
//   if ( m_rta )
//   {
//      delete m_rta;
//      m_rta = nullptr;
//   }
}

void
wxRtAudioEnginePanel::onSliderBpm( wxCommandEvent & event )
{
   std::cout << __func__ << "\n";
}


void
wxRtAudioEnginePanel::onSliderVolume( wxCommandEvent & event )
{
   std::cout << __func__ << "\n";
}


void
wxRtAudioEnginePanel::onButtonPlay( wxCommandEvent & event )
{
//   de::audio::Config cfg = getConfig();
//   std::string s( "Config:\n" );
//   s += cfg.toString();
//   wxLogMessage( s.c_str() );
}

