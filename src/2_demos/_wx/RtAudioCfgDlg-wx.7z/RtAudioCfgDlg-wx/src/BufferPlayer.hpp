﻿#ifndef DE_RTAUDIO_ENGINE_WXPANEL_HPP
#define DE_RTAUDIO_ENGINE_WXPANEL_HPP

#include <RtAudioConfig_wxpanel.hpp>
#include <de/audio/engine/RtAudioEngine.hpp>
#include <wxDial.hpp>
#include <wxLevelMeter.hpp>

// ===================================================================
class wxRtAudioEnginePanel : public wxPanel
// ===================================================================
{
   DE_CREATE_LOGGER("de.wxRtAudioEnginePanel")

   wxImageCtrl* m_img;       // Engine Label as Image

   wxDial* m_dialVolume;
   wxDial* m_dialBpm;
   wxButton* m_btnStop;
   wxToggleButton* m_btnPlay;
   //wxToggleButton* m_btnMute;
   //wxToggleButton* m_btnRepeat;
   wxSlider* m_sldVolume;
   wxSlider* m_sldBpm;

//   de::media::ff::FileDecoder m_ifsAudio;
   de::audio::engine::RtAudioEngine m_Engine;

public:
   wxRtAudioEnginePanel(
      wxWindow* parent, 
      wxWindowID id = wxID_ANY, 
      wxPoint const & pos = wxDefaultPosition, 
      wxSize const & size = wxDefaultSize, 
      long style = wxTAB_TRAVERSAL | wxNO_BORDER );

   ~wxRtAudioEnginePanel();

private:  
   void onSliderVolume( wxCommandEvent & event );
   void onSliderBpm( wxCommandEvent & event );
   void onButtonPlay( wxCommandEvent & event );
   // void onPause( wxCommandEvent & event );
   // void onStop( wxCommandEvent & event );

   //DECLARE_EVENT_TABLE()
};

#endif

