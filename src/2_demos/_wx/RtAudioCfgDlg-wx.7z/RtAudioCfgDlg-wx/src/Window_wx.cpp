﻿#include "Window_wx.hpp"

// ===================================================================
// Window
// ===================================================================
BEGIN_EVENT_TABLE(Window, wxFrame)
   EVT_CLOSE(Window::closeEvent)
   //EVT_DROP_FILES(Window::dropFilesEvent)
   //EVT_SLIDER(id, func):
   EVT_MENU(MenuID_FileExit, Window::onMenuFileExit)
   EVT_MENU(MenuID_FileLoad, Window::onMenuFileOpen)
   // EVT_MENU(MenuID_FileSAVE, Window::OnSave)
   // EVT_MENU(MenuID_FileSAVE_AS, Window::OnSaveAs)
   EVT_MENU(MenuID_HelpAbout, Window::onMenuHelpAbout)
END_EVENT_TABLE()

Window::Window(
      wxWindow* parent, 
      wxWindowID id, 
      wxPoint const & pos, 
      wxSize const & size, 
      long style )
   : wxFrame(parent, id, wxT("VLC Player wx + ffmpeg"), pos, size, style)
   , m_MenuBar( nullptr )
   , m_MenuFile( nullptr )
   , m_MenuHelp( nullptr )
   , m_AudioConfigPanel( nullptr )
{
   //   wxFont fontAwesome( 16, wxFONTFAMILY_UNKNOWN, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, _("fontawesome") );
   //   SetFont( fontAwesome );
   SetSize(800, 600);
   Center();
   DragAcceptFiles( true );
   createMenuBar();
   createStatusBar();

   m_AudioConfigPanel = new wxRtAudioConfigPanel( this, wxID_ANY );
   m_AudioPlayerPanel = new wxRtAudioEnginePanel( this, wxID_ANY );
   wxBoxSizer* v = new wxBoxSizer( wxVERTICAL );
   v->Add( m_AudioConfigPanel, wxSizerFlags().Expand() );
   v->Add( m_AudioPlayerPanel, wxSizerFlags().Expand() );
   SetSizerAndFit( v );

}

Window::~Window()
{
}

void Window::createStatusBar()
{
   CreateStatusBar(1);
   SetStatusText(_("RtAudioConfigDialog-wx (c) 2021 Benjamin Hampe <benjamin.hampe@gmx.de> | "),0);
}

void Window::createMenuBar()
{
   m_MenuFile = new wxMenu(_T(""));
   m_MenuFile->Append(MenuID_FileLoad, _("&Load\tAlt-O"), _("Laden von Dateien und Projekten"));
   m_MenuFile->Append(MenuID_FileExit, _("&Exit VLC\tAlt-F4"), _("Programm beenden"));

   m_MenuHelp = new wxMenu(_T(""));
   m_MenuHelp->Append(MenuID_HelpAbout, _("&About\tF12"), _("Infos"));

   m_MenuBar = new wxMenuBar();
   m_MenuBar->Append( m_MenuFile, _("&File"));
   m_MenuBar->Append( m_MenuHelp, _("&Help"));
   SetMenuBar( m_MenuBar );
}

// void Window::dropFilesEvent( wxDropFilesEvent& event )
// {
   // int fileCount = event.GetNumberOfFiles();
   // DE_DEBUG("FileCount = ", fileCount )
   // for ( int i = 0; i < fileCount; ++i )
   // {
      // wxString const & uri = event.GetFiles()[ i ];
      // DE_DEBUG("File[",i,"] ", uri.ToStdString() )
   // }
   // if ( fileCount > 0 )
   // {
      // std::string uri = event.GetFiles()[ 0 ].ToStdString();
      // openFile( uri );
   // }
// }

void Window::closeEvent( wxCloseEvent & event )
{
   Destroy();
}

void Window::onMenuFileExit( wxCommandEvent & event )
{
   Destroy();
}

void Window::onMenuHelpAbout( wxCommandEvent & event )
{
   wxMessageBox( wxT("wxIrrlicht (c) 2008-2011 by BenjaminHampe@gmx.de\n\nVersion 1.0\n"), wxT("About"));
}

void Window::onMenuFileOpen( wxCommandEvent & event )
{
   wxFileDialog fileDialog( this );
   wxString uri;
   if ( fileDialog.ShowModal() == wxID_OK )
   {
      uri = fileDialog.GetPath();
   }

//   openFile( uri.ToStdString() );

   event.Skip();
}

// void Window::openFile( std::string uri )
// {
   // if ( uri.empty() )
   // {
      // DE_ERROR("Empty uri")
      // return;
   // }

   // if ( !m_File.open( uri ) )
   // {
      // DE_ERROR("Cant open uri ",uri )
      // return;
   // }

   // DE_DEBUG("Opened VLC uri ",uri )

   // //std::string saveName = uri.ToStdString() + ".coverart.jpg";
   // //dbSaveImage( m_File.m_CoverArt, saveName );
   // //DE_DEBUG("Saved CoverArt ",saveName)

   // m_imgVideo->setImage( m_File.m_CoverArt );
   // updateMenuBarFromMediaFile();

   // if ( !de::audio::BufferLoader::load( m_Buffer, uri, de::audio::ST_S16I, -1 ) )
   // {
      // DE_ERROR("Cant load waveform uri ", uri)
   // }
   // else
   // {
      // DE_DEBUG("Loaded waveform uri = ", uri)
      // DE_DEBUG("Loaded waveform buffer = ",m_Buffer.toString())

      // de::Image waveform( 1024,64 );
      // de::audio::BufferDraw::drawChannelWaveform( m_Buffer, 0, waveform, waveform.getRect() );
      // m_imgWaveform->setImage( waveform );
   // }

   //de::fileconverter::convert2wav( uri );

   // m_File.hasDurationFast();
// }

// ===================================================================
// App
// ===================================================================

bool App::OnInit()
{
   wxInitAllImageHandlers();

   if ( !wxFont::AddPrivateFont( "fontawesome463.ttf" ) )
   {
      std::cout << "No fontawesome463.ttf" << std::endl;
   }

  // Print CommandLine Commands wxCmdLineEntryDesc
  size_t c = sizeof(commands)/sizeof(commands[0])-1;

  wxString s = wxT("");
  for ( size_t i = 0; i < c; ++i )
  {
     s += wxString::Format(
     wxT("Option [%d]\t%s, %s, %s, %d, %d\n"),
     i,
     //commands[i].kind,
     commands[i].shortName,
     commands[i].longName,
     commands[i].description,
     commands[i].type,
     commands[i].flags);
  }

  std::cout << s.mb_str(wxConvUTF8) << std::endl;

  // Set CommandLine Parser
  wxCmdLineParser parser(commands, argc, argv);
  parser.SetDesc(commands);
  parser.SetLogo(wxT("Irrlicht2011"));
  parser.SetSwitchChars(wxT("-"));
  parser.Parse(false);

  // Parse CommandLine
  bool showHelp = parser.Found(wxT("h"));
  if (showHelp)
     wxMessageBox(s,wxT("wx-Irrlicht2011 CommandLineOptions"));

  // Print CommandLine Arguments
  for ( size_t i = 0; i < parser.GetParamCount(); ++i )
  {
     wxString p = parser.GetParam( i );
     wxLogMessage( p.c_str() );
     wxMessageBox( p, wxT("Param") + i );
  }

   // Create GUI
   Window* win = new Window(0L, wxID_ANY);
   win->SetIcon(wxICON(aaaa)); // To Set App Icon
   win->Show();
   return true;
}

int App::OnExit()
{
   // clean up
   return 0;
}

int App::OnRun()
{
   int exitcode = wxApp::OnRun();
   if ( exitcode!=0 ) 
   {
      // error
   }
   return exitcode;
}
