#include "IrfanView_wx.hpp"

IMPLEMENT_APP(IrfanView_App);
