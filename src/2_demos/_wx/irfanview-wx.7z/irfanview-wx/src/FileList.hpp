#ifndef DE_FILELIST_HPP
#define DE_FILELIST_HPP

#include <de/FileSystem.hpp>

uint64_t
dbFileIndex();

uint64_t
dbFileCount();

std::string
dbPrevFile( std::string uri, bool wrapAround = false );

std::string
dbNextFile( std::string uri, bool wrapAround = false );

//std::string
//dbEnumerateFiles( std::string uri, bool recursive = false );

//std::string
//dbGetFile( std::string uri, bool recursive = false );

//std::string
//dbGetFile( std::string uri, bool recursive = false );

#endif // DARKCORE_FILESYSTEM_HPP
