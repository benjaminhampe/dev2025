#include "FileList.hpp"
#include <de/FileSystem.hpp>

namespace de {

struct FileList
{
   DE_CREATE_LOGGER("de.FileList")
   uint64_t m_Index;
   std::string m_Uri;
   std::string m_Dir;
   std::vector< std::string > m_Files;
   FileList() : m_Index( 0 ) {}
   ~FileList() {}

   static FileList &
   getInstance()
   {
      static FileList fileList;
      return fileList;
   }

   bool
   enumerateFiles( std::string uri, bool recursive = false, bool forceUpdate = false )
   {
      uri = FileSystem::makeAbsolute( uri );
      std::string dir = uri;
      bool isFile = dbExistFile( uri );
      bool isDir = dbExistDirectory( uri );
      if ( !isDir )
      {
         //DE_DEBUG("Not a dir = ",dir)
         if ( isFile )
         {
            dir = dbGetFileDir( uri );
            //DE_DEBUG("Use dir = ",dir, " from uri = ",uri)
            isDir = dbExistDirectory( dir );
            if ( !isDir )
            {
               //DE_ERROR("No parent dir = ",dir)
               return false;
            }
         }
         else
         {
            //DE_ERROR("No uri = ",uri)
            return false;
         }
      }

      bool needUpdate = true;
      if ( m_Dir == dir )
      {
         if ( !forceUpdate )
         {
            needUpdate = false; // Nothing todo
         }
      }

      if ( needUpdate )
      {
         //DE_DEBUG("needUpdate")
         m_Uri = uri;
         m_Dir = dir;
         m_Files.clear();
         FileSystem::entryList(
                     m_Dir,
                     recursive,
                     true,    // withFiles
                     false,   // withDirs,
                     [&]( std::string const & uri ) { m_Files.push_back( uri ); } );

         if ( isFile )
         {
            m_Index = findUri( uri );
         }
         else
         {
            m_Index = 0; // first file
         }
      }

      //DE_DEBUG("uri = ", uri)
      //DE_ERROR("m_Uri = ", m_Files[ m_Index ])
      //DE_ERROR("m_Index = ", m_Index)
      return true;
   }

   uint64_t
   findUri( std::string uri ) const
   {
      //DE_DEBUG("uri = ",uri)

      auto it = std::find_if( m_Files.begin(), m_Files.end(),
         [&] ( std::string const& cached )
         {
            return cached == uri;
         });

      if ( it == m_Files.end() )
      {
         //DE_ERROR("Cant find uri ", uri,", files = ",m_Files.size() )
         return m_Files.size();
      }
      else
      {
         uint64_t index = std::distance( m_Files.begin(), it );
         //DE_DEBUG("Got index ", index, ", uri = ", m_Files[ index ] )
         return index;
      }
   }


   std::string
   prev( std::string uri, bool wrapAround = false )
   {
      enumerateFiles( uri, false, false );

      if ( m_Files.empty() ) return "";

      uint64_t index = getIndex();
      if ( index == 0 )
      {
         if ( wrapAround )
         {
            index = m_Files.size() - 1;
         }
      }
      else
      {
         index--;
      }

      setIndex( index );
      return getFileName();
   }

   std::string
   next( std::string uri, bool wrapAround = false )
   {
      enumerateFiles( uri, false, false );

      if ( m_Files.empty() ) return "";

      uint64_t index = getIndex();
      if ( index >= m_Files.size() - 1 )
      {
         if ( wrapAround )
         {
            index = 0;
         }
         else
         {
            index = m_Files.size() - 1;
         }
      }
      else
      {
         index++;
      }

      setIndex( index );
      return getFileName();
   }

   std::string
   getFileName() const
   {
      if ( m_Index >= m_Files.size() ) return "";
      return m_Files[ m_Index ];
   }

   std::string const &
   getDir() const { return m_Dir; }

   uint64_t
   getFileCount() const { return m_Files.size(); }

   uint64_t
   getIndex() const { return m_Index; }

   bool
   setIndex( uint64_t i )
   {
      if ( m_Files.size() < 2 )
      {
         m_Index = 0;
         //DE_WARN("Too few files = ",m_Files.size())
         if ( m_Files.empty() ) { m_Uri = ""; }
         else { m_Uri = m_Files[ 0 ]; }
         return true;
      }

      if ( i >= m_Files.size() )
      {
         //DE_WARN("Invalid i = ",i,", files = ",m_Files.size())
         return false;
      }

      m_Index = i;
      m_Uri = m_Files[ i ];
      //DE_DEBUG("Set file i = ", m_Index,", files = ",m_Files.size())
      return true;
   }
};

} // end namespace de.

uint64_t
dbFileIndex()
{
   return de::FileList::getInstance().getIndex();
}

uint64_t
dbFileCount()
{
   return de::FileList::getInstance().getFileCount();
}

std::string
dbPrevFile( std::string uri, bool wrapAround )
{
   return de::FileList::getInstance().prev( uri, wrapAround );
}

std::string
dbNextFile( std::string uri, bool wrapAround )
{
   return de::FileList::getInstance().next( uri, wrapAround );
}
