﻿#include "IrfanView_wx.hpp"

BEGIN_EVENT_TABLE(IrfanViewWindow, wxFrame)
   EVT_CLOSE(IrfanViewWindow::closeEvent)
   EVT_DROP_FILES(IrfanViewWindow::dropFilesEvent)
   //EVT_SLIDER(id, func):
   EVT_MENU(MenuId_ABOUT, IrfanViewWindow::onMenuHelpAbout)
   EVT_MENU(MenuId_QUIT, IrfanViewWindow::onMenuFileExit)
   EVT_MENU(MenuId_OPEN, IrfanViewWindow::onMenuFileOpen)
//   EVT_MENU(MenuId_SAVE, IrfanViewWindow::OnSave)
   EVT_MENU(MenuId_SAVE_AS, IrfanViewWindow::onMenuFileSaveAs)
   EVT_KEY_DOWN(IrfanViewWindow::keyPressEvent)
   EVT_KEY_UP(IrfanViewWindow::keyReleaseEvent)
   EVT_MOUSE_EVENTS(IrfanViewWindow::mouseEvent)
END_EVENT_TABLE()

// ===================================================================
IrfanViewWindow::IrfanViewWindow(
      wxWindow* parent, wxWindowID id, wxString const & title, 
      wxPoint const & pos, wxSize const & size, long style )
// ===================================================================
   : wxFrame(parent, id, title, pos, size, style)
   , m_MenuBar( nullptr )
   , m_MenuFile( nullptr )
   , m_MenuEdit( nullptr )
   , m_MenuView( nullptr )
   , m_MenuHelp( nullptr )
   , m_Canvas( nullptr )
{
   wxFont fontAwesome( 16, wxFONTFAMILY_UNKNOWN, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, _("fontawesome") );
   SetFont( fontAwesome );
   SetSize( 800, 600 );
   Center();
   DragAcceptFiles( true );
   // SetDoubleBuffered();
   // m_X->Bind( wxEVT_COMMAND_SPINCTRL_UPDATED, &wxImageCtrl::OnXChanged, this );
   //Connect(wxEVT_SIZE, wxSizeEventHandler(MySubScrolledWindow::OnSize));
   createMenuBar();
   createStatusBar();
   m_Canvas = new wxImageCtrl( this, wxID_ANY );
   m_Canvas->SetMinSize( wxSize(256,256) );
   m_Canvas->setPreserveAspectRatio( true );
   wxBoxSizer* v = new wxBoxSizer( wxVERTICAL );
   v->Add( m_Canvas, wxSizerFlags().Expand().Proportion(1) );
   SetSizerAndFit( v );

   m_Canvas->setUserData( this );
}

IrfanViewWindow::~IrfanViewWindow()
{
   DE_DEBUG("")
}

void
IrfanViewWindow::prevFile()
{
   //DE_DEBUG("")
   std::string uri = dbPrevFile( m_FileName );
   openFile( uri );
}

void
IrfanViewWindow::nextFile()
{
   //DE_DEBUG("")
   std::string uri = dbNextFile( m_FileName );
   openFile( uri );
}

void
IrfanViewWindow::keyPressEvent( wxKeyEvent& event )
{
   int kc = event.GetKeyCode();
   DE_DEBUG("KeyPressEvent :: ", kc )
   if ( kc == WXK_LEFT ) { prevFile(); }
   else if ( kc == WXK_RIGHT ){ nextFile(); }
   event.Skip();
}

void
IrfanViewWindow::keyReleaseEvent( wxKeyEvent& event )
{
   int kc = event.GetKeyCode();
   DE_DEBUG("keyReleaseEvent :: ", kc )
   if ( kc == WXK_LEFT ) { prevFile(); }
   else if ( kc == WXK_RIGHT ){ nextFile(); }

   event.Skip();
}


void IrfanViewWindow::onMenuFileOpen( wxCommandEvent & event )
{
   wxFileDialog fileDialog( this );

   wxString uri;
   if ( fileDialog.ShowModal() == wxID_OK )
   {
      uri = fileDialog.GetPath();
   }

   openFile( uri.ToStdString() );
   event.Skip();
}

void IrfanViewWindow::onMenuFileSaveAs( wxCommandEvent & event )
{
   wxFileDialog fileDialog( this );

   wxString uri;
   if ( fileDialog.ShowModal() == wxID_OK )
   {
      uri = fileDialog.GetPath();
   }

   std::string m_SaveUri = uri.ToStdString();

   if ( dbSaveImage( m_Image, m_SaveUri ) )
   {

   }
   event.Skip();
}

void IrfanViewWindow::openFile( std::string uri )
{
   if ( uri.empty() )
   {
      //DE_ERROR("Empty uri")
      return;
   }

   if ( m_FileName == uri )
   {
      //DE_DEBUG("Already open")
      return;
   }

   m_FileName = uri;

   if ( dbLoadImage( m_Image, uri ) )
   {
      //DE_DEBUG("Loaded img(",m_Image.toString(),")" )
      m_Canvas->setImage( m_Image );

      std::ostringstream s;
      s << "[" << dbFileIndex()+1 << "," << dbFileCount() << "] " << uri;

      std::string msg = s.str();
      SetStatusText(_(msg.c_str()),0);

      SetTitle( _(msg.c_str()) );
   }
}

void IrfanViewWindow::createStatusBar()
{
   CreateStatusBar(1);
   SetStatusText(_("IrfanView-wx (c) 2021 Benjamin Hampe <benjamin.hampe@gmx.de> | "),0);
}

void IrfanViewWindow::createMenuBar()
{
   m_MenuBar = new wxMenuBar();
   m_MenuFile = new wxMenu(_T(""));
   m_MenuEdit = new wxMenu(_T(""));
   m_MenuView = new wxMenu(_T(""));
   m_MenuHelp = new wxMenu(_T(""));
   m_MenuFile->Append(MenuId_OPEN, _("&Load\tAlt-O"), _("Laden von Dateien und Projekten"));
   //m_actOpen->Bind wxEVT_COMMAND_BUTTON_CLICKED, &IrfanViewWindow::onMenuFileOpen, this );
   //m_MenuFile->Append(MenuId_SAVE, _("&Save\tAlt-S"), _("Speichern von Dateien und Projekten"));
   m_MenuFile->Append(MenuId_SAVE_AS, _("&Save As\tCtrl-S"), _("Speichern von Dateien und Projekten"));
   m_MenuFile->Append(MenuId_QUIT, _("&Exit Program\tAlt-F4"), _("Programm beenden"));
   m_MenuHelp->Append(MenuId_ABOUT, _("&About\tF12"), _("Infos"));
   m_MenuBar->Append( m_MenuFile, _("&File"));
   m_MenuBar->Append( m_MenuEdit, _("&Edit"));
   m_MenuBar->Append( m_MenuView, _("&View"));
   m_MenuBar->Append( m_MenuHelp, _("&Help"));
   SetMenuBar( m_MenuBar );
}

void IrfanViewWindow::dropFilesEvent( wxDropFilesEvent& event )
{
   int fileCount = event.GetNumberOfFiles();
   DE_DEBUG("FileCount = ", fileCount )
   for ( int i = 0; i < fileCount; ++i )
   {
      wxString const & uri = event.GetFiles()[ i ];
      DE_DEBUG("File[",i,"] ", uri.ToStdString() )
   }
   if ( fileCount > 0 )
   {
      std::string uri = event.GetFiles()[ 0 ].ToStdString();
      openFile( uri );
   }
}

void IrfanViewWindow::closeEvent( wxCloseEvent & event )
{
   DE_DEBUG("")
   Destroy();
}

void IrfanViewWindow::onMenuFileExit( wxCommandEvent & event )
{
   DE_DEBUG("")
   Destroy();
}

void IrfanViewWindow::onMenuHelpAbout( wxCommandEvent & event )
{
   DE_DEBUG("")
   wxMessageBox( wxT("wxIrrlicht (c) 2008-2011 by BenjaminHampe@gmx.de\n\nVersion 1.0\n"), wxT("About"));
}


void
IrfanViewWindow::mouseEvent(wxMouseEvent& event)
{
   int mx = event.GetX();
   int my = event.GetY();
   float wheel = (float)event.GetWheelRotation();
/*
   m_MousePos = glm::ivec2( mx, my ); // current mouse pos

   if ( m_MousePos != m_MousePosLast ) // Some button is clicked...
   {
      m_MouseMove = m_MousePos - m_MousePosLast; // current mouse pos

      m_MousePosLast = m_MousePos;
   }
   else
   {
      m_MouseMove = { 0,0 };
   }

   // ### MousePressEvent ###
   // m_MousePos = glm::ivec2( event->x(), event->y() ); // current mouse pos
   // m_MouseMove = { 0,0 };
   // m_IsLeftPressed = event->button() == Qt::LeftButton;
   // m_IsRightPressed = event->button() == Qt::RightButton;
   // m_IsMiddlePressed = event->button() == Qt::MiddleButton;
   if (event.IsButton())
   {
      if (event.LeftDown()) m_IsLeftPressed = true;
      else if (event.LeftUp()) m_IsLeftPressed = false;
      else if (event.MiddleDown()) m_IsMiddlePressed = true;
      else if (event.MiddleUp()) m_IsMiddlePressed = false;
      else if (event.RightDown()) m_IsRightPressed = true;
      else if (event.RightUp()) m_IsRightPressed = false;
   }

   // ### MouseReleaseEvent ###
   // m_MousePos = glm::ivec2( event->x(), event->y() ); // current mouse pos
   // m_MouseMove = { 0,0 };
   // if ( event->button() == Qt::LeftButton )
   // {
      // m_IsLeftPressed = false;
   // }
   // if ( event->button() == Qt::RightButton )
   // {
      // m_IsRightPressed = false;
   // }
   // if ( event->button() == Qt::MiddleButton )
   // {
      // m_IsMiddlePressed = false;
   // }
*/
   event.Skip();
}


// ===================================================================
bool IrfanView_App::OnInit()
// ===================================================================
{
   wxInitAllImageHandlers();

   if ( !wxFont::AddPrivateFont( "fontawesome463.ttf" ) )
   {
      DEM_FATAL("No fontawesome463.ttf")
   }

  // Print CommandLine Commands wxCmdLineEntryDesc
  size_t c = sizeof(commands)/sizeof(commands[0])-1;

  wxString s = wxT("");
  for ( size_t i = 0; i < c; ++i )
  {
     s += wxString::Format(
     wxT("Option [%d]\t%s, %s, %s, %d, %d\n"),
     i,
     //commands[i].kind,
     commands[i].shortName,
     commands[i].longName,
     commands[i].description,
     commands[i].type,
     commands[i].flags);
  }

  std::cout << s.mb_str(wxConvUTF8) << std::endl;

  // Set CommandLine Parser
  wxCmdLineParser parser(commands, argc, argv);
  parser.SetDesc(commands);
  parser.SetLogo(wxT("Irrlicht2011"));
  parser.SetSwitchChars(wxT("-"));
  parser.Parse(false);

  // Parse CommandLine
  bool showHelp = parser.Found(wxT("h"));
  if (showHelp)
     wxMessageBox(s,wxT("wx-Irrlicht2011 CommandLineOptions"));

  // Print CommandLine Arguments
  for ( size_t i = 0; i < parser.GetParamCount(); ++i )
  {
     wxString p = parser.GetParam( i );
     wxLogMessage( p.c_str() );
     wxMessageBox( p, wxT("Param") + i );
  }

   // Create GUI
   IrfanViewWindow* win = new IrfanViewWindow(0L, wxID_ANY, wxT("Paint2D-wx"));
   win->SetIcon(wxICON(aaaa));
   win->Show();
   return true;
}

int IrfanView_App::OnExit()
{
   // clean up
   return 0;
}

int IrfanView_App::OnRun()
{
   int exitcode = wxApp::OnRun();
   if ( exitcode!=0 ) 
   {
      // error
   }
   return exitcode;
}
