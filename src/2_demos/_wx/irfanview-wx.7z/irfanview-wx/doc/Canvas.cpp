#include "Canvas.hpp"
#include "History.hpp"
#include "MainWindow.hpp"


QImage
createImage( int w, int h, QColor color )
{
   QImage img( w, h, QImage::Format_ARGB32 );
   img.fill( color );
   return img;
}

QImage
zoomImage( QImage const & src, float zoom, int src_x, int src_y, int dst_w, int dst_h, int max_w, int max_h )
{
   // de::Math::clamp32i( )
   if ( src.isNull() )
   {
      qDebug() << __func__ << ":" << __LINE__ << " :: Empty image";
      return QImage();
   }
   if ( max_w < 2 )
   {
      qDebug() << __func__ << ":" << __LINE__ << " :: Invalid max_w("<<max_w<<")";
      return QImage();
   }
   if ( max_h < 2 )
   {
      qDebug() << __func__ << ":" << __LINE__ << " :: Invalid max_h("<<max_h<<")";
      return QImage();
   }
   if ( dst_w < 2 )
   {
      qDebug() << __func__ << ":" << __LINE__ << " :: Invalid dst_w("<< dst_w<<")";
      return QImage();
   }
   if ( dst_h < 2 )
   {
      qDebug() << __func__ << ":" << __LINE__ << " :: Invalid dst_h("<< dst_h<<")";
      return QImage();
   }

   //int dst_h = src.height() * zoom;
   QImage dst( max_w, max_h, QImage::Format_ARGB32 );
   dst.fill( Qt::red );
//   //
//   int rx = std::clamp( src_x - dst_w/2, 0, img_w - 1 );
//   int ry = std::clamp( src_y - dst_h/2, 0, img_h - 1 );

//   int src_w = int( float( src.width() ) / zoom );
//   int src_h = int( float( src.height() ) / zoom );

   int src_w = src.width();
   int src_h = src.height();

   for ( int y = 0; y < max_h; ++y )
   {
      for ( int x = 0; x < max_w; ++x )
      {
         int zoom_x = src_x + std::round( float( src_w-1 ) * ( float( x ) / float( dst_w-1 ) ) );
         int zoom_y = src_y + std::round( float( src_h-1 ) * ( float( y ) / float( dst_h-1 ) ) );

         if ( zoom_x >= 0 && zoom_y >= 0 && zoom_x < src.width() && zoom_y < src.height() )
         {
            QColor color = src.pixelColor( zoom_x, zoom_y );
            dst.setPixelColor( x, y, color );
         }
      }
   }

   QPainter dc;
   if ( dc.begin( &dst ) )
   {
      dc.setBrush( Qt::NoBrush );
      dc.setPen( QPen( QColor( 255,0,0 ) ) );
      dc.drawRect( QRect( 0,0,dst.width()-1,dst.height()-1) );
   }
   // qDebug() << __func__ << " :: Zoom("<<src_x<< ","<<src_y<<"), DstSize("<<dst_w<<","<<dst_h<< ")";

   return dst;
}


void
Canvas::updateDstImage()
{
   if ( !m_DstNeedsUpdate )
   {
      return;
   }
   int src_w = m_SrcImage.width();
   int src_h = m_SrcImage.height();
   int src_x = int( m_ScrollX * src_w );
   int src_y = int( m_ScrollY * src_h );

//   int max_w = std::min( src_w, width() - 2*m_ResizeBorder );
//   int max_h = std::min( src_h, height() - 2*m_ResizeBorder );
   float fZoom = 0.01f * float(m_Zoom);
   int dst_w = int( fZoom * src_w );
   int dst_h = int( fZoom * src_h );
   if ( dst_w < 2 && dst_h < 2 )
   {
      qDebug() << __func__ << " :: Invalid dst_w " << dst_w << "), dst_h(" << dst_h << ")";
      return;
   }

   int max_w = width();
   int max_h = height();
   if ( width() >= dst_w )
   {
      max_w = dst_w;
   }
   if ( height() >= dst_h )
   {
      max_h = dst_h;
   }


   m_DstImage = zoomImage( m_SrcImage, 1, src_x, src_y, dst_w, dst_h, max_w, max_h );
   m_DstNeedsUpdate = false;
   qDebug() << __func__ << " :: Max(" << max_w << "," << max_h << "), "
      "Zoom(" << m_Zoom << "), Scroll(" << m_ScrollX << "," << m_ScrollY << "), "
      "Src(" << src_x << "," << src_y << "," << src_w << "," << src_h << "), "
      "Dst(" << dst_w << "," << dst_h << "), ";
   update();
}
/*
void
Canvas::updateViewImage()
{
   if ( !m_DstNeedsUpdate )
   {
      return;
   }
   m_DstNeedsUpdate = false;

   m_DstImage = m_SrcImage.copy( m_DstRect );
   qDebug() << "Canvas." << __FUNCTION__ << " :: Copy viewRect(" << m_DstRect << ") from source-image(" << m_SrcImage.size() << ").";

   int scaled_w = int ( m_ViewScale * float( m_DstImage.width() ) );
   int scaled_h = int ( m_ViewScale * float( m_DstImage.height() ) );
   if ( scaled_w != m_DstRect.width() || scaled_h != m_DstRect.height() )
   {
      qDebug() << "Canvas." << __FUNCTION__ << " :: Scaled view image(" << scaled_w << "," << scaled_h << ") with viewScale(" << m_ViewScale << ").";
      if ( scaled_w < m_SrcImage.width() || scaled_h < m_SrcImage.height() )
      {
         m_DstImage = m_DstImage.scaled( scaled_w, scaled_h, Qt::IgnoreAspectRatio, Qt::SmoothTransformation );
      }
      else
      {
         m_DstImage = m_DstImage.scaled( scaled_w, scaled_h, Qt::IgnoreAspectRatio, Qt::FastTransformation );
      }
      setFixedSize( m_DstImage.width() + 10, m_DstImage.height() + 10 );
   }
   m_ResizeBarXRect = QRect( m_DstImage.width(), 0, 10, m_DstImage.height() );
   m_ResizeBarYRect = QRect( 0, m_DstImage.height(), m_DstImage.width(), 10 );
}
*/
Canvas::Canvas( QWidget * parent )
   : QWidget( parent )
   , m_MainWindow( nullptr )
   , m_PaintMode( PaintMode::SelectRect )
   , m_Zoom( 100 )
   , m_ResizeBorder( 15 )
   , m_ScrollX( 0.0f )
   , m_ScrollY( 0.0f )
   , m_SrcFileName()
   , m_SrcImage()
   , m_DstImage()
   , m_DstNeedsUpdate( true )
   , m_FillColor( 255,255,255,255 )
   , m_LineColor( 0,0,0,255 )
   , m_LineWidth( 1.0f )
   , m_ZoomViewEnabled( false )
   , m_IsResizingView( false )
   , m_IsViewResizingX( false )
   , m_IsViewResizingY( false )
//   , m_ZoomRectX( 0 ) // show 10 px in x direction.
//   , m_ZoomRectY( 0 ) // show 20 px in y direction.
//   , m_ZoomRectW( 11 ) // show 10 px in x direction.
//   , m_ZoomRectH( 11 ) // show 20 px in y direction.
   , m_CursorX( 0 )
   , m_CursorY( 0 )
   , m_LastCursorX( 0 )
   , m_LastCursorY( 0 )
   , m_MouseX( 0 )
   , m_MouseY( 0 )
   , m_LastMouseX( 0 )
   , m_LastMouseY( 0 )
   , m_MouseReleaseX( 0 )
   , m_MouseReleaseY( 0 )
   , m_MouseClickLeft( false )
   , m_MouseClickRight( false )
{
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 128, 64 );
   setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
   setMouseTracking( true );
   m_MainWindow = dynamic_cast< MainWindow* >( parent );

   newImage( 512, 256 );
}

Canvas::~Canvas()
{

}

/*
bool
Canvas::loadImage( QString fileName )
{
   if ( m_SrcImage.load( fileName ) )
   {
      m_SrcFileName = fileName;
      setFixedSize( m_SrcImage.width() + 10, m_SrcImage.height() + 10 );
      qDebug() << "Loaded image file(" << m_SrcFileName << "), image( w:" << m_SrcImage.width() << ", h:" << m_SrcImage.height() << ")";
      updateViewImage();
      return true;
   }
   else
   {
      qDebug() << "Cant load image (" << fileName << ")";
      return false;
   }
}
*/

void
Canvas::setImage( QImage const & img, QString const & uri)
{
   qDebug() << __func__ << " :: Dim(" << img.width() << "," << img.height() << "), Uri(" << uri << ")";
   m_SrcImage = img;
   m_SrcFileName = uri;
   m_DstNeedsUpdate = true;
   updateDstImage();
}

void
Canvas::newImage( int w, int h )
{
   QImage img( w, h, QImage::Format_ARGB32 );
   img.fill( Qt::white );
   setImage( img, "Untitled2020.png" );
}

bool
Canvas::saveImage()
{
   return false;
}

bool
Canvas::saveImageAs( QString fileName )
{
   return false;
}

void
Canvas::setScrollBarX( float scroll_x )
{
   m_ScrollX = scroll_x;
   m_DstNeedsUpdate = true;
   updateDstImage();
}

void
Canvas::setScrollBarY( float scroll_y )
{
   m_ScrollY = scroll_y;
   m_DstNeedsUpdate = true;
   updateDstImage();
}


void
Canvas::resizeEvent( QResizeEvent* event )
{
   int w = event->size().width();
   int h = event->size().height();
   m_DstNeedsUpdate = true;
   updateDstImage();
   // Signal canvas size changed.
   std::stringstream s; s << "ResizeEvent( w:" << w << ", h:" << h << " )";
   getMainWindow()->getStatusBar()->m_CanvasInfo->setText( QString::fromStdString( s.str() ) );
}

void
Canvas::paintEvent( QPaintEvent* event )
{
   updateDstImage();

   QPainter dc;
   if ( !dc.begin( this ) ) { return; }

   // Clear
   dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
   dc.setBrush( QBrush( QColor(50,50,50) ) );
   dc.fillRect( rect(), Qt::SolidPattern );

   if ( m_SrcImage.isNull() )
   {
      qDebug() << "Source image is null";
   }

// RESIZE-BORDER:

   // Draw TOP resize border:
   QColor top( 55,100,200,255 );
   dc.setPen( QPen( top ) );
   dc.setBrush( QBrush( top.lighter(), Qt::SolidPattern ) );
   dc.drawRect( QRect( 0, 0, m_DstImage.width() + m_ResizeBorder, m_ResizeBorder ) );

   // Draw LEFT resize border:
   QColor left( 55,100,250,255 );
   dc.setPen( QPen( left ) );
   dc.setBrush( QBrush( left.lighter(), Qt::SolidPattern ) );
   dc.drawRect( QRect( 0,
                       m_ResizeBorder,
                       m_ResizeBorder,
                       m_DstImage.height() + m_ResizeBorder ) );

   // Draw RIGHT resize border:
   QColor right( 100,100,250,255 );
   dc.setPen( QPen( right ) );
   dc.setBrush( QBrush( right.lighter(), Qt::SolidPattern ) );
   dc.drawRect( QRect( m_DstImage.width() + m_ResizeBorder,
                       0,
                       m_ResizeBorder,
                       m_DstImage.height() + m_ResizeBorder ) );

   // Draw BOTTOM resize border:
   QColor bottom( 100,150,250,255 );
   dc.setPen( QPen( bottom ) );
   dc.setBrush( QBrush( bottom.lighter(), Qt::SolidPattern ) );
   dc.drawRect( QRect( m_ResizeBorder,
                       m_DstImage.height() + m_ResizeBorder,
                       m_DstImage.width() + m_ResizeBorder,
                       m_ResizeBorder ) );

   // DRAW_DISPLAY_IMAGE:

   dc.setBrush( Qt::NoBrush );
   dc.drawImage( QPoint( m_ResizeBorder, m_ResizeBorder ), m_DstImage );

// IMAGE-BORDER:

   if ( m_Zoom < 100 )
   {
      dc.setBrush( Qt::NoBrush );
      dc.setPen( QPen( QColor( 255,100,255 ) ) );
      dc.drawRect( QRect( m_ResizeBorder-1, m_ResizeBorder-1, m_SrcImage.width()+2, m_SrcImage.height()+2 ) );
   }

// RENDER MouseBars:
   dc.setBrush( Qt::NoBrush );
   dc.setPen( QPen( Qt::white ) );
   dc.drawLine( m_CursorX, 0, m_CursorX, m_CursorY - 9 );   // Draw mouse x bar (yellow)
   dc.drawLine( 0, m_CursorY, m_CursorX - 9, m_CursorY );   // Draw mouse y bar (turkis)

// RENDER MouseBarTexts:
   std::ostringstream s;
   s.str(""); s << m_CursorX << " px";
   drawText( dc, s.str(), m_CursorX / 2, 0, TextAlignment::CenterTop );
   // Draw mouse Y
   s.str(""); s << m_CursorY << " px";
   drawText( dc, s.str(), 0, m_CursorY / 2, TextAlignment::LeftMiddle );

// RENDER PAINT-MODE: SELECT-RECT/DRAW-LINE

   if ( m_MouseClickLeft )
   {
      int x1 = std::min( m_CursorX, m_LastCursorX );
      int y1 = std::min( m_CursorY, m_LastCursorY );
      int x2 = std::max( m_CursorX, m_LastCursorX );
      int y2 = std::max( m_CursorY, m_LastCursorY );
      int w = x2 - x1;
      int h = y2 - y1;
      QRect r( x1, y1, w, h );

      // Draw cursor xy
      dc.setPen( QPen( Qt::white ) );
      s.str(""); s << "(" << m_CursorX << "," << m_CursorY << ")";
      drawText( dc, s.str(), m_CursorX + 5, m_CursorY + 5, TextAlignment::TopLeft );
      // Draw width
      s.str(""); s << w << " px";
      drawText( dc, s.str(), x1 + w / 2, 5, TextAlignment::TopCenter );
      // Draw height
      s.str(""); s << h << " px";
      drawText( dc, s.str(), 5, y1 + h / 2, TextAlignment::LeftMiddle );

//         // Draw mouse click X vertical line
//         dc.drawLine( x1, 0, x1, y1 - 1 );
//         // Draw mouse click Y horizontal line
//         dc.drawLine( 0, y1, x1 - 1, y1 );
//         // Draw mouse click X
//         dc.drawRect( r );
//         // Draw mouse pos drag-start XY
//         s.str(""); s << "(" << m_LastCursorX << "," << m_LastCursorY << ")";
//         drawText( dc, s.str(), m_LastCursorX - 5, m_LastCursorY - 5, TextAlignment::BottomRight );
//         // Draw x1
//         s.str(""); s << x1 << " px";
//         drawText( dc, s.str(), x1 / 2, 5, TextAlignment::CenterTop );
//         // Draw y1
//         s.str(""); s << y1 << " px";
//         drawText( dc, s.str(), 0, y1 / 2, TextAlignment::LeftMiddle );

      // Draw line angle
      // dc.setPen( QPen( QColor( 155,155,150,255 ) ) );
      // dc.drawEllipse( m_LastCursorX - 20, m_LastCursorY - 20, 40, 40 );

      dc.setPen( QPen( QBrush( m_LineColor ), qreal( m_LineWidth ) ) );
      if ( m_FillColor.alpha() < 1 )
      {
         dc.setBrush( Qt::NoBrush );
      }
      else
      {
         dc.setBrush( QBrush( m_FillColor ) );
      }

      if ( m_PaintMode == PaintMode::Point )
      {
         dc.drawEllipse( r.left(), r.top(), 3, 3 );
      }
      else if ( m_PaintMode == PaintMode::Line )
      {
         dc.drawLine( m_LastCursorX, m_LastCursorY, m_CursorX, m_CursorY );
      }
      else if ( m_PaintMode == PaintMode::LineStrip )
      {
         dc.drawLine( m_LastCursorX, m_LastCursorY, m_CursorX, m_CursorY );
      }
      else if ( m_PaintMode == PaintMode::Rect )
      {
         dc.drawRect( x1, y1, w, h );
      }
      else if ( m_PaintMode == PaintMode::Ellipse )
      {
         dc.drawEllipse( r );
      }
   }


//   // Draw Canvas border
//   dc.setPen( QPen( QColor( 255,255,255 ) ) );
//   dc.setBrush( Qt::NoBrush );
//   dc.drawRect( QRect( rect().topLeft(), rect().bottomRight() - QPoint(1,1) ) );

//   // Draw resize bar vertical
//   dc.setPen( QPen( QColor( 100,255,100 ) ) );
//   dc.setBrush( QBrush( QColor( 50,200,50 ) ) );
//   dc.drawRect( m_ResizeBarXRect );

//   // Draw (orange) image border
//   dc.setPen( QPen( QColor( 50,50,100 ) ) );
//   dc.setBrush( QBrush( QColor( 50,50,200 ) ) );
//   dc.drawRect( m_ResizeBarYRect );

   if ( m_IsResizingView )
   {
      QPen pen( Qt::white );
      pen.setStyle( Qt::DashLine );
      dc.setPen( pen );
      dc.setBrush( QBrush( Qt::NoBrush ) );
      dc.drawRect( 0,0, m_MouseX, m_MouseY );
   }

   // Draw bottom info string below PaintMode
   s.str(""); s <<
   "zoom(" << m_Zoom << ")"
   "scroll(" << m_ScrollX << "," << m_ScrollY << ")"
   "cursor(" << m_CursorX << "," << m_CursorY << "), "
   "mouse(" << m_MouseX << "," << m_MouseY << "), "
   "view(" << m_DstImage.width() << "," << m_DstImage.height() << "), "
   "img(" << m_SrcImage.width() << "," << m_SrcImage.height() << "), "
   "file(" << m_SrcFileName.toStdString() << ")";
   dc.setPen( QPen( Qt::white ) );
   drawText( dc, s.str(), width() / 2, height() - 10, TextAlignment::BottomCenter );

   // Draw current PaintMode:
   QFont const old_font = font();
   QFont h1_font( "fontawesome", 32, 75, true );
   dc.setFont( h1_font );
   drawText( dc, PaintMode::toString( m_PaintMode ), width() / 2, height() - 36, TextAlignment::BottomCenter );
   dc.setFont( old_font );

// DRAW_END:
   dc.end();
}

///////////////////////////////
/// --- Keyboard events --- ///
///////////////////////////////

void
Canvas::keyPressEvent( QKeyEvent* event )
{
   if ( event->key() == Qt::Key_Left )
   {
      on_move_cursor_left();
   }
   else if ( event->key() == Qt::Key_Right )
   {
      on_move_cursor_right();
   }
   else if ( event->key() == Qt::Key_Up )
   {
      on_move_cursor_up();
   }
   else if ( event->key() == Qt::Key_Down )
   {
      on_move_cursor_down();
   }
}

////////////////////////////////
/// --- MouseWheel event --- ///
////////////////////////////////

void
Canvas::wheelEvent( QWheelEvent * we )
{
#if OLD
   float e = static_cast< float >( we->delta() ) * 0.001f;
   int zoom_min = 1;
   int zoom_max = 513;

   if ( we->delta() >= 0 )
   {
      m_ZoomRectW+=2;
      m_ZoomRectH+=2;
      if ( m_ZoomRectW > zoom_max ) { m_ZoomRectW = zoom_max; }
      if ( m_ZoomRectH > zoom_max ) { m_ZoomRectH = zoom_max; }
      emit zoomChanged( m_ZoomRectW, m_ZoomRectH );
      update();
   }
   else
   {
      m_ZoomRectW-=2;
      m_ZoomRectH-=2;
      if ( m_ZoomRectW < zoom_min ) { m_ZoomRectW = zoom_min; }
      if ( m_ZoomRectH < zoom_min ) { m_ZoomRectH = zoom_min; }
      emit zoomChanged( m_ZoomRectW, m_ZoomRectH );
      update();
   }
#else
   float e = static_cast< float >( we->delta() ) * 0.1f;

   if ( std::signbit( e ) )
   {
      m_Zoom *= 2;
   }
   else
   {
      m_Zoom /= 2;
   }

   m_Zoom = std::clamp( m_Zoom, 25, 6400 );
   m_DstNeedsUpdate = true;
   updateDstImage();
#endif
}


void
Canvas::mouseMoveEvent( QMouseEvent * me )
{
   m_LastMouseX = m_MouseX;
   m_LastMouseY = m_MouseY;
   m_MouseX = me->x();
   m_MouseY = me->y();

   m_CursorX = m_MouseX;
   m_CursorY = m_MouseY;

   if ( m_CursorX >= m_SrcImage.width() )
   {
      m_CursorX = m_SrcImage.width() - 1;
   }

   if ( m_CursorY >= m_SrcImage.height() )
   {
      m_CursorY = m_SrcImage.height() - 1;
   }

   {
      std::stringstream s;
      s << "cursor(" << m_CursorX << "," << m_CursorY << "), ";
      s << "mouse(" << m_MouseX << "," << m_MouseY << ")";
      QString t = QString::fromStdString( s.str() );
      getMainWindow()->getStatusBar()->m_MouseInfo->setText( t );
   }
   {
      std::stringstream s;
      s << "canvas( w:" << width() << ", h:" << height() << " )";
      QString t = QString::fromStdString( s.str() );
      getMainWindow()->getStatusBar()->m_CanvasInfo->setText( t );
   }

   if ( isMouseOver( m_CursorX, m_CursorY, m_ResizeBarXRect ) )
   {
      m_IsOverResizeBarX = true;
   }
   else
   {
      m_IsOverResizeBarX =false;
   }

   if ( isMouseOver( m_CursorX, m_CursorY, m_ResizeBarYRect ) )
   {
      m_IsOverResizeBarY = true;
   }
   else
   {
      m_IsOverResizeBarY =false;
   }


   if ( me->buttons() & Qt::RightButton )
   {
      //int dx   = m_MouseX - me->globalX();
      //int dy   = m_MouseY - me->globalY();
      //m_MouseX = me->globalX();
      //m_MouseY = me->globalY();

      //tilt -= float( dy ) * 0.25f * api::Deg2Rad();
      //rota -= float( dx ) * 0.25f * api::Deg2Rad();
   }

   if ( me->buttons() & Qt::MiddleButton )
   {
      // vertical drag while holding middle button => smoother zoom than with mouse wheel
      //int dy = m_MouseY - me->globalY();
      //float32_t new_e = e - e * static_cast< float >( dy ) * 0.001f;

      //m_MouseX = me->globalX();
      //m_MouseY = me->globalY();
   }

   emit_cursorPosChanged();
   update();
}



void
Canvas::mousePressEvent( QMouseEvent * me )
{
   m_MouseX = me->x();
   m_MouseY = me->y();
   m_MouseClickX = m_MouseX;
   m_MouseClickY = m_MouseY;

   m_CursorX = me->x();
   m_CursorY = me->y();
   m_LastCursorX = me->x();
   m_LastCursorY = me->y();

   if ( me->button() == Qt::LeftButton )  {      m_MouseClickLeft = true; update(); }
   else if ( me->button() == Qt::RightButton ){  m_MouseClickRight = true; update(); }

   if ( isMouseOver( m_CursorX, m_CursorY, m_ResizeBarXRect ) )
   {
      m_IsResizingView = true;
      m_IsViewResizingX = true;
   }
   else if ( isMouseOver( m_CursorX, m_CursorY, m_ResizeBarYRect ) )
   {
      m_IsResizingView = true;
      m_IsViewResizingY = true;
   }

}

void
Canvas::mouseReleaseEvent( QMouseEvent * me )
{
   m_MouseReleaseX = me->x();
   m_MouseReleaseY = me->y();
   if ( me->button() == Qt::LeftButton )
   {
      m_MouseClickLeft = false;
      update();

      if ( m_IsResizingView )
      {
         qDebug() << "ResizeView(" << m_MouseReleaseX << "," << m_MouseReleaseY << ")";
         m_IsResizingView = false;
      }
      // Access real history over historyWidget
      //DrawCommandHistory* history = nullptr;

      //History* historyWidget = m_MainWindow->getHistory();
//      if ( historyWidget )
//      {
//         history = historyWidget->getDrawCommandHistory();
//      }

      // Add draw commands to history (undo/redo)
      History* history = m_MainWindow->getHistory();
      if ( history )
      {
         history->setLineWidth( 1.0f );
         history->setLineColor( m_LineColor );
         history->setFillColor( m_FillColor );
         if ( m_PaintMode == PaintMode::Point )
         {
            history->drawPoint( m_MouseClickX, m_MouseClickY );
         }
//         if ( m_PaintMode == PaintMode::Points )
//         {
//            history->drawPoints( m_MouseClickX, m_MouseClickY );
//         }
         if ( m_PaintMode == PaintMode::Line )
         {
            history->drawLine( m_MouseClickX, m_MouseClickY, m_MouseReleaseX, m_MouseReleaseY );
         }
         if ( m_PaintMode == PaintMode::LineStrip )
         {
            std::vector< Point2di > points;
            points.emplace_back( m_MouseClickX, m_MouseClickY );
            points.emplace_back( m_MouseReleaseX, m_MouseReleaseY );
            history->drawLineStrip( points );
         }
         if ( m_PaintMode == PaintMode::Rect )
         {
            history->drawRect( m_MouseClickX, m_MouseClickY, m_MouseReleaseX, m_MouseReleaseY );
         }
         if ( m_PaintMode == PaintMode::Ellipse )
         {
            history->drawEllipse( m_MouseClickX, m_MouseClickY, m_MouseReleaseX - m_MouseClickX, m_MouseReleaseY - m_MouseClickY );
         }
         if ( m_PaintMode == PaintMode::Text )
         {
            history->drawText( "Hello Text!", m_MouseClickX, m_MouseClickY );
         }
      }

   }
   else if ( me->button() == Qt::RightButton )
   {
      m_MouseClickRight = false;
      update();
   }
}

void
Canvas::mouseDoubleClickEvent( QMouseEvent * me )
{
   if ( me->buttons() & Qt::LeftButton )
   {

   }
}



void
Canvas::setZoom( int zoom )
{
   m_Zoom = zoom;
   m_DstNeedsUpdate = true;
   updateDstImage();
}

void
Canvas::on_zoom_view_enabled( bool enabled )
{
   m_ZoomViewEnabled = enabled; // show rect of zoom-view, or not.
   update();
}


void
Canvas::on_resizeX( int w )
{
   update();
}
void
Canvas::on_resizeY( int h )
{
   update();
}
void
Canvas::on_resizeXY( int w, int h )
{
   update();
}

void
Canvas::on_paintModeChanged( PaintMode::EPaintMode paintMode )
{
   m_PaintMode = paintMode;
   update();
}

void
Canvas::on_fillColorChanged( QColor fillColor )
{
   m_FillColor = fillColor;
   update();
}
void
Canvas::on_lineColorChanged( QColor lineColor )
{
   m_LineColor = lineColor;
   update();
}
void
Canvas::on_lineWidthChanged( float lineWidth )
{
   m_LineWidth = lineWidth;
   update();
}

void
Canvas::emit_cursorPosChanged()
{
//   if ( m_SrcImage.isNull()
//        || m_SrcImage.width() < 1
//        || m_SrcImage.height() < 1
//        || m_MouseX < 0
//        || m_MouseY < 0
//        || m_MouseX >= m_SrcImage.width()
//        || m_MouseY >= m_SrcImage.height() )
//   {
//      return;
//   }
   emit cursorPosChanged( m_MouseX, m_MouseY );
}

void
Canvas::on_move_cursor_left()
{
   qDebug() << "Paint." <<__FUNCTION__ << "()";
   m_MouseX--;
   emit_cursorPosChanged();
   update();
}

void
Canvas::on_move_cursor_right()
{
   qDebug() << "Paint." <<__FUNCTION__ << "()";
   m_MouseX++;
   emit_cursorPosChanged();
   update();
}

void
Canvas::on_move_cursor_down()
{
   qDebug() << "Paint." <<__FUNCTION__ << "()";
   m_MouseY++;
   emit_cursorPosChanged();
   update();
}

void
Canvas::on_move_cursor_up()
{
   qDebug() << "Paint." <<__FUNCTION__ << "()";
   m_MouseY--;
   emit_cursorPosChanged();
   update();
}


void
Canvas::onScreenshot()
{
   QScreen * screen = QGuiApplication::primaryScreen();
   if ( !screen ) return;
   auto shot = screen->grabWindow( this->winId() );

   QString     path = QDir::homePath() + "/";
   QFileDialog saveFileDialog( this, tr( "Save screenshot as ..." ), path );
   saveFileDialog.setAcceptMode( QFileDialog::AcceptSave );
   saveFileDialog.setFileMode( QFileDialog::AnyFile );
   saveFileDialog.selectMimeTypeFilter( "image/png" );
   saveFileDialog.setDefaultSuffix( "png" );

   if ( saveFileDialog.exec() != QDialog::Accepted ) return;

   QString name = saveFileDialog.selectedFiles().first();

   if ( !shot.save( name ) ) QMessageBox::warning( this, tr( "Save Error" ), tr( "The screenshot could not be saved!" ) );
}

