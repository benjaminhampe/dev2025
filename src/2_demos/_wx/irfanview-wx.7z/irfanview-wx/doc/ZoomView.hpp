#ifndef PAINT_ZoomView_HPP
#define PAINT_ZoomView_HPP

#include "CompileConfig.hpp"
#include <QWidget>

class ZoomView : public QWidget
{
   Q_OBJECT
public:
   ZoomView( QWidget * parent = nullptr );
   ~ZoomView() override;

   QImage const *
   getImage() const { return m_Image; }

   void
   setImage( QImage const * img ) { m_Image = img; }

public slots:
   void onCursor( int x, int y )
   {
      m_CursorX = x;
      m_CursorY = y;
      update();
   }

   void onZoom( int zoomWidthPx, int zoomHeightPx )
   {
      m_ZoomRectW = zoomWidthPx;
      m_ZoomRectH = zoomHeightPx;
      update();
   }


protected:
   void keyPressEvent( QKeyEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;
   void resizeEvent( QResizeEvent* event ) override;

private:
   QImage const * m_Image;
   int m_ZoomRectX;
   int m_ZoomRectY;
   int m_ZoomRectW;
   int m_ZoomRectH;
   int m_CursorX;
   int m_CursorY;

};

#endif
