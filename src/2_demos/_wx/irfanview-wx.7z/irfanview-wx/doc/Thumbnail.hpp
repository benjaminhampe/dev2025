#ifndef PAINT_QUI_THUMBNAIL_WIDGET_HPP
#define PAINT_QUI_THUMBNAIL_WIDGET_HPP

#include <CompileConfig.hpp>

class MainWindow;

class Thumbnail : public QWidget
{
   Q_OBJECT
public:
   Thumbnail( QWidget * parent = nullptr );
   ~Thumbnail() override;

   MainWindow* getMainWindow() { return m_MainWindow; }

   QImage const * getImage() const;
   void setImage( QImage const * img );

public slots:
   void onCursorPosChanged( int x, int y );

protected:
   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;

protected:
   void updateDisplayImage();


   MainWindow* m_MainWindow;

   QImage const * m_Image;
   QImage m_Display;

   bool m_RefreshDisplay;

   int m_CursorX;
   int m_CursorY;

   float m_ZoomRectX;
   float m_ZoomRectY;
   float m_ZoomRectW;
   float m_ZoomRectH;

   //bool m_DisplayUpdate;
};

#endif
