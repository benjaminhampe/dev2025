m_ribbon = new wxRibbonBar(this,-1,wxDefaultPosition, wxDefaultSize, wxRIBBON_BAR_FLOW_HORIZONTAL
                                | wxRIBBON_BAR_SHOW_PAGE_LABELS
                                | wxRIBBON_BAR_SHOW_PANEL_EXT_BUTTONS
                                | wxRIBBON_BAR_SHOW_TOGGLE_BUTTON
                                | wxRIBBON_BAR_SHOW_HELP_BUTTON
                                );

wxRibbonPage* home = new wxRibbonPage(m_ribbon, wxID_ANY, wxT("Examples"), ribbon_xpm);
wxRibbonPanel *toolbar_panel = new wxRibbonPanel(home, wxID_ANY, wxT("Toolbar"), 
                                   wxNullBitmap, wxDefaultPosition, wxDefaultSize, 
                                   wxRIBBON_PANEL_NO_AUTO_MINIMISE |
                                   wxRIBBON_PANEL_EXT_BUTTON);
                                   
wxRibbonToolBar *toolbar = new wxRibbonToolBar(toolbar_panel, ID_MAIN_TOOLBAR);
toolbar->AddToggleTool(wxID_JUSTIFY_LEFT, align_left_xpm);
toolbar->AddToggleTool(wxID_JUSTIFY_CENTER , align_center_xpm);
toolbar->AddToggleTool(wxID_JUSTIFY_RIGHT, align_right_xpm);
toolbar->AddSeparator();
toolbar->AddHybridTool(wxID_NEW, wxArtProvider::GetBitmap(wxART_NEW, wxART_OTHER, wxSize(16, 15)));
toolbar->AddTool(wxID_OPEN, wxArtProvider::GetBitmap(wxART_FILE_OPEN, wxART_OTHER, wxSize(16, 15)), "Open something");
toolbar->AddTool(wxID_SAVE, wxArtProvider::GetBitmap(wxART_FILE_SAVE, wxART_OTHER, wxSize(16, 15)), "Save something");
toolbar->AddTool(wxID_SAVEAS, wxArtProvider::GetBitmap(wxART_FILE_SAVE_AS, wxART_OTHER, wxSize(16, 15)), "Save something as ...");
toolbar->EnableTool(wxID_OPEN, false);
toolbar->EnableTool(wxID_SAVE, false);
toolbar->EnableTool(wxID_SAVEAS, false);
toolbar->AddSeparator();
toolbar->AddDropdownTool(wxID_UNDO, wxArtProvider::GetBitmap(wxART_UNDO, wxART_OTHER, wxSize(16, 15)));
toolbar->AddDropdownTool(wxID_REDO, wxArtProvider::GetBitmap(wxART_REDO, wxART_OTHER, wxSize(16, 15)));
toolbar->AddSeparator();
toolbar->AddTool(wxID_ANY, wxArtProvider::GetBitmap(wxART_REPORT_VIEW, wxART_OTHER, wxSize(16, 15)));
toolbar->AddTool(wxID_ANY, wxArtProvider::GetBitmap(wxART_LIST_VIEW, wxART_OTHER, wxSize(16, 15)));
toolbar->AddSeparator();
toolbar->AddHybridTool(ID_POSITION_LEFT, position_left_xpm, 
                       "Align ribbonbar vertically\non the left\nfor demonstration purposes");
toolbar->AddHybridTool(ID_POSITION_TOP, position_top_xpm, 
                       "Align the ribbonbar horizontally\nat the top\nfor demonstration purposes");
toolbar->AddSeparator();
toolbar->AddHybridTool(wxID_PRINT, wxArtProvider::GetBitmap(wxART_PRINT, wxART_OTHER, wxSize(16, 15)),
                       "This is the Print button tooltip\ndemonstrating a tooltip");
toolbar->SetRows(2, 3);

wxRibbonPanel *selection_panel = new wxRibbonPanel(home, wxID_ANY, wxT("Selection"), wxBitmap(selection_panel_xpm));
wxRibbonButtonBar *selection = new wxRibbonButtonBar(selection_panel);
selection->AddButton(ID_SELECTION_EXPAND_V, wxT("Expand Vertically"), wxBitmap(expand_selection_v_xpm),
                       "This is a tooltip for Expand Vertically\ndemonstrating a tooltip");
selection->AddButton(ID_SELECTION_EXPAND_H, wxT("Expand Horizontally"), wxBitmap(expand_selection_h_xpm), wxEmptyString);
selection->AddButton(ID_SELECTION_CONTRACT, wxT("Contract"), wxBitmap(auto_crop_selection_xpm), wxBitmap(auto_crop_selection_small_xpm));

wxRibbonPanel *shapes_panel = new wxRibbonPanel(home, wxID_ANY, wxT("Shapes"), wxBitmap(circle_small_xpm));
wxRibbonButtonBar *shapes = new wxRibbonButtonBar(shapes_panel);
shapes->AddButton(ID_CIRCLE, wxT("Circle"), wxBitmap(circle_xpm), wxBitmap(circle_small_xpm), 
                   wxNullBitmap, wxNullBitmap, wxRIBBON_BUTTON_NORMAL,
                   "This is a tooltip for the circle button\ndemonstrating another tooltip");
shapes->AddButton(ID_CROSS, wxT("Cross"), wxBitmap(cross_xpm), wxEmptyString);
shapes->AddHybridButton(ID_TRIANGLE, wxT("Triangle"), wxBitmap(triangle_xpm));
shapes->AddButton(ID_SQUARE, wxT("Square"), wxBitmap(square_xpm), wxEmptyString);
shapes->AddDropdownButton(ID_POLYGON, wxT("Other Polygon"), wxBitmap(hexagon_xpm), wxEmptyString);

wxRibbonPanel *sizer_panel = new wxRibbonPanel(home, wxID_ANY, wxT("Panel with Sizer"), 
                                           wxNullBitmap, wxDefaultPosition, wxDefaultSize, 
                                           wxRIBBON_PANEL_DEFAULT_STYLE);

wxArrayString as;
as.Add("Item 1 using a box sizer now");
as.Add("Item 2 using a box sizer now");
wxComboBox* sizer_panelcombo = new wxComboBox(sizer_panel, wxID_ANY, 
                                           wxEmptyString, 
                                           wxDefaultPosition, wxDefaultSize, 
                                           as, wxCB_READONLY);

wxComboBox* sizer_panelcombo2 = new wxComboBox(sizer_panel, wxID_ANY, 
                                           wxEmptyString, 
                                           wxDefaultPosition, wxDefaultSize, 
                                           as, wxCB_READONLY);

sizer_panelcombo->Select(0);
sizer_panelcombo2->Select(1);
sizer_panelcombo->SetMinSize(wxSize(150, -1));
sizer_panelcombo2->SetMinSize(wxSize(150, -1));

//not using wxWrapSizer(wxHORIZONTAL) as it reports an incorrect min height
wxSizer* sizer_panelsizer = new wxBoxSizer(wxVERTICAL);
sizer_panelsizer->AddStretchSpacer(1);
sizer_panelsizer->Add(sizer_panelcombo, 0, wxALL|wxEXPAND, 2);
sizer_panelsizer->Add(sizer_panelcombo2, 0, wxALL|wxEXPAND, 2);
sizer_panelsizer->AddStretchSpacer(1);
sizer_panel->SetSizer(sizer_panelsizer);

wxFont label_font(8, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_LIGHT);
m_bitmap_creation_dc.SetFont(label_font);

wxRibbonPage* scheme = new wxRibbonPage(m_ribbon, wxID_ANY, wxT("Appearance"), eye_xpm);
m_ribbon->GetArtProvider()->GetColourScheme(&m_default_primary,
   &m_default_secondary, &m_default_tertiary);
wxRibbonPanel *provider_panel = new wxRibbonPanel(scheme, wxID_ANY,
   wxT("Art"), wxNullBitmap, wxDefaultPosition, wxDefaultSize, wxRIBBON_PANEL_NO_AUTO_MINIMISE);
wxRibbonButtonBar *provider_bar = new wxRibbonButtonBar(provider_panel, wxID_ANY);
provider_bar->AddButton(ID_DEFAULT_PROVIDER, wxT("Default Provider"),
   wxArtProvider::GetBitmap(wxART_QUESTION, wxART_OTHER, wxSize(32, 32)));
provider_bar->AddButton(ID_AUI_PROVIDER, wxT("AUI Provider"), aui_style_xpm);
provider_bar->AddButton(ID_MSW_PROVIDER, wxT("MSW Provider"), msw_style_xpm);
wxRibbonPanel *primary_panel = new wxRibbonPanel(scheme, wxID_ANY,
   wxT("Primary Colour"), colours_xpm);
m_primary_gallery = PopulateColoursPanel(primary_panel,
   m_default_primary, ID_PRIMARY_COLOUR);
wxRibbonPanel *secondary_panel = new wxRibbonPanel(scheme, wxID_ANY,
   wxT("Secondary Colour"), colours_xpm);
m_secondary_gallery = PopulateColoursPanel(secondary_panel,
   m_default_secondary, ID_SECONDARY_COLOUR);
