#include "ZoomView.hpp"

ZoomView::ZoomView( QWidget * parent )
   : QWidget( parent )
   , m_Image( nullptr )
   , m_ZoomRectX( 0 ) // show 10 px in x direction.
   , m_ZoomRectY( 0 ) // show 20 px in y direction.
   , m_ZoomRectW( 11 ) // show 10 px in x direction.
   , m_ZoomRectH( 11 ) // show 20 px in y direction.
   , m_CursorX( 0 )
   , m_CursorY( 0 )
{
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 32, 32 );
   setMaximumSize( 4*128, 4*128 );
   setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Minimum );
}

ZoomView::~ZoomView()
{

}

void
ZoomView::resizeEvent( QResizeEvent* event )
{
   bool preserveImageAspect = false;

   if ( !preserveImageAspect )
   {
      setMinimumHeight( event->size().width() );
   }
   else
   {
      if ( m_Image )
      {
         int w = m_Image->width();
         int h = m_Image->height();
         float a = float( h ) / float( w );
         int ew = event->size().width();
         //int eh = event->size().height();
         setMinimumHeight( int( a * ew ) );
      }
   }
}

void
ZoomView::keyPressEvent( QKeyEvent* event )
{
   Q_UNUSED( event )
}

void
ZoomView::paintEvent( QPaintEvent* event )
{
   Q_UNUSED( event )

   if ( !isEnabled() )
   {
      QPainter dc;
      if ( dc.begin( this ) )
      {
         dc.setPen( QPen( Qt::lightGray, 3 ) );
         dc.setBrush( QBrush( Qt::gray ) );
         dc.drawRect( 0, 0, width(), height() );
         dc.drawLine( 0, 0, width() - 1, height() - 1 );
         dc.drawLine( 0, height() - 1, width() - 1, 0 );
      }
      return;
   }

   QPainter dc;
   if ( dc.begin( this ) )
   {
      dc.setBrush( Qt::NoBrush );

      if ( m_Image )
      {
//      if ( m_ZoomViewEnabled )
//      {
//         // Draw ZoomRect border
//         int zx = ( width() - m_ZoomRectW ) / 2;
//         int zy = ( height() - m_ZoomRectH ) / 2;
//         dc.setPen( QPen( QColor( 255,0,255,255 ) ) );
//         dc.drawRect( zx, zy, m_ZoomRectW, m_ZoomRectH );
//      }

         // Draws the widget, we extrapolate from image space ( this widget )
         // back to original space ( source m_Image ).
         // That is necessary to catch all pixels in image space.
         // Because its not a perfect biprojection in both directions.
         // Keine eineindeutige Abbildung.
         // Zoomen ist wie Skalieren/Rotation/Translat. mit ints/floats nicht eineindeutig.
         // Das ist also grundbedingt wegen der Diskretheit des Rechners.
         // Zooms a cut of image piece.
         int w = m_Image->width();
         int h = m_Image->height();
         //
         int rx = std::clamp( m_CursorX - m_ZoomRectW/2, 0, w - 1 );
         int ry = std::clamp( m_CursorY - m_ZoomRectH/2, 0, h - 1 );
         //
         for ( int j = 0; j < height(); ++j )
         {
            for ( int i = 0; i < width(); ++i )
            {
               int x = rx + int( float( m_ZoomRectW ) * float( i ) / float( width() - 1 ) );
               int y = ry + int( float( m_ZoomRectH ) * float( j ) / float( height() - 1 ) );
               if ( x >= 0 && x < w && y >= 0 && y < h )
               {
                  QColor color = m_Image->pixelColor( x, y );
                  dc.setPen( QPen( color ) );
                  dc.drawPoint( i, j );
               }
            }
         }
      }

      //      if ( m_ZoomViewEnabled )
      //      {
      // Draw ZoomRect border
      int zx = ( width() - m_ZoomRectW ) / 2;
      int zy = ( height() - m_ZoomRectH ) / 2;
      dc.setPen( QPen( QColor( 255,0,255,255 ) ) );
      dc.drawRect( zx, zy, m_ZoomRectW, m_ZoomRectH );
      //      }

      // Draw Text: ZoomRect
      {
         std::stringstream s;
         s << "zoomRect( w:" << m_ZoomRectW << ", h:" << m_ZoomRectH;
         s << ", x:" << m_ZoomRectX << ", y:" << m_ZoomRectY << " )";
         QString t = QString::fromStdString( s.str() );
         QSize ts = dc.fontMetrics().size( 0, t );
         dc.drawText( (width() - ts.width())/2, ts.height() + 2, t );
      }

      // Draw Text: MousePos
      {
         std::stringstream s;
         s << "cursor( x:" << m_CursorX << ", y:" << m_CursorY << " )";
         QString t = QString::fromStdString( s.str() );
         QSize ts = dc.fontMetrics().size( 0, t );
         dc.drawText( (width() - ts.width())/2, 2*ts.height() + 2, t );
      }

      // Draw Text: color
      if ( m_Image )
      {
         int w = m_Image->width();
         int h = m_Image->height();
         if ( w > 0 && h > 0
            && m_CursorX >= 0
            && m_CursorY >= 0
            && m_CursorX < w
            && m_CursorY < h )
         {
            QColor c = m_Image->pixelColor( m_CursorX, m_CursorY );
            {
               std::stringstream s;
               s << "0x" << std::hex << c.rgba();
               QString t = QString::fromStdString( s.str() );
               t = t.toUpper();
               QSize ts = dc.fontMetrics().size( 0, t );
               dc.drawText( (width() - ts.width())/2, height() - 5, t );
            }

            {
               std::stringstream s;
               if ( c.alpha() < 255 )
               {
                  s << "rgba(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
               }
               else
               {
                  s << "rgb(" << c.red() << "," << c.green() << "," << c.blue() << ")";
               }
               QString t = QString::fromStdString( s.str() );
               QSize ts = dc.fontMetrics().size( 0, t );
               dc.drawText( (width() - ts.width())/2, height() - 5 - ts.height(), t );
            }
   // Draw Zoom magnitude
            {
               std::stringstream s;
               float fx = float( w ) / float( m_ZoomRectW );
               float fy = float( h ) / float( m_ZoomRectH );
               s << "zoom(" << fx << "," << fy << ")";
               QString t = QString::fromStdString( s.str() );
               QSize ts = dc.fontMetrics().size( 0, t );
               dc.drawText( (width() - ts.width())/2, height() - 5 - 2 * ts.height(), t );
            }
         }
      }
      dc.end();
   }
}
