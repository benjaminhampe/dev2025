#ifndef PAINT_ZOOMBAR_HPP
#define PAINT_ZOOMBAR_HPP

#include "CompileConfig.hpp"
#include <QToolBar>
#include <QToolButton>
#include <QComboBox>
#include <fontawesome.hpp>

class ZoomBar : public QToolBar
{
   Q_OBJECT
public:
   ZoomBar( QWidget * parent = nullptr );
   ~ZoomBar() override;
signals:
   void zoomChanged( int zoom ); // 100 = 1
public slots:
   void onButton_zoomIn( bool ckecked );
   void onButton_zoomOut( bool ckecked );
   void onComboZoom( int );
private:
   QToolButton* m_ZoomOut;
   QComboBox* m_ZoomCombo;
   QToolButton* m_ZoomIn;
};

#endif
