#ifndef PAINT_CANVAS_HPP
#define PAINT_CANVAS_HPP

#include "DrawCommandList.hpp"

class MainWindow;
class ModeControl;
class History;

class Canvas : public QWidget
{
   Q_OBJECT
public:
   MainWindow* m_MainWindow;
   PaintMode::EPaintMode m_PaintMode;
   int m_Zoom; // 100 = 1
   int m_ResizeBorder; // 10px
   float m_ScrollX; // 0..99
   float m_ScrollY; // 0..99
   QString m_SrcFileName; // uri of source image
   QImage m_SrcImage; // source image
   QImage m_DstImage; // display image
   bool m_DstNeedsUpdate; // display image dirty flag

   QRect m_SrcRect;
   QRect m_DstRect;


   QColor m_FillColor;
   QColor m_LineColor;
   float m_LineWidth;

   QRect m_ResizeBarXRect;
   QRect m_ResizeBarYRect;
   bool m_IsOverResizeBarX = false;
   bool m_IsOverResizeBarY = false;

   bool m_ZoomViewEnabled;
   bool m_IsResizingView;
   bool m_IsViewResizingX;
   bool m_IsViewResizingY;

   int m_CursorX;
   int m_CursorY;
   int m_LastCursorX;
   int m_LastCursorY;

   int m_MouseX;
   int m_MouseY;
   int m_LastMouseX;
   int m_LastMouseY;

   int m_MouseClickX;
   int m_MouseClickY;
   int m_LastMouseClickX;
   int m_LastMouseClickY;

   int m_MouseReleaseX;
   int m_MouseReleaseY;

   bool m_MouseClickLeft;
   bool m_MouseClickRight;

   QColor m_CurrColor;

public:
   Canvas( QWidget * parent = nullptr );
   ~Canvas() override;

   MainWindow* getMainWindow() { return m_MainWindow; }
   QString const & getImageUri() const { return m_SrcFileName; }
   QImage const & getImage() const { return m_SrcImage; }

   void setImage( QImage const & img, QString const & uri = "Untitled2020.png" );
   void newImage( int w, int h );
   bool saveImage();
   bool saveImageAs( QString fileName );

signals:
   void viewRectChanged( int x, int y, int w, int h );
   void cursorSizeChanged( int w, int h );
   void cursorPosChanged( int x, int y );
   void zoomChanged( int w, int h );

public slots:
   // new
   void onScreenshot();
   void updateDstImage();
   void setScrollBarX( float scroll_x );
   void setScrollBarY( float scroll_y );

   // old
   void setZoom( int zoom );
   void on_resizeX( int w );
   void on_resizeY( int h );
   void on_resizeXY( int w, int h );

   void on_paintModeChanged( PaintMode::EPaintMode paintMode );
   void on_fillColorChanged( QColor fillColor );
   void on_lineColorChanged( QColor lineColor );
   void on_lineWidthChanged( float lineWidth );

   void emit_cursorPosChanged();
   void on_zoom_view_enabled( bool enabled );
   void on_move_cursor_left();
   void on_move_cursor_right();
   void on_move_cursor_up();
   void on_move_cursor_down();

protected:
   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void mouseMoveEvent( QMouseEvent * me ) override;
   void mousePressEvent( QMouseEvent * me ) override;
   void mouseReleaseEvent( QMouseEvent * me ) override;
   void mouseDoubleClickEvent( QMouseEvent * me ) override;
   void wheelEvent( QWheelEvent * we ) override;


};

#endif
