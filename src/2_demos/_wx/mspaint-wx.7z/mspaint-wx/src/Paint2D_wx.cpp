﻿#include "Paint2D_wx.hpp"

BEGIN_EVENT_TABLE(Paint2DWindow, wxFrame)
   EVT_CLOSE(Paint2DWindow::closeEvent)
   EVT_DROP_FILES(Paint2DWindow::dropFilesEvent)
   //EVT_SLIDER(id, func):
   EVT_MENU(MenuId_ABOUT, Paint2DWindow::onMenuHelpAbout)
   EVT_MENU(MenuId_QUIT, Paint2DWindow::onMenuFileExit)
   EVT_MENU(MenuId_OPEN, Paint2DWindow::onMenuFileOpen)
//   EVT_MENU(MenuId_SAVE, Paint2DWindow::OnSave)
//   EVT_MENU(MenuId_SAVE_AS, Paint2DWindow::OnSaveAs)
END_EVENT_TABLE()

// ===================================================================
Paint2DWindow::Paint2DWindow(
      wxWindow* parent, wxWindowID id, wxString const & title, 
      wxPoint const & pos, wxSize const & size, long style )
// ===================================================================
   : wxFrame(parent, id, title, pos, size, style)
   , m_MenuBar( nullptr )
   , m_MenuFile( nullptr )
   , m_MenuEdit( nullptr )
   , m_MenuView( nullptr )
   , m_MenuHelp( nullptr )
   , m_Canvas( nullptr )
{
   wxFont m_FontAwesome( 16, wxFONTFAMILY_UNKNOWN, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, _("fontawesome") );
   SetFont( m_FontAwesome );
   SetSize(800, 600);
   Center();
   DragAcceptFiles( true );
   // SetDoubleBuffered();
   // m_X->Bind( wxEVT_COMMAND_SPINCTRL_UPDATED, &wxImageCtrl::OnXChanged, this );
   //Connect(wxEVT_SIZE, wxSizeEventHandler(MySubScrolledWindow::OnSize));
   createMenuBar();
   createStatusBar();
   m_Canvas = new wxImageCtrl( _("swCanvas"), this, wxID_ANY );
   m_Canvas->SetMinSize( wxSize(256,256) );
   wxBoxSizer* v = new wxBoxSizer( wxVERTICAL );
   v->Add( m_Canvas, wxSizerFlags().Expand().Proportion(1) );
   SetSizerAndFit( v );
}

Paint2DWindow::~Paint2DWindow()
{
   DE_DEBUG("")
}

void Paint2DWindow::openFile( std::string uri )
{
   if ( uri.empty() ) { DE_ERROR("Empty uri") return; }
   DE_DEBUG("Opened image uri ",uri )
   //m_Canvas->setImage( m_File.m_CoverArt );
}

void Paint2DWindow::createStatusBar()
{
   CreateStatusBar(1);
   SetStatusText(_("Paint2D-wx (c) 2021 Benjamin Hampe <benjamin.hampe@gmx.de> | "),0);
}

void Paint2DWindow::createMenuBar()
{
   m_MenuBar = new wxMenuBar();
   m_MenuFile = new wxMenu(_T(""));
   m_MenuEdit = new wxMenu(_T(""));
   m_MenuView = new wxMenu(_T(""));
   m_MenuHelp = new wxMenu(_T(""));
   m_MenuFile->Append(MenuId_OPEN, _("&Load\tAlt-O"), _("Laden von Dateien und Projekten"));
   //m_actOpen->Bind wxEVT_COMMAND_BUTTON_CLICKED, &Paint2DWindow::onMenuFileOpen, this );
   //m_MenuFile->Append(MenuId_SAVE, _("&Save\tAlt-S"), _("Speichern von Dateien und Projekten"));
   //m_MenuFile->Append(MenuId_SAVE_AS, _("&Save As\tShift-Alt-S"), _("Speichern von Dateien und Projekten"));
   m_MenuFile->Append(MenuId_QUIT, _("&Exit VLC\tAlt-F4"), _("Programm beenden"));
   m_MenuHelp->Append(MenuId_ABOUT, _("&About\tF12"), _("Infos"));
   m_MenuBar->Append( m_MenuFile, _("&File"));
   m_MenuBar->Append( m_MenuEdit, _("&Edit"));
   m_MenuBar->Append( m_MenuView, _("&View"));
   m_MenuBar->Append( m_MenuHelp, _("&Help"));
   SetMenuBar( m_MenuBar );
}

void Paint2DWindow::dropFilesEvent( wxDropFilesEvent& event )
{
   int fileCount = event.GetNumberOfFiles();
   DE_DEBUG("FileCount = ", fileCount )
   for ( int i = 0; i < fileCount; ++i )
   {
      wxString const & uri = event.GetFiles()[ i ];
      DE_DEBUG("File[",i,"] ", uri.ToStdString() )
   }
   if ( fileCount > 0 )
   {
      std::string uri = event.GetFiles()[ 0 ].ToStdString();
      openFile( uri );
   }
}

void Paint2DWindow::closeEvent( wxCloseEvent & event )
{
   DE_DEBUG("")
   Destroy();
}

void Paint2DWindow::onMenuFileExit( wxCommandEvent & event )
{
   DE_DEBUG("")
   Destroy();
}

void Paint2DWindow::onMenuHelpAbout( wxCommandEvent & event )
{
   DE_DEBUG("")
   wxMessageBox( wxT("wxIrrlicht (c) 2008-2011 by BenjaminHampe@gmx.de\n\nVersion 1.0\n"), wxT("About"));
}

void Paint2DWindow::onMenuFileOpen( wxCommandEvent & event )
{
   wxFileDialog fileDialog( this );

   wxString uri;
   if ( fileDialog.ShowModal() == wxID_OK )
   {
      uri = fileDialog.GetPath();
   }

   openFile( uri.ToStdString() );
   event.Skip();
}

// ===================================================================
bool Paint2D_App::OnInit()
// ===================================================================
{
   wxInitAllImageHandlers();

   if ( !wxFont::AddPrivateFont( "fontawesome463.ttf" ) )
   {
      DEM_FATAL("No fontawesome463.ttf")
   }

  // Print CommandLine Commands wxCmdLineEntryDesc
  size_t c = sizeof(commands)/sizeof(commands[0])-1;

  wxString s = wxT("");
  for ( size_t i = 0; i < c; ++i )
  {
     s += wxString::Format(
     wxT("Option [%d]\t%s, %s, %s, %d, %d\n"),
     i,
     //commands[i].kind,
     commands[i].shortName,
     commands[i].longName,
     commands[i].description,
     commands[i].type,
     commands[i].flags);
  }

  std::cout << s.mb_str(wxConvUTF8) << std::endl;

  // Set CommandLine Parser
  wxCmdLineParser parser(commands, argc, argv);
  parser.SetDesc(commands);
  parser.SetLogo(wxT("Irrlicht2011"));
  parser.SetSwitchChars(wxT("-"));
  parser.Parse(false);

  // Parse CommandLine
  bool showHelp = parser.Found(wxT("h"));
  if (showHelp)
     wxMessageBox(s,wxT("wx-Irrlicht2011 CommandLineOptions"));

  // Print CommandLine Arguments
  for ( size_t i = 0; i < parser.GetParamCount(); ++i )
  {
     wxString p = parser.GetParam( i );
     wxLogMessage( p.c_str() );
     wxMessageBox( p, wxT("Param") + i );
  }

   // Create GUI
   Paint2DWindow* win = new Paint2DWindow(0L, wxID_ANY, wxT("Paint2D-wx"));
   win->SetIcon(wxICON(aaaa));
   win->Show();
   return true;
}

int Paint2D_App::OnExit()
{
   // clean up
   return 0;
}

int Paint2D_App::OnRun()
{
   int exitcode = wxApp::OnRun();
   if ( exitcode!=0 ) 
   {
      // error
   }
   return exitcode;
}
