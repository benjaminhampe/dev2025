#include "Paint2D_wx.hpp"

IMPLEMENT_APP(Paint2D_App);
