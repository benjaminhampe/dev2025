./GUILocaleFix.sh
xgettext src/*.h src/*.cpp src/HexEditorCtrl/*.cpp src/HexEditorCtrl/*.h  src/HexEditorCtrl/wxHexCtrl/*.cpp src/HexEditorCtrl/wxHexCtrl/*.h -C -k_ -o locale/wxHexEditor.pot
