# wxHexEditor
wxHexEditor official GIT repo
For info : http://www.wxhexeditor.org

# Compilation instructions
Just launch `make`!

# Compilation dependencies on Linux

- wxgtk;
