#include <fn_copyImageRect.hpp>
#include <fn_genImageNormalMap.hpp>

using namespace de;

int main(int argc, char** argv )
{
   int x = 0;
   int y = 0;
   int w = 0;
   int h = 0;
   std::string loadUri;
   std::string saveUri;

   if ( argc < 3 )
   {
      DE_DEBUG("[cutImage] Need atleast 2 user params: x y <w> <h> <in-file> <out-file>")
      return 0;
   }

   x = atol( argv[ 1 ] );
   y = atol( argv[ 2 ] );

   if ( argc > 3 )
   {
      w = atol( argv[ 3 ] );
   }

   if ( argc > 4 )
   {
      h = atol( argv[ 4 ] );
   }

   DE_DEBUG("[cutImage] Got x = ",x)
   DE_DEBUG("[cutImage] Got y = ",y)
   DE_DEBUG("[cutImage] Got w = ",w)
   DE_DEBUG("[cutImage] Got h = ",h)

   if ( argc > 5 )
   {
      loadUri = argv[ 5 ];
   }

   if ( !de::FileSystem::existFile( loadUri ) )
   {
      loadUri = dbOpenFileDlg( "Load image file (bmp,xpm,png,tga,jpg,tif,gif,dds,etc..)" );
   }

   if ( !de::FileSystem::existFile( loadUri ) )
   {
      DE_DEBUG("[cutImage] No loadUri ", loadUri )
      return 0;
   }

   DE_DEBUG("[cutImage] Got loadUri = ", loadUri )

   if ( argc > 6 )
   {
      saveUri = argv[ 6 ];
   }

   if ( saveUri.empty() )
   {
//      std::string caption, int x, int y, int w, int h,
//                     std::string filter,
//                     std::string initDir,
//                     std::string initFileName, bool newui)

      int dw = dbDesktopWidth() - 400;
      int dh = dbDesktopHeight() - 400;
      int dx = 200;
      int dy = 200;
      saveUri = dbSaveFileDlg("Save image (bmp,png,jpg,gif,tga,dds,tif)",
         dx,dy,dw,dh,
         "All Files (*.*)\0*.*\0", "", "",
         true );
      //            "Bitmap (*.bmp)\0*.bmp\0"
      //            "Portable Network Graphic (*.png)\0*.png\0"
      //            "JPEG (*.jpg)\0*.jpg\0"
      //            "Graphic interchange format (*.gif)\0*.gif\0"
      //            "TrueVision (*.tga)\0*.tga\0"
      //            "DDS (*.dds)\0*.dds\0"
      //            "Tif (*.tif)\0*.tif\0"
      //            "\0",
   }

   DE_DEBUG("[cutImage] Got saveUri = ",saveUri)

   de::PerformanceTimer perf;

   perf.start();
   de::Image img;
   bool ok = dbLoadImage( img, loadUri );
   perf.stop();

   DE_DEBUG("[cutImage] LoadImage needed ",perf.ms()," ms, loadUri = ",loadUri)

   if ( !ok )
   {
      DE_ERROR("[cutImage] Cant load image. Nothing todo.")
      return 0;
   }

   perf.start();
   Image subImage = copyImageRect( img, Recti(x,y,w,h) );
   perf.stop();

   DE_DEBUG("[cutImage] CopyImage needed ",perf.us()," us.")

   perf.start();
   ok = dbSaveImage( subImage, saveUri );
   perf.stop();

   DE_DEBUG("[cutImage] SaveImage needed ",perf.ms()," ms, saveUri = ",saveUri)

   if ( !ok )
   {
      DE_ERROR("[cutImage] Cant save image.")
   }
   return 0;
}
