//////////////////////////////////////////////////////////////////////
/// @file 	Logger.hpp
/// @author Copyright (c) Benjamin Hampe <benjaminhampe@gmx.de>
///
/// No guarantees given whatsover!
///
/// The author grants permission of free use, free distribution and
/// free usage for commercial applications even for modified sources.
//////////////////////////////////////////////////////////////////////

#pragma once
#include <cstdint>
#include <sstream>
#include <thread>
#include <de/StringUtil.hpp>

#ifndef USE_DE_LOGGING
#define USE_DE_LOGGING
#endif

namespace de {
    /// Since ANSI standard exists only 50yrs (1970!) its to few time for MS to implement it.
    /// cmd.exe is not an ANSI console. AND
    /// cmd.exe is nothing i would use and call myself a professional at the same time.
    /// On Windows64 use the ANSI terminal in git4windows setup (based on MSYS2) or ConEmu64.
    /// On Linux just open a terminal and be happy.
    /// On Mac good luck, but i heard its a Linux ripoff
    /// On Android good luck, but i heard its a Linux ripoff aswell.

    /// @brief Write ANSI terminal/console color reset marker.
    inline std::string
    Terminal_reset_colors()
    {
        return "\033[0m";
    }

    /// @brief Write ANSI terminal/console color RGB marker. Foreground + Background colors.
    inline std::string
    Terminal_set_colors( uint8_t fr, uint8_t fg, uint8_t fb, uint8_t br, uint8_t bg, uint8_t bb )
    {
        // The (int) casts are necessary to print decimals and not secret control message hex bytes.
        std::ostringstream o; o <<
            "\033[38;2;" << int(fr) << ";" << int(fg) << ";" << int(fb) << "m"
                                                                           "\033[48;2;" << int(br) << ";" << int(bg) << ";" << int(bb) << "m";
        return o.str();
    }

    // ===========================================================================
    struct LogLevel
    // ===========================================================================
    {
       enum ELevel
       {
            None = 0,
            Trace,
            Debug,
            Ok,
            Benni,
            Info,
            Warn,
            Error,
            Fatal,
            Count
       };
       ELevel m_Level = None;
       LogLevel( ELevel logLevel ) : m_Level(logLevel) {}
       operator uint32_t() const { return m_Level; }
       void setLevel( ELevel logLevel ) { m_Level = logLevel; }
       ELevel getLevel() const { return m_Level; }
    };


    // ===========================================================================
    // ===   LogMacros
    // ===========================================================================

    template< typename ... T >
    std::string Logger_join( T const & ... t )
    {
       std::ostringstream s;
       (void)std::initializer_list<int>{ (s<<t, 0)... };
       return s.str();
    }

    template< typename ... T >
    std::wstring Logger_joinW( T const & ... t )
    {
        std::wostringstream s;
        (void)std::initializer_list<int>{ (s<<t, 0)... };
        return s.str();
    }

}



void
dbLogMessage(  int logLevel, // 0=Trace, 1=Debug, 2=Ok, 3=Benni, 4=Info, 5=Warn, 6=Error, 7=Fatal
               const std::string& msg,
               const std::string& file, // = "DeineMutter.cpp",
               int line, // = 666,
               const std::string& func, // = "knatscheln",
               std::thread::id threadId = std::this_thread::get_id() );

// Legacy -> nop
#ifndef DE_CREATE_LOGGER
#define DE_CREATE_LOGGER(x)
#endif

#ifndef DE_OK
#define DE_OK(...) {  dbLogMessage(     de::LogLevel::Ok, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
#ifndef DE_BENNI
#define DE_BENNI(...) {  dbLogMessage(  de::LogLevel::Benni, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
#ifndef DE_INFO
#define DE_INFO(...) {  dbLogMessage(   de::LogLevel::Info, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
#ifndef DE_WARN
#define DE_WARN(...) {  dbLogMessage(   de::LogLevel::Warn, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
#ifndef DE_ERROR
#define DE_ERROR(...) {  dbLogMessage(  de::LogLevel::Error, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
#ifndef DE_DEBUG
#define DE_DEBUG(...) {  dbLogMessage(  de::LogLevel::Debug, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
#ifndef DE_TRACE
#define DE_TRACE(...) {  dbLogMessage(  de::LogLevel::Trace, \
                                        de::Logger_join( __VA_ARGS__ ), \
                                        __FILE__, __LINE__, __func__, \
                                        std::this_thread::get_id() ); }
#endif
