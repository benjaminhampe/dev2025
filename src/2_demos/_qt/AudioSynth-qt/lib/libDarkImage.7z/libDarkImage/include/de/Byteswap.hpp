#ifndef DE_OS_BYTESWAP_HPP
#define DE_OS_BYTESWAP_HPP

#include <cstdint>
//#include <cstdlib>
//#include <cstdio>
//#include <cstring>

namespace de
{
	// class Byteswap
	// {
	// public:
		// static u16 byteswap(u16 num);
		// static s16 byteswap(s16 num);
		// static u32 byteswap(u32 num);
		// static s32 byteswap(s32 num);
		// static f32 byteswap(f32 num);
		// // prevent accidental swapping of chars
		// static u8  byteswap(u8  num);
		// static c8  byteswap(c8  num);
	// };

} // end namespace de

#endif
