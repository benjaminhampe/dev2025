#include <de/Logger.hpp>
// #include <de/Timer.hpp>
// #include <de/StringUtil.hpp>
#include <de/FileSystem.hpp>

#include <chrono>
#include <array>
#include <filesystem>
#include <fstream>

#include <locale>
#include <string>
#include <codecvt>

#include <algorithm>
#include <cctype>
//#include <locale>
//#include <string>

namespace {

int64_t dbTimeInNanoseconds()
{
    typedef std::chrono::steady_clock Clock_t; // high_resolution_clock Clock_t;
    auto dur = Clock_t::now() - Clock_t::time_point(); // now - epoch = dur
    return std::chrono::duration_cast< std::chrono::nanoseconds >( dur ).count();
}

int64_t dbTimeInMicroseconds()
{
    return dbTimeInNanoseconds() / 1000;
}

int32_t dbTimeInMilliseconds()
{
    return static_cast<int32_t>( dbTimeInNanoseconds() / 1000000 );
}

double dbTimeInSeconds()
{
    return static_cast<double>( dbTimeInNanoseconds() ) * 1e-9;
}

void dbRandomize()
{
    ::srand( static_cast<uint32_t>(dbTimeInMilliseconds()) );
}

int32_t dbRND()
{
    return ::rand();
}

}

// ===========================================================================
void dbLogMessage( int logLevel, const std::string& msg,
        const std::string& file, int line, const std::string& func,
        std::thread::id threadId )
// ===========================================================================
{
    static double g_lineCount = 0;
    g_lineCount++;

    static double m_TimeStart = dbTimeInSeconds();
    double m_Time = dbTimeInSeconds() - m_TimeStart;

    const size_t BUFFER_SIZE = 32;
    char txt_time[BUFFER_SIZE];
    snprintf(txt_time, BUFFER_SIZE, "%.8lf", m_Time );

    std::ostringstream o;
    //de::Terminal_set_colors(150,155,155, 200,150,30)

    o << de::Terminal_reset_colors() << g_lineCount;
    // if (g_lineCount < 10) o << " ";
    // if (g_lineCount < 100) o << " ";
    // if (g_lineCount < 1000) o << " ";
    // if (g_lineCount < 10000) o << " ";
    o <<" [" << txt_time << "] [" << threadId << "] ";

    switch( logLevel )
    {
    case de::LogLevel::Trace: o << de::Terminal_set_colors(255,255,255, 200,100,200) << "[Trace]"; break;
    case de::LogLevel::Debug: o << de::Terminal_set_colors(205,205,205, 220,100,220) << "[Debug]"; break;
    case de::LogLevel::Ok:    o << de::Terminal_set_colors(255,255,255, 0,120,20) << "[Ok]"; break;
    case de::LogLevel::Benni: o << de::Terminal_set_colors(0,20,160, 255,255,255) << "[Benni]"; break;
    case de::LogLevel::Info:  o << "[Info]"; break;
    case de::LogLevel::Warn:  o << de::Terminal_set_colors(0,0,0, 255,255,0) << "[Warn]"; break;
    case de::LogLevel::Error: o << de::Terminal_set_colors(255,255,255, 255,0,0) << "[Error]"; break;
    case de::LogLevel::Fatal: o << de::Terminal_set_colors(255,255,255, 255,0,100) << "[Fatal]"; break;
    default:                  o << "[Unknown]"; break;
    }

    o << " " << de::FileSystem::fileName(file) << ":" << line
      << " " << func << "() :: " << msg << " "
      << de::Terminal_reset_colors() << " " << de::Terminal_reset_colors() ;

    printf( "%s\n", o.str().c_str() ); // Actual logging
    fflush(stdout);

    //if ( flush ) { fflush(stdout); }
}
