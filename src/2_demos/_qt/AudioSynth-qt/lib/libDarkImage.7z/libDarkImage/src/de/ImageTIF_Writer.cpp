#include "ImageTIF_Writer.hpp"

#ifdef DE_IMAGE_WRITER_TIF_ENABLED

// #include <de/File.hpp>
// #include <sstream>

namespace de {
namespace image {

bool
ImageWriterTIF::save( Image const & img, std::string const & uri, uint32_t quality )
{

   return false;
}

} // end namespace image.
} // end namespace de.

#endif // DE_IMAGE_WRITER_TIF_ENABLED


