// Copyright (C) 2019, Benjamin Hampe
#ifndef DE_IMAGE_PPM_HPP
#define DE_IMAGE_PPM_HPP

#include <de/Image.hpp>

#ifdef DE_IMAGE_CODEC_PPM_ENABLED

namespace de {
namespace image {

} // end namespace image.
} // end namespace de.

#endif // DE_IMAGE_CODEC_PPM_ENABLED

#endif // DE_IMAGE_PPM_HPP
