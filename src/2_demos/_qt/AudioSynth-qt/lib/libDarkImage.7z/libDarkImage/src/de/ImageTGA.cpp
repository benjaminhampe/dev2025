#include "ImageTGA.hpp"

#if defined(DE_IMAGE_READER_TGA_ENABLED) || defined(DE_IMAGE_WRITER_TGA_ENABLED)

namespace de {
namespace image {
namespace tga {

   // ...

} // end namespace tga.
} // end namespace image.
} // end namespace de.

#endif // DE_IMAGE_CODEC_TGA_ENABLED
