#include <de/gpu/MeshBuffer.hpp>
#include <de/gpu/GLESv3_BufferTools.hpp>

namespace de {
namespace gpu {

/// @brief Constructor
SMeshBuffer::SMeshBuffer( PrimitiveType::EType primType )
   : TMeshBuffer< S3DVertex >( primType )
{
   // DE_DEBUG(getName())
}

SMeshBuffer::~SMeshBuffer()
{
   //DE_DEBUG(getName())
   destroy();
}

bool
SMeshBuffer::upload( int mode )
{
   return BufferTools::upload(
      #ifdef USE_GPU_BUFFER_CALLER
      getName(),
      #endif
      getVBO(), getIBO(), getVAO(),
      getPrimitiveType(), getVertices(), getVertexCount(), getFVF(),
      getIndices(), getIndexCount(), getIndexType() );
}

void
SMeshBuffer::destroy()
{
   BufferTools::destroy(
      #ifdef USE_GPU_BUFFER_CALLER
      getName(),
      #endif
      getVBO(), getIBO(), getVAO() );
}

void
SMeshBuffer::draw( int mode )
{
   if ( mode == 0 )
   {
      BufferTools::drawImmediate(
         #ifdef USE_GPU_BUFFER_CALLER
         getName(),
         #endif
         getPrimitiveType(), getVertices(), getVertexCount(), getFVF(),
         getIndices(), getIndexCount(), getIndexType() );
   }
   else
   {
      BufferTools::draw(
#ifdef USE_GPU_BUFFER_CALLER
         getName(),
#endif
         getVBO(),
         getIBO(),
         getVAO(),
         getPrimitiveType(),
         getVertices(),
         getVertexCount(),
         getFVF(),
         getIndices(),
         getIndexCount(),
         getIndexType() );
   }
}

} // end namespace gpu.
} // end namespace de.
