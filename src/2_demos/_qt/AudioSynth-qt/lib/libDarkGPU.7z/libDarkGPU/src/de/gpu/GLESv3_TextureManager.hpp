#pragma once
#include <de/gpu/State.hpp>
#include <de/gpu/ITextureManager.hpp>

// #include <DarkImage.hpp>
// #include <cstdint>
// #include <functional>
// #include <sstream>

namespace de {
namespace gpu {

// ===========================================================================
struct TexManager : public ITexManager
// ===========================================================================
{
   DE_CREATE_LOGGER("de.gpu.TexManager")
   // ###   HwTexUnitManager    ###
   std::vector< uint32_t > m_TexUnits; // Physical avail texture Units
   // ###   TexManager   ###
   std::vector< Tex* > m_Textures; // All big memory pages ( atlas textures )
   std::vector< Tex* > m_TexturesToRemove;   // All textures that exist
   std::unordered_map< std::string, TexRef > m_refs; // has indices into m_Textures.
   // ###   RefManager   ###
   //std::vector< TexRef > m_Refs;    // All small textures we can use
   //std::unordered_map< std::string, int > m_RefLUT; // has indices into m_TexRefs
public:
   TexManager();
   ~TexManager() override;
   void init() override;
   void dump() override;

   TexRef getTexture2D( S const & name, SO const & so = SO(), bool keepImage = false ) override;
   TexRef createTexture2D( S const & name, Image const & img, SO so = SO(), bool keepImage = false ) override;
   bool upload( Tex* tex, Image const & src ) override;
   void clearTextures() override;
   void updateTextures() override;
   void removeTexture( Tex* tex ) override;
   void removeTexture( std::string const & key ) override;
   // int32_t findTex( Tex* tex ) const override;
   // int32_t findTex( std::string const & name ) const override;
   // bool hasTex( std::string const & name ) const override;
   // TexRef getTex( std::string const & name ) const override;
   // TexRef load2D( std::string const & name, std::string uri, bool keepImage = true, SO so = SO() ) override;
   // TexRef add2D( std::string const & name, Image const & img, bool keepImage = true, SO so = SO() ) override;

   Tex*
   findTexture( S const & name ) const override
   {
      return nullptr;
   }

   bool
   has( S const & name ) const override
   {
      auto it = m_refs.find( name ); // Find 'name' in cache
      if (it == m_refs.end()) // Cache miss => try load ( every time, yet )
      {
         return false;
      }
      else
      {
         return true;
      }
   }
   // ###   HwTexUnitManager    ###
   uint32_t getUnitCount() const override;
   int32_t findUnit( uint32_t texId ) const override;
   bool bindTexture2D( int stage, uint32_t texId ) override;// ###   OpenGL id   ###
   bool unbindTexture2D( uint32_t texId ) override;// ###   OpenGL id   ###
   int bindTexture2D( uint32_t texId ) override;// ###   OpenGL id   ### AutoSelect a free tex unit and return its index for use in setSamplerUniform().
   bool bindTexture( int stage, Tex* tex ) override;// ###   class Tex   ###
   bool unbindTexture( Tex* tex ) override;// ###   class Tex   ###
   int bindTexture( Tex* tex ) override;// ###   class Tex  with more intelligence.  ###
};


} // end namespace gpu.
} // end namespace de.
