#include <de/gpu/GLESv3_BufferTools.hpp>
#include <de/gpu/GLES.hpp>

namespace de {
namespace gpu {

// ===========================================================================
// FVFUtils GLESv3
// ===========================================================================
uint32_t
BufferTools::fromPrimitiveType( PrimitiveType::EType const primType )
{
   switch ( primType )
   {
      case PrimitiveType::Points: return GL_POINTS;
      case PrimitiveType::Lines: return GL_LINES;
      case PrimitiveType::LineStrip: return GL_LINE_STRIP;
      case PrimitiveType::LineLoop: return GL_LINE_LOOP;
      case PrimitiveType::Triangles: return GL_TRIANGLES;
      case PrimitiveType::TriangleStrip: return GL_TRIANGLE_STRIP;
      case PrimitiveType::TriangleFan: return GL_TRIANGLE_FAN;
      default: return GL_POINTS;
   }
}

PrimitiveType::EType
BufferTools::toPrimitiveType( uint32_t const primType )
{
   switch ( primType )
   {
      case GL_POINTS: return PrimitiveType::Points;
      case GL_LINES: return PrimitiveType::Lines;
      case GL_LINE_STRIP: return PrimitiveType::LineStrip;
      case GL_LINE_LOOP: return PrimitiveType::LineLoop;
      case GL_TRIANGLES: return PrimitiveType::Triangles;
      case GL_TRIANGLE_STRIP: return PrimitiveType::TriangleStrip;
      case GL_TRIANGLE_FAN: return PrimitiveType::TriangleFan;
      default: return PrimitiveType::Points;
   }
}
uint32_t
BufferTools::fromIndexType( IndexType::EType const indexType )
{
   switch ( indexType )
   {
      case IndexType::U8: return GL_UNSIGNED_BYTE;
      case IndexType::U16: return GL_UNSIGNED_SHORT;
      case IndexType::U32: return GL_UNSIGNED_INT;
      default: assert( false ); return 0;
   }
}

VertexAttribType::EType
BufferTools::toVertexAttribType( uint32_t type )
{
   switch( type )
   {
      case GL_FLOAT: return VertexAttribType::F32;
      case GL_BYTE: return VertexAttribType::S8;
      case GL_SHORT: return VertexAttribType::S16;
      case GL_INT: return VertexAttribType::S32;
      case GL_UNSIGNED_BYTE: return VertexAttribType::U8;
      case GL_UNSIGNED_SHORT: return VertexAttribType::U16;
      case GL_UNSIGNED_INT: return VertexAttribType::U32;
      default: { assert( false );
         return VertexAttribType::ETypeMax;
      }
   }
}

uint32_t
BufferTools::fromVertexAttribType( VertexAttribType::EType type )
{
   switch( type )
   {
      case VertexAttribType::F32: return GL_FLOAT;
      case VertexAttribType::S8: return GL_BYTE;
      case VertexAttribType::S16: return GL_SHORT;
      case VertexAttribType::S32: return GL_INT;
      case VertexAttribType::U8: return GL_UNSIGNED_BYTE;
      case VertexAttribType::U16: return GL_UNSIGNED_SHORT;
      case VertexAttribType::U32: return GL_UNSIGNED_INT;
      default: { assert( false );
         return 0;
      }
   }
}

bool
BufferTools::enableFVF( FVF const & fvf, uint8_t const* vertices )
{
   if ( !vertices ) { return false; }
   GLuint k = 0;
   // loop vertex attributes
   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & a = fvf.m_Data[ i ];
      if ( !a.m_Enabled ) continue;
      GLint const aCount = GLint( a.m_Count );
      GLenum const aType = fromVertexAttribType( a.m_Type );
      GLsizei const aStride = GLsizei( fvf.m_Stride );
      GLboolean const bAutoNorm = a.m_Normalize ? GL_TRUE : GL_FALSE;
      ::glEnableVertexAttribArray( k ); GPU_BUFFER_VALIDATE
      ::glVertexAttribPointer( k, aCount, aType, bAutoNorm, aStride, vertices ); GPU_BUFFER_VALIDATE
      vertices += a.m_ByteSize; // next attribute.
      k++;
   }

   return true;
}

bool BufferTools::disableFVF( FVF const & fvf )
{
   GLuint k = 0;
   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & a = fvf.m_Data[ i ];
      if ( !a.m_Enabled ) continue;
      ::glDisableVertexAttribArray( GLuint( i ) ); GPU_BUFFER_VALIDATE
      k++;
   }
   return true;
}


bool
BufferTools::drawPrimitiveList(
   #ifdef USE_GPU_BUFFER_CALLER
   std::string const & caller,
   #endif
   IMeshBuffer const & buf )
{
   return drawPrimitiveList(
      #ifdef USE_GPU_BUFFER_CALLER
      __func__,
      #endif
      buf.getPrimitiveType(),
      buf.getVertices(),
      buf.getVertexCount(),
      buf.getFVF(),
      buf.getIndices(),
      buf.getIndexCount(),
      buf.getIndexType() );
}

bool
BufferTools::drawPrimitiveList(
   #ifdef USE_GPU_BUFFER_CALLER
   std::string const & caller,
   #endif
   PrimitiveType::EType primType,
   void const* vertices,
   uint32_t vCount,
   FVF const & fvf,
   void const* indices,
   uint32_t indexCount,
   IndexType::EType indexType,
   bool debug )
{
   if ( !vertices ) { return false; } // DE_DEBUG( "No vertices. caller(",caller,")" )
   if ( vCount < 1 ) { return false; } // DE_DEBUG( "Empty vertices. caller(",caller,")" )
   if ( indexCount > 0 && !indices ) { return false; } // DE_ERROR( "Invalid indices. caller(",caller,")" )

   #ifdef USE_GPU_BUFFER_DEBUG
   if ( debug )
   {
      uint32_t nPrim = PrimitiveType::getPrimitiveCount( primType, vCount, indexCount );
      size_t bytes_v = size_t( fvf.getByteSize() ) * vCount;
      size_t bytes_i = size_t( IndexType::getIndexSize( indexType ) ) * indexCount;
      size_t bytes = bytes_v + bytes_i;
      DE_DEBUG( caller," with ", nPrim,
         " ", PrimitiveType::getString( primType ),", "
         "v:",vCount,", ",
         "i:",indexCount,"|",IndexType::getString( indexType ), ", "
         "fvf:", fvf.getByteSize(), ", "
         "siz:", bytes
      )
   }
   #else
   (void)debug;
   #endif

   bool ok = enableFVF( fvf, (uint8_t const* )vertices );
   if ( ok )
   {
      if ( indexCount > 0 )
      {
         ::glDrawElements( GLenum( fromPrimitiveType( primType ) ),
                           GLsizei( indexCount ),
                           GLenum( fromIndexType( indexType ) ),
                           indices );
      }
      else
      {
         ::glDrawArrays( GLenum( fromPrimitiveType( primType ) ),
                         0,
                         GLsizei( vCount ) );
      }
      GPU_BUFFER_VALIDATE
      disableFVF( fvf );
      return true;
   }
   else
   {
      return false;
   }
}


// ====== VBO ==========================================

void
BufferTools::destroyVBO( uint32_t & vbo )
{
   if ( vbo < 1 ) { return; }
   GLuint id = vbo;
   ::glDeleteBuffers( 1, &id );
   GPU_BUFFER_VALIDATE
   vbo = 0;
}

bool
BufferTools::createVBO( uint32_t & vbo )
{
   if ( vbo > 0 ) { return true; } // Nothing todo, already created.
   GLuint id = vbo;
   ::glGenBuffers( 1, &id );
   GPU_BUFFER_VALIDATE
   bool ok = id != 0; // Was buffer created?
   if ( ok ) { vbo = id; }
   else      { vbo = 0; }
   return ok;
}

// ====== IBO ==========================================
void
BufferTools::destroyIBO( uint32_t & ibo )
{
   destroyVBO( ibo );

//   if ( ibo < 1 ) { return; }
//   GLuint id = 0;
//   ::glDeleteBuffers( 1, &id );
//   GPU_BUFFER_VALIDATE
//   ibo = id;
}

bool
BufferTools::createIBO( uint32_t & ibo )
{
   return createVBO( ibo );

//   if ( ibo > 0 ) { return true; } // Nothing todo
//   GLuint id = 0;
//   ::glGenBuffers( 1, &id );
//   GPU_BUFFER_VALIDATE
//   bool const ok = ( id != 0 ); // Was buffer created?
//   if ( ok ) { ibo = id; }
//   else      { ibo = 0; }
//   return ok;
}

// ====== VAO ==========================================
void
BufferTools::destroyVAO( uint32_t & vao )
{
   if ( vao < 1 ) { return; }
   GLuint id = vao;
   ::glDeleteVertexArrays( 1, &id );
   GPU_BUFFER_VALIDATE
   vao = 0;
}

bool
BufferTools::createVAO( uint32_t & vao )
{
   if ( vao != 0 ) { return true; }
   GLuint id = 0;
   ::glGenVertexArrays( 1, &id );
   GPU_BUFFER_VALIDATE
   if ( id == 0 ) { vao = 0; return false; }
   else { vao = id; return true; }
}

void
BufferTools::destroy(
   #ifdef USE_GPU_BUFFER_CALLER
   std::string const & caller,
   #endif
   uint32_t & vbo,
   uint32_t & ibo,
   uint32_t & vao )
{
   // Nothing todo, since no gpu buffer was used.
   // Immediate mode uploads CPU side right before rendering
   // and then nothing needs to be cleaned up on GPU side, CPU mesh stays constant.
   // No gpu buffer ids have to managed or carried around.
   destroyVBO( vbo );
   destroyIBO( ibo );
   destroyVAO( vao );
}

// Setup
// unsigned int cubeVAO, cubeVBO, cubeIBO;
// VBO - Since OpenGL ES 2.0 ( we love it, it means we store a mesh on graphics card memory GDDR5 )
// glGenBuffers(1, &cubeVBO);
// glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
// glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), &cubeVertices, GL_STATIC_DRAW);
// IBO - Since OpenGL ES 2.0 ( we love it, it means we store a mesh on graphics card memory GDDR5 )
// glGenBuffers(1, &cubeIBO);
// glBindBuffer(GL_ARRAY_BUFFER, cubeIBO);
// glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cubeIndices), &cubeIndices, GL_STATIC_DRAW);
// VAO
// glGenVertexArrays(1, &cubeVAO);
// glBindVertexArray(cubeVAO);
// glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
// glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeIBO);
// glEnableVertexAttribArray(0);
// glEnableVertexAttribArray(1);
// glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
// glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));

bool
BufferTools::upload(
   #ifdef USE_GPU_BUFFER_CALLER
   std::string const & caller,
   #endif
   uint32_t & vbo,
   uint32_t & ibo,
   uint32_t & vao,
   PrimitiveType::EType /*primType */,
   void const* vertices,
   uint32_t vCount,
   FVF const & fvf,
   void const* indices,
   uint32_t iCount,
   IndexType::EType indexType )
{
   //=======
   // Setup
   //=======
   if ( !vertices ) { return false; }
   if ( vCount < 1 ) { return false; }
   bool useIndices = indices && iCount > 0;
   // RestorePoint
   GLint vao1 = 0; ::glGetIntegerv( GL_VERTEX_ARRAY_BINDING, &vao1 ); GPU_BUFFER_VALIDATE
   GLint vbo1 = 0; ::glGetIntegerv( GL_ARRAY_BUFFER_BINDING, &vbo1 ); GPU_BUFFER_VALIDATE
   GLint ibo1 = 0; ::glGetIntegerv( GL_ELEMENT_ARRAY_BUFFER_BINDING, &ibo1 ); GPU_BUFFER_VALIDATE
   //=====
   // VBO
   //=====
   if ( !vbo ) { createVBO( vbo ); }
   if ( !vbo ) { return false; }
   ::glBindBuffer( GL_ARRAY_BUFFER, vbo); GPU_BUFFER_VALIDATE
   size_t byteCount = size_t(vCount) * fvf.getByteSize();
   ::glBufferData( GL_ARRAY_BUFFER, byteCount, vertices, GL_STATIC_DRAW ); GPU_BUFFER_VALIDATE

   //==============================
   // IBO - Upload Indices ( optional, can reduce memory of mesh by reusing vertices using indices )
   // Possible since OpenGL ES 2.0 ( we love it, it means we store a mesh on graphics card memory GDDR5 )
   // A 4byte index is still smaller than a 36byte S3DVertex.
   // So i could address 9 vertices instead of storing only one new vertex.
   // Indices can be 8-bit,16-bit,32-bit unsigned integer.
   // Default for me is 4 byte to load 150000000 triangles without problems.
   //==============================
   if ( useIndices )
   {
      // Create index buffer, because we need one...
      if ( !ibo )
      {
         createIBO( ibo );
         //::glGenBuffers( 1, &ibo ); GPU_BUFFER_VALIDATE
      }
      // No index buffer created, but we need one, ergo abort.
      if ( !ibo )
      {
         return false;
      }

      // Bind index buffer
      ::glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, ibo );
      GPU_BUFFER_VALIDATE

      // Compute byte-size of indices to draw
      size_t bs = size_t(iCount) * IndexType::getIndexSize(indexType);

      // Draw indices
      ::glBufferData( GL_ELEMENT_ARRAY_BUFFER, bs, indices, GL_STATIC_DRAW );
      GPU_BUFFER_VALIDATE
   }
   //==============================
   // [VAO] for reducing calls to Attribute changes, possible since OpenGL ES 3.0 ( we like it )

   //==============================
#ifdef USE_VAO
   // ::glGenVertexArrays( 1, &vao ); GPU_BUFFER_VALIDATE
   if ( !vao ) { createVAO( vao ); }
   if ( !vao ) { return false; }

   ::glBindVertexArray( vao ); GPU_BUFFER_VALIDATE
   ::glBindBuffer( GL_ARRAY_BUFFER, vbo); GPU_BUFFER_VALIDATE
   if ( useIndices )
   {
      ::glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, ibo); GPU_BUFFER_VALIDATE
   }

   GLuint k = 0;
   size_t offset = 0;
   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & attr = fvf.m_Data[ i ];
      if ( !attr.m_Enabled ) continue;
      GLint const aCount = GLint( attr.m_Count );
      GLenum const aType = fromVertexAttribType( attr.m_Type );
      GLsizei const aStride = GLsizei( fvf.m_Stride );
      GLboolean const shouldNormalize = attr.m_Normalize ? GL_TRUE : GL_FALSE;
      ::glEnableVertexAttribArray( k ); GPU_BUFFER_VALIDATE
      ::glVertexAttribPointer( k, aCount, aType, shouldNormalize,
            aStride,( const void * )offset ); GPU_BUFFER_VALIDATE
      offset += attr.m_ByteSize; // Advance ptr to next item (attribute).
      k++;
   }

   // Restore RestorePoint
   ::glBindVertexArray ( vao1 ); GPU_BUFFER_VALIDATE
   ::glBindBuffer( GL_ARRAY_BUFFER, vbo1 ); GPU_BUFFER_VALIDATE
   ::glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, ibo1 ); GPU_BUFFER_VALIDATE
   //::glBindVertexArray ( 0 );

   //GPU_BUFFER_VALIDATE
//   k = 0;
//   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
//   {
//      VertexAttrib const & attr = fvf.m_Data[ i ];
//      if ( !attr.m_Enabled ) continue;
//      ::glDisableVertexAttribArray( GLuint( k ) );
//       GPU_BUFFER_VALIDATE
//      k++;
//   }

#endif

   return true;
}

void
BufferTools::draw(
#ifdef USE_GPU_BUFFER_CALLER
   std::string const & caller,
#endif
   uint32_t & vbo,
   uint32_t & ibo,
   uint32_t & vao,
   PrimitiveType::EType primType,
   void const* vertices, uint32_t vCount, FVF const & fvf,
   void const* indices, uint32_t iCount, IndexType::EType indexType )
{
   if ( !vertices || vCount < 1 )
   {
      return; // nothing to draw
   }
   if ( !indices && iCount > 0 )
   {
      return; // malformed indices
   }
   bool useIndices = indices && iCount > 0;

//   if ( esVersion > 1 )
//   {
//      if ( !vbo ) { return; }
//      if ( !ibo && useIndices ) { return; }
//   }
//   if ( esVersion > 2 )
//   {
//      if ( !vao ) { return; }
//   }

#ifdef USE_GPU_BUFFER_DEBUG
   PerformanceTimer timer;
   timer.start();
#endif

#ifdef USE_VAO
   if ( !vao )
   {
      upload(
         #ifdef USE_GPU_BUFFER_CALLER
         caller,
         #endif
         vbo, ibo, vao,
         primType, vertices, vCount, fvf,
         indices, iCount, indexType );
    }

   if ( !vao )
   {
      //DE_ERROR( "name(",caller,"), es(3) No vao" )
      return;
   }

   // RestorePoint
#ifdef USE_RESTORE_POINT
   GLint old_vao = 0;
   GLint old_vbo = 0;
   GLint old_ibo = 0;
   ::glGetIntegerv( GL_VERTEX_ARRAY_BINDING, &old_vao ); GPU_BUFFER_VALIDATE;
   ::glGetIntegerv( GL_ARRAY_BUFFER_BINDING, &old_vbo ); GPU_BUFFER_VALIDATE;
   ::glGetIntegerv( GL_ELEMENT_ARRAY_BUFFER_BINDING, &old_ibo ); GPU_BUFFER_VALIDATE;
#endif
   ::glBindVertexArray( vao );

   GPU_BUFFER_VALIDATE

   if ( useIndices )
   {
      ::glDrawElements(
            GLenum( fromPrimitiveType( primType ) ),
            GLsizei( iCount ),
            GLenum( fromIndexType( indexType ) ),
            (const void*)0 );
   }
   else
   {
      ::glDrawArrays(
            GLenum( fromPrimitiveType( primType ) ),
            0,
            GLsizei( vCount ) );
   }
   GPU_BUFFER_VALIDATE

#ifdef USE_RESTORE_POINT
//   ::glBindVertexArray ( old_vao );
//   ::glBindBuffer( GL_ARRAY_BUFFER, old_vbo );
//   ::glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, old_ibo );
#endif
   ::glBindVertexArray ( 0 );
   GPU_BUFFER_VALIDATE

#ifdef USE_GPU_BUFFER_DEBUG
   timer.stop();
   //DE_DEBUG( "RenderTime = ", timer.us(), " us." )
   //DE_DEBUG( "New vao = ", vao )
   //DE_DEBUG( "Old vao = ", old_vao )
#endif

#else
   // VBO only not implemented
#endif
}


} // end namespace gpu.
} // end namespace de.



// ===========================================================================
// FVFUtils
// ===========================================================================
#if 0

uint32_t
GLES::fromPrimitiveType( PrimitiveType::EType const primitiveType )
{
   switch ( primitiveType )
   {
      case PrimitiveType::Points: return GL_POINTS;
      case PrimitiveType::Lines: return GL_LINES;
      case PrimitiveType::LineStrip: return GL_LINE_STRIP;
      case PrimitiveType::LineLoop: return GL_LINE_LOOP;
      case PrimitiveType::Triangles: return GL_TRIANGLES;
      case PrimitiveType::TriangleStrip: return GL_TRIANGLE_STRIP;
      case PrimitiveType::TriangleFan: return GL_TRIANGLE_FAN;
      default: return GL_POINTS;
   }
}

PrimitiveType::EType
GLES::toPrimitiveType( uint32_t const primitiveType )
{
   switch ( primitiveType )
   {
      case GL_POINTS: return PrimitiveType::Points;
      case GL_LINES: return PrimitiveType::Lines;
      case GL_LINE_STRIP: return PrimitiveType::LineStrip;
      case GL_LINE_LOOP: return PrimitiveType::LineLoop;
      case GL_TRIANGLES: return PrimitiveType::Triangles;
      case GL_TRIANGLE_STRIP: return PrimitiveType::TriangleStrip;
      case GL_TRIANGLE_FAN: return PrimitiveType::TriangleFan;
      default: return PrimitiveType::Points;
   }
}

uint32_t
GLES::fromIndexType( IndexType::EType const indexType )
{
   switch ( indexType )
   {
      case IndexType::U8: return GL_UNSIGNED_BYTE;
      case IndexType::U16: return GL_UNSIGNED_SHORT;
      case IndexType::U32: return GL_UNSIGNED_INT;
      default: assert( false ); return 0;
   }
}

// I. converter from OpenGL backend
VertexAttribType::EType
GLES::toVertexAttribType( uint32_t type )
{
   switch( type )
   {
      case GL_FLOAT: return VertexAttribType::F32;
      case GL_BYTE: return VertexAttribType::S8;
      case GL_SHORT: return VertexAttribType::S16;
      case GL_INT: return VertexAttribType::S32;
      case GL_UNSIGNED_BYTE: return VertexAttribType::U8;
      case GL_UNSIGNED_SHORT: return VertexAttribType::U16;
      case GL_UNSIGNED_INT: return VertexAttribType::U32;
      default: { assert( false );
         return VertexAttribType::ETypeMax;
      }
   }
}

// I. converter to OpenGL backend
uint32_t
GLES::fromVertexAttribType( VertexAttribType::EType type )
{
   switch( type )
   {
      case VertexAttribType::F32: return GL_FLOAT;
      case VertexAttribType::S8: return GL_BYTE;
      case VertexAttribType::S16: return GL_SHORT;
      case VertexAttribType::S32: return GL_INT;
      case VertexAttribType::U8: return GL_UNSIGNED_BYTE;
      case VertexAttribType::U16: return GL_UNSIGNED_SHORT;
      case VertexAttribType::U32: return GL_UNSIGNED_INT;
      default: { assert( false );
         return 0;
      }
   }
}


bool
GLES::drawPrimitiveList( std::string const & caller, IMeshBuffer const & buf )
{
   return GLES::drawPrimitiveList( __func__, buf.getPrimitiveType(),
               buf.getVertices(), buf.getVertexCount(), buf.getFVF(),
               buf.getIndices(), buf.getIndexCount(), buf.getIndexType() );
}

bool
GLES::drawPrimitiveList(
   std::string const & caller,
   PrimitiveType::EType primType,
   void const* vertices, uint32_t vCount, FVF const & fvf,
   void const* indices, uint32_t indexCount, IndexType::EType indexType, bool debug )
{
   if ( !vertices ) { return false; } // DE_DEBUG( "No vertices. caller(",caller,")" )
   if ( vCount < 1 ) { return false; } // DE_DEBUG( "Empty vertices. caller(",caller,")" )
   if ( indexCount > 0 && !indices ) { DE_ERROR( "Invalid indices. caller(",caller,")" ) return false; }

   if ( debug )
   {
      uint32_t primCount = PrimitiveType::getPrimitiveCount( primType, indexCount > 0 ? indexCount : vCount );
      uint64_t byteCount = uint64_t(fvf.getByteSize()) * vCount +
                           uint64_t(IndexType::getIndexSize( indexType )) * indexCount;
      DE_DEBUG( caller," with ", primCount,
         " ", PrimitiveType::getString( primType ),", "
         "v:",vCount,", ",
         "i:",indexCount,"|",IndexType::getString( indexType ), ", "
         "fvf:", fvf.getByteSize(), ", "
         "siz:", byteCount
      )
   }

   bool ok = GLES::enableAttributesGL( fvf, (uint8_t const* )vertices );
   if ( !ok ) { DE_DEBUG( "No enabled attributes, caller(",caller,")" ) return false; }
   if ( indexCount < 1 )
   {
      //DE_DEBUG("VERTEX-PRIM(", PrimitiveType::getString( primType), "), v(", vCount,"), i(", indexCount, "), i-type(", IndexType::getString( indexType ), ")" )
      ::glDrawArrays( GLenum( GLES::fromPrimitiveType( primType ) ),
                      0, GLsizei( vCount ) ); GPU_BUFFER_VALIDATE
   }
   else
   {
      // DE_DEBUG("INDEX-PRIM(", PrimitiveType::getString( primType), "), v(", vCount,"), i(", indexCount, "), i-type(", IndexType::getString( indexType ), ")" )
      ::glDrawElements( GLenum( GLES::fromPrimitiveType( primType ) ),
                        GLsizei( indexCount ),
                        GLenum( GLES::fromIndexType( indexType ) ),
                        indices ); GPU_BUFFER_VALIDATE
   }

   GLES::disableAttributesGL( fvf );
   return true;
}

// New:

// moved here from FVF, because FVF is API only now.
bool
GLES::enableAttributesGL( FVF const & fvf, uint8_t const * vertices )
{
   if ( !vertices ) { DE_WARN("No vertices") return false; }

   GLuint k = 0;

   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & attr = fvf.m_Data[ i ];
      if ( !attr.m_Enabled ) continue;

      //DE_DEBUG("glEnableVertexAttribArray(",k,")")

      GLint const attrCount = GLint( attr.m_Count );
      GLenum const attrType = GLES::fromVertexAttribType( attr.m_Type );
      GLsizei const attrStride = GLsizei( fvf.m_Stride );
      GLboolean const shouldNormalize = attr.m_Normalize ? GL_TRUE : GL_FALSE;

      ::glEnableVertexAttribArray( k ); GPU_BUFFER_VALIDATE

      ::glVertexAttribPointer( k, attrCount, attrType,
                             shouldNormalize, attrStride, vertices ); GPU_BUFFER_VALIDATE

      // DE_DEBUG("glEnableVertexAttribArray(",k,")")
      // DE_DEBUG("glVertexAttribPointer(", k,",", va_count,","
      //       , uint32_t(va_type),",", uint32_t(va_normalize),","
      //       , uint32_t(va_stride),",", (void*)vertices )

      vertices += attr.m_ByteSize; // Advance ptr to next item (attribute).
      k++;
   }

   return true;
}

// New:

// moved here from FVF, because FVF is API only now.
bool
GLES::disableAttributesGL( FVF const & fvf )
{
   GLuint k = 0;

   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & attr = fvf.m_Data[ i ];
      if ( !attr.m_Enabled ) continue;

      ::glDisableVertexAttribArray( GLuint( i ) ); GPU_BUFFER_VALIDATE

      //DE_DEBUG("glDisableVertexAttribArray(",k,")")
      k++;
   }
   return true;
}

//   void
//   drawGL( uint8_t const * vertices )
//   {
//      // DE_DEBUG("")
//      enableAttributesGL( vertices );
//      ::glDrawArrays( getPrimitiveType(), 0, getVertexCount() );
//      disableAttributesGL();
//   }

// ===========================================================================
// FVFUtils
// ===========================================================================
bool
GLES::drawPrimitiveList( std::string const & caller, IMeshBuffer const & buf )
{
   return GLES::drawPrimitiveList( __func__, buf.getPrimitiveType(),
               buf.getVertices(), buf.getVertexCount(), buf.getFVF(),
               buf.getIndices(), buf.getIndexCount(), buf.getIndexType() );
}

bool
GLES::drawPrimitiveList(
   std::string const & caller,
   PrimitiveType::EType primType,
   void const* vertices, uint32_t vertexCount, FVF const & fvf,
   void const* indices, uint32_t indexCount, IndexType::EType indexType, bool debug )
{
   if ( !vertices ) { return false; } // DE_DEBUG( "No vertices. caller(",caller,")" )
   if ( vertexCount < 1 ) { return false; } // DE_DEBUG( "Empty vertices. caller(",caller,")" )
   if ( indexCount > 0 && !indices ) { DE_ERROR( "Invalid indices. caller(",caller,")" ) return false; }

   if ( debug )
   {
      uint32_t primCount = PrimitiveType::getPrimitiveCount( primType, indexCount > 0 ? indexCount : vertexCount );
      uint64_t byteCount = uint64_t(fvf.getByteSize()) * vertexCount +
                           uint64_t(IndexType::getIndexSize( indexType )) * indexCount;
      DE_DEBUG( caller," with ", primCount,
         " ", PrimitiveType::getString( primType ),", "
         "v:",vertexCount,", ",
         "i:",indexCount,"|",IndexType::getString( indexType ), ", "
         "fvf:", fvf.getByteSize(), ", "
         "siz:", byteCount
      )
   }

   bool ok = GLES::enableAttributesGL( fvf, (uint8_t const* )vertices );
   if ( !ok ) { DE_DEBUG( "No enabled attributes, caller(",caller,")" ) return false; }
   if ( indexCount < 1 )
   {
      //DE_DEBUG("VERTEX-PRIM(", PrimitiveType::getString( primType), "), v(", vertexCount,"), i(", indexCount, "), i-type(", IndexType::getString( indexType ), ")" )
      ::glDrawArrays( GLenum( GLES::fromPrimitiveType( primType ) ),
                      0, GLsizei( vertexCount ) ); GL_VALIDATE
   }
   else
   {
      // DE_DEBUG("INDEX-PRIM(", PrimitiveType::getString( primType), "), v(", vertexCount,"), i(", indexCount, "), i-type(", IndexType::getString( indexType ), ")" )
      ::glDrawElements( GLenum( GLES::fromPrimitiveType( primType ) ),
                        GLsizei( indexCount ),
                        GLenum( GLES::fromIndexType( indexType ) ),
                        indices ); GL_VALIDATE
   }

   GLES::disableAttributesGL( fvf );
   return true;
}

// New:

// moved here from FVF, because FVF is API only now.
bool
GLES::enableAttributesGL( FVF const & fvf, uint8_t const * vertices )
{
   if ( !vertices ) { DE_WARN("No vertices") return false; }

   GLuint k = 0;

   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & attr = fvf.m_Data[ i ];
      if ( !attr.m_Enabled ) continue;

      //DE_DEBUG("glEnableVertexAttribArray(",k,")")

      GLint const attrCount = GLint( attr.m_Count );
      GLenum const attrType = GLES::fromVertexAttribType( attr.m_Type );
      GLsizei const attrStride = GLsizei( fvf.m_Stride );
      GLboolean const shouldNormalize = attr.m_Normalize ? GL_TRUE : GL_FALSE;

      ::glEnableVertexAttribArray( k ); GL_VALIDATE

      ::glVertexAttribPointer( k, attrCount, attrType,
                             shouldNormalize, attrStride, vertices ); GL_VALIDATE

      // DE_DEBUG("glEnableVertexAttribArray(",k,")")
      // DE_DEBUG("glVertexAttribPointer(", k,",", va_count,","
      //       , uint32_t(va_type),",", uint32_t(va_normalize),","
      //       , uint32_t(va_stride),",", (void*)vertices )

      vertices += attr.m_ByteSize; // Advance ptr to next item (attribute).
      k++;
   }

   return true;
}

// New:

// moved here from FVF, because FVF is API only now.
bool
GLES::disableAttributesGL( FVF const & fvf )
{
   GLuint k = 0;

   for ( size_t i = 0 ; i < fvf.m_Data.size(); ++i )
   {
      VertexAttrib const & attr = fvf.m_Data[ i ];
      if ( !attr.m_Enabled ) continue;

      ::glDisableVertexAttribArray( GLuint( i ) ); GL_VALIDATE

      //DE_DEBUG("glDisableVertexAttribArray(",k,")")
      k++;
   }
   return true;
}

//   void
//   drawGL( uint8_t const * vertices )
//   {
//      // DE_DEBUG("")
//      enableAttributesGL( vertices );
//      ::glDrawArrays( getPrimitiveType(), 0, getVertexCount() );
//      disableAttributesGL();
//   }


uint32_t
GLES::fromPrimitiveType( PrimitiveType::EType const primitiveType )
{
   switch ( primitiveType )
   {
      case PrimitiveType::Points: return GL_POINTS;
      case PrimitiveType::Lines: return GL_LINES;
      case PrimitiveType::LineStrip: return GL_LINE_STRIP;
      case PrimitiveType::LineLoop: return GL_LINE_LOOP;
      case PrimitiveType::Triangles: return GL_TRIANGLES;
      case PrimitiveType::TriangleStrip: return GL_TRIANGLE_STRIP;
      case PrimitiveType::TriangleFan: return GL_TRIANGLE_FAN;
      default: return GL_POINTS;
   }
}

PrimitiveType::EType
GLES::toPrimitiveType( uint32_t const primitiveType )
{
   switch ( primitiveType )
   {
      case GL_POINTS: return PrimitiveType::Points;
      case GL_LINES: return PrimitiveType::Lines;
      case GL_LINE_STRIP: return PrimitiveType::LineStrip;
      case GL_LINE_LOOP: return PrimitiveType::LineLoop;
      case GL_TRIANGLES: return PrimitiveType::Triangles;
      case GL_TRIANGLE_STRIP: return PrimitiveType::TriangleStrip;
      case GL_TRIANGLE_FAN: return PrimitiveType::TriangleFan;
      default: return PrimitiveType::Points;
   }
}

uint32_t
GLES::fromIndexType( IndexType::EType const indexType )
{
   switch ( indexType )
   {
      case IndexType::U8: return GL_UNSIGNED_BYTE;
      case IndexType::U16: return GL_UNSIGNED_SHORT;
      case IndexType::U32: return GL_UNSIGNED_INT;
      default: assert( false ); return 0;
   }
}

// I. converter from OpenGL backend
VertexAttribType::EType
GLES::toVertexAttribType( uint32_t type )
{
   switch( type )
   {
      case GL_FLOAT: return VertexAttribType::F32;
      case GL_BYTE: return VertexAttribType::S8;
      case GL_SHORT: return VertexAttribType::S16;
      case GL_INT: return VertexAttribType::S32;
      case GL_UNSIGNED_BYTE: return VertexAttribType::U8;
      case GL_UNSIGNED_SHORT: return VertexAttribType::U16;
      case GL_UNSIGNED_INT: return VertexAttribType::U32;
      default: { assert( false );
         return VertexAttribType::ETypeMax;
      }
   }
}

// I. converter to OpenGL backend
uint32_t
GLES::fromVertexAttribType( VertexAttribType::EType type )
{
   switch( type )
   {
      case VertexAttribType::F32: return GL_FLOAT;
      case VertexAttribType::S8: return GL_BYTE;
      case VertexAttribType::S16: return GL_SHORT;
      case VertexAttribType::S32: return GL_INT;
      case VertexAttribType::U8: return GL_UNSIGNED_BYTE;
      case VertexAttribType::U16: return GL_UNSIGNED_SHORT;
      case VertexAttribType::U32: return GL_UNSIGNED_INT;
      default: { assert( false );
         return 0;
      }
   }
}
// static
std::string
GLES::getActiveAttribString( uint32_t program )
{
   std::stringstream s;
   GLint attribCount = getProgramValue( program, GL_ACTIVE_ATTRIBUTES );
   //GLint maxAttribCount = getProgramValue( program, GL_MAX_ATTRIBUTES );
//   GLint maxUniformLen;
//   GLint maxUniforms;
   s << "[GL] Attributes.Count = " << attribCount << "\n";
//   s << "[GL] Uniforms.MaxLen = " << maxUniformLen << "\n";
//   std::vector< char > uniformName;
//   uniformName.reserve( maxUniformLen );
//   for ( GLint i = 0; i < maxUniforms; ++i )
//   {
//      GLint uniformSize;
//      GLenum uniformType;
//      ::glGetActiveUniform( program, i, maxUniformLen, NULL, &uniformSize, &uniformType, uniformName.data() );
//      GLint location = ::glGetUniformLocation ( program, uniformName.data() );

//      std::string uniformTypeStr;
//      switch ( uniformType )
//      {
//         case GL_FLOAT:       uniformTypeStr = "float"; break;
//         case GL_FLOAT_VEC2:  uniformTypeStr = "vec2"; break;
//         case GL_FLOAT_VEC3:  uniformTypeStr = "vec3"; break;
//         case GL_FLOAT_VEC4:  uniformTypeStr = "vec4"; break;
//         case GL_INT:         uniformTypeStr = "int"; break;
//         default: break;
//      }
//      s << "[GL] Uniforms[" << i << "] loc:" << location << ", name:" << uniformName.data() << ", type:" << uniformType << ":" << uniformTypeStr << ", size:" << uniformSize << "\n";
//   }
   return s.str();
}
#endif
