#pragma once
#include <de/gpu/Font5x8.hpp>

namespace de {
namespace gpu {

struct IVideoDriver;

// ===========================================================================
struct Font5x8Renderer
// ===========================================================================
{
   DE_CREATE_LOGGER("de.gpu.Font5x8Renderer")

   Font5x8Renderer();
   ~Font5x8Renderer();
   void setDriver( IVideoDriver* driver ) { m_Driver = driver; }

   glm::ivec2
   getTextSize( std::string const & msg, Font5x8 const & font = Font5x8() ) const;

   void
   add2DText( SMeshBuffer & o, int x, int y,
            std::string const & msg,
            uint32_t color,
            Align::EAlign align,
            Font5x8 const & font );

   void
   draw2DText( int x, int y,
               std::string const & msg,
               uint32_t color = 0xFFFFFFFF,
               Align::EAlign align = Align::Default,
               Font5x8 const & font = Font5x8() );

   IVideoDriver* m_Driver;
};

} // end namespace gpu.
} // end namespace de.