#pragma once
#include <de/gpu/MeshBuffer.hpp>

namespace de {
namespace gpu {

#ifndef USE_VAO
#define USE_VAO
#endif

#ifndef USE_GPU_BUFFER_DEBUG
//#define USE_GPU_BUFFER_DEBUG
//#define USE_GPU_BUFFER_CALLER
//#define USE_GPU_BUFFER_VALIDATE
#endif

#ifdef USE_GPU_BUFFER_VALIDATE
#ifndef GPU_BUFFER_VALIDATE
#define GPU_BUFFER_VALIDATE GL_VALIDATE
#endif
#else
#ifndef GPU_BUFFER_VALIDATE
#define GPU_BUFFER_VALIDATE
#endif
#endif


enum EGpuBufferUsage
{
   GBU_Static = 0,
   GBU_Dynamic
};

// Manages the GpuSide of a high level mesh.
// Internally creates a VAO with VBO and IBO if needed.
// VAO is supported since ES 3.0
// VBO and IBO supported since ES2.0
// Immediate drawing supported since ES 1.0 ( no gpu buffer, but can be fast for dynamic things )
// ===========================================================================
struct BufferTools
// ===========================================================================
{
   // Advanced users use their own custom shader
   // Surpasses the StandardMaterial renderer
   // Does only setup geometry (state/vao/vbo/ibo).

   static bool
   drawPrimitiveList(
      #ifdef USE_GPU_BUFFER_CALLER
      std::string const & caller,
      #endif
      IMeshBuffer const & buf );

   static bool
   drawPrimitiveList(
      #ifdef USE_GPU_BUFFER_CALLER
      std::string const & caller,
      #endif
      PrimitiveType::EType primType,
      void const* vertices, uint32_t vertexCount, FVF const & fvf,
      void const* indices, uint32_t indexCount, IndexType::EType indexType, bool debug = false );

   // Pro draw users

   static bool
   disableFVF( FVF const & fvf );

   static bool
   enableFVF( FVF const & fvf, uint8_t const * vertices );

   static uint32_t
   fromVertexAttribType( VertexAttribType::EType type );

   static VertexAttribType::EType
   toVertexAttribType( uint32_t type );

   static uint32_t
   fromIndexType( IndexType::EType const indexType );

   static PrimitiveType::EType
   toPrimitiveType( uint32_t const primitiveType );

   static uint32_t
   fromPrimitiveType( PrimitiveType::EType const primitiveType );

   // ===========================================================================
   // VAO_Utils
   // ===========================================================================

   // Tools for all users
   static void
   destroy(
#ifdef USE_GPU_BUFFER_CALLER
      std::string const & caller,
#endif
      uint32_t & vbo,
      uint32_t & ibo,
      uint32_t & vao );

   static bool upload(
#ifdef USE_GPU_BUFFER_CALLER
      std::string const & caller,
#endif
      uint32_t & vbo,
      uint32_t & ibo,
      uint32_t & vao,
      PrimitiveType::EType primType,
      void const* vertices,
      uint32_t vCount,
      FVF const & fvf,
      void const* indices,
      uint32_t iCount,
      IndexType::EType indexType );

   static void draw(
#ifdef USE_GPU_BUFFER_CALLER
      std::string const & caller,
#endif
      uint32_t & vbo,
      uint32_t & ibo,
      uint32_t & vao,
      PrimitiveType::EType primType,
      void const* vertices,
      uint32_t vCount,
      FVF const & fvf,
      void const* indices,
      uint32_t iCount,
      IndexType::EType indexType );

   static bool
   drawImmediate(
#ifdef USE_GPU_BUFFER_CALLER
      std::string const & caller,
#endif
      PrimitiveType::EType primType,
      void const* vertices,
      uint32_t vCount,
      FVF const & fvf,
      void const* indices,
      uint32_t iCount,
      IndexType::EType indexType )
   {
      return drawPrimitiveList(
         #ifdef USE_GPU_BUFFER_CALLER
         caller,
         #endif
         primType, vertices, vCount, fvf,
         indices, iCount, indexType );
   }


   // Advanced user:

   static bool createVBO( uint32_t & vbo ); // ES 2.0
   static bool createIBO( uint32_t & ibo ); // ES 2.0
   static bool createVAO( uint32_t & vao ); // ES 3.0

   static void destroyVBO( uint32_t & vbo ); // ES 2.0
   static void destroyIBO( uint32_t & ibo ); // ES 2.0
   static void destroyVAO( uint32_t & vao ); // ES 3.0

};

} // end namespace gpu.
} // end namespace de.
