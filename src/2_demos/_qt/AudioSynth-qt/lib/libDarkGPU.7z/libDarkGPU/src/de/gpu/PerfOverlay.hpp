#pragma once
#include <de/gpu/IVideoDriver.hpp>

namespace de {
namespace gpu {

// ===========================================================================
struct PerfOverlay
// ===========================================================================
{
   DE_CREATE_LOGGER("de.gpu.PerfOverlay")

   PerfOverlay() : m_Driver( nullptr ) {}
   ~PerfOverlay() {}
   void setDriver( IVideoDriver* driver ) { m_Driver = driver; }


   void draw2DPerfOverlay5x8();
   
   IVideoDriver* m_Driver;
};

} // end namespace gpu.
} // end namespace de.
