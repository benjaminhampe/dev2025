#pragma once
#include <de/gpu/ISceneManager.hpp>

namespace de {
namespace gpu {

// =======================================================================
struct SceneManager : public ISceneManager
// =======================================================================
{
   DE_CREATE_LOGGER("de.gpu.SceneManager")
   IVideoDriver* m_Driver;    // ### Driver ###
   std::vector< ISceneNode* > m_TopLevel;    // ### SceneNodeManager ###
   std::vector< ISceneNode* > m_TrashBin;    // ### SceneNodeManager ###
   ISceneNode* m_RootNode;    // ### SceneNodeManager ###
   ISceneNode* m_Hovered;     // ### CollisionManager ###
   ISceneNode* m_Picked;      // ### CollisionManager ###
   std::unordered_map< std::string, SMesh::SharedPtr > m_MeshLut;   // ### MeshManager ###
public:
   SceneManager( IVideoDriver* driver );
   ~SceneManager() override;
   IVideoDriver* getVideoDriver() override;
   ISceneNode* getRootSceneNode() override;
   std::vector< ISceneNode* > const & getSceneNodes() const override;
   std::vector< ISceneNode* > & getSceneNodes() override;
   ISceneNode* getHoveredSceneNode() override;
   ISceneNode* getPickedSceneNode() override;

   // ================
   // Collision control
   // ================
   ISceneNode* 
	pickSceneNode( Ray3< T > const & ray, ScenePickResult< T >* pickResult = nullptr ) override;

   //virtual void clearDebugData();
   uint32_t
   getBufferCount( int mode ) const override;

   uint64_t
   getVertexCount( int mode ) const override;

   uint64_t
   getIndexCount( int mode ) const override;

   uint64_t
   getByteCount( int mode ) const override;

   bool
   hasMesh( std::string const & name ) const override;

   void
   removeMesh( std::string const & name ) override;

   SMesh::SharedPtr
   addEmptyMesh( std::string name ) override;

   bool
   addMesh( SMesh::SharedPtr mesh ) override;
	
   uint32_t
   getMeshCount() const override;

   SMesh::SharedPtr
   getMesh( std::string const & name ) override;

   void 
	init( int w, int h ) override;

   void 
	clear() override;
	
   void 
	render() override;

   void 
	resize( int w, int h ) override;

   void 
	onFrameBegin() override;
	
   void 
	onFrameEnd() override;
	
   void 
	postEvent( SEvent event ) override;

   void 
	setDebugData( VisualDebugData const & debugData ) override;

   ISceneNode* 
	getSceneNode( std::string const & name ) override;

   void 
	addSceneNode( ISceneNode* node ) override;

   SMeshSceneNode*
   addMeshSceneNode( SMesh::SharedPtr const & mesh, ISceneNode* parent = nullptr, int id = -1 ) override;
   void 
	removeSceneNode( ISceneNode* node ) override;

	// ###########################
   // ###     MeshManager     ###
   // ###########################
	std::unordered_map< std::string, SMesh::SharedPtr > const &
   getMeshCache() const override;
	
   // =====================
   // ### CameraManager ###
   // =====================
   // ICamera* m_Camera;
   // std::vector< ICamera* > m_Cameras;
   // void clearCameras();
   // int32_t getCameraCount() const;
   // int32_t findCamera( ICamera* camera ) const;
   // int32_t findCamera( std::string const & name ) const;
   // ICamera* getCamera( int32_t index ) const;
   // ICamera* getCamera( std::string const & name ) const;
   // ICamera* addCamera( std::string const & name, bool makeActive = true );
   // void addCamera( ICamera* camera, bool makeActive = true );
   // ICamera* getActiveCamera();
   // ICamera const* getActiveCamera() const;
   // bool setActiveCamera( ICamera* camera );



};

} // end namespace gpu.
} // end namespace de.



