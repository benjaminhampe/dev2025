#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
struct Stencil
// ===========================================================================
{
   // 1: glEnable( GL_STENCIL_TEST )   // glStencilFunc, glStencilOp, glStencilMask
   // 2: glStencilFunc( GLenum func = GL_GEQUAL, GLint ref = 2, GLuint mask = 0xFF ):
   // 3: glStencilOp( GLenum sfail = GL_KEEP, GLenum zfail = GL_KEEP, GLenum zpass = GL_REPLACE ):

   // 1: glEnable( GL_STENCIL_TEST )   // glStencilFunc, glStencilOp, glStencilMask
   // StencilTest: mostly 8 bit channel to mask things while compositing.
   // Advanced graphic artists toolset for advanced image compositions.
   // A render pass can mark pixels as writable/non-writable to create effects.
   // The render pass would draw simple geometry
   // with simple colors to mark these regions as wished (writable|non-writable).
   // This stuff is hard to imagine, but still powerful to toolset with 256 layers.

   // 2: glStencilFunc( GLenum func = GL_GEQUAL, GLint ref = 2, GLuint mask = 0xFF ):
   // func: The test function, GL_NEVER,GL_LESS,GL_LEQUAL,GL_GREATER,GL_GEQUAL,GL_EQUAL, GL_NOTEQUAL, and GL_ALWAYS.
   // ref:  A value to compare the stencil value to using the test function.
   // mask: A bitwise AND operation is performed on the stencil value and reference value with this mask value before comparing them.
   enum ETestFunc { AlwaysPass = 0, Equal, Less, LessEqual, Greater,
      GreaterEqual, NotEqual, Never, ETestFuncCount
   };

   // 3: glStencilOp( GLenum sfail = GL_KEEP, GLenum zfail = GL_KEEP, GLenum zpass = GL_REPLACE ):
   // sfail: Action to take if the stencil test fails.
   // zfail: Action to take if the stencil test is successful, but the depth test failed.
   // zpass: Action to take if both the stencil test and depth tests pass.
   enum EAction { Keep = 0, Replace, EActionCount };

   Stencil( bool enable = false )
      : enabled( enable )
      , sfail( Keep )
      , zfail( Keep )
      , zpass( Replace )
      , testFunc( GreaterEqual )
      , testRefValue( 0 )
      , testMask( 0xFFFFFFFF )
      , stencilMask( 0xFFFFFFFF ) // 0x00 means write disabled to stencil buffer.
   {}

   bool isEnabled() const { return enabled; }

   static Stencil disabled() { Stencil stencil; stencil.enabled = false; return stencil; }

   Stencil& setEnabled( bool enable )
   {
      if ( enable ) { enabled = true; }
      else          { enabled = false; }
      return *this;
   }

   static std::string
   getFuncString( ETestFunc func )
   {
      switch( func ) // delete last 2 bits
      {
         case AlwaysPass: return "AlwaysPass";
         case Equal: return "Equal";
         case LessEqual: return "LessEqual";
         case Greater: return "Greater";
         case GreaterEqual: return "GreaterEqual";
         case NotEqual: return "NotEqual";
         case Never: return "Never";
         default: return "Unknown";
      }
   }

   static std::string
   getActionString( EAction action )
   {
      switch( action )
      {
         case Keep: return "Keep";
         case Replace: return "Replace";
         default: return "Unknown";
      }
   }


   bool operator==( Stencil const & other ) const
   {
      if ( other.enabled != enabled ) return false;
      if ( other.testFunc != testFunc ) return false;
      if ( other.testRefValue != testRefValue ) return false;
      if ( other.testMask != testMask ) return false;
      if ( other.sfail != sfail ) return false;
      if ( other.zfail != zfail ) return false;
      if ( other.zpass != zpass ) return false;
      if ( other.stencilMask != stencilMask ) return false;
      return true;
   }

   bool operator!=( Stencil const & other ) const { return !( other == *this ); }

   std::string
   toString() const
   {
      std::ostringstream s;
      if ( enabled ) { s << "ON"; }
      else           { s << "OFF"; }
      s << ", "
      "func(" << testFunc << "), "
      "refValue(" << testRefValue << "), "
      "testMask(" << RGBA_toHexString(testMask) << "), "
      "sfail(" << sfail << "), "
      "zfail(" << zfail << "), "
      "zpass(" << zpass << "), "
      "writeMask(" << RGBA_toHexString(stencilMask) << ")"
      ;
      return s.str();
   }

public:
   // 1: glEnable( GL_STENCIL_TEST )   // glStencilFunc, glStencilOp, glStencilMask
   bool enabled : 2;
   // 3: glStencilOp( GLenum sfail = GL_KEEP, GLenum zfail = GL_KEEP, GLenum zpass = GL_REPLACE ):
   EAction sfail : 2; // = GL_KEEP;
   EAction zfail : 2; // = GL_KEEP;
   EAction zpass : 2; // = GL_REPLACE
   // 2: glStencilFunc( GLenum func = GL_GEQUAL, GLint ref = 2, GLuint mask = 0xFF ):
   ETestFunc testFunc : 4; // ETestFunc
   int32_t  testRefValue;
   uint32_t testMask;
   // glStencilMask(0xFF);
   // Finally, glStencilMask can be used to control the bits that are written to the
   // stencil buffer when an operation is run. The default value is all ones, which
   // means that the outcome of any operation is unaffected.
   // glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
   // glDepthMask(GL_FALSE);
   uint32_t stencilMask;
};

} // end namespace gpu.
} // end namespace de.
