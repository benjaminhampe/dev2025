#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
struct Blend
// ===========================================================================
{
   // GL_BLEND_COLOR 0x8005
   enum EEquation { Add = 0, Sub, ReverseSub, Min, Max, EEquationCount };
   // AlphaBlending = SourceColor*SourceAlpha + DestColor*(1-SourceAlpha)
   // AdditiveBlending = SourceColor*1 + DestColor*1
   enum EFunction { Zero = 0, One, SrcAlpha, OneMinusSrcAlpha, SrcAlphaSaturate,
      ConstantAlpha, DstAlpha, OneMinusDstAlpha, SrcColor, OneMinusSrcColor,
      DstColor, OneMinusDstColor, ConstantColor, OneMinusConstantColor,
      BlendColor, Src1Color, OneMinusSrc1Color, Src1Alpha, OneMinusSrc1Alpha,
      EFunctionCount
   };

   bool enabled;
   EEquation equation;
   // EEquation equationSeparate2;
   EFunction src_a;
   EFunction dst_a;
   EFunction src_rgb;
   EFunction dst_rgb;

   /*
   AlphaBlending = SourceColor*SourceAlpha + DestColor*(1-SourceAlpha)
   AdditiveBlending = SourceColor*1 + DestColor*1
   case SourceOver:      glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); break;
   case DestinationOver: glBlendFunc(GL_ONE_MINUS_DST_ALPHA, GL_ONE); break;
   case Clear:           glBlendFunc(GL_ZERO, GL_ZERO); break;
   case Source:          glBlendFunc(GL_ONE, GL_ZERO); break;
   case Destination:     glBlendFunc(GL_ZERO, GL_ONE); break;
   case SourceIn:        glBlendFunc(GL_DST_ALPHA, GL_ZERO); break;
   case DestinationIn:   glBlendFunc(GL_ZERO, GL_SRC_ALPHA); break;
   case SourceOut:       glBlendFunc(GL_ONE_MINUS_DST_ALPHA, GL_ZERO); break;
   case DestinationOut:  glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_ALPHA); break;
   case SourceAtop:      glBlendFunc(GL_DST_ALPHA, GL_ONE_MINUS_SRC_ALPHA); break;
   case DestinationAtop: glBlendFunc(GL_ONE_MINUS_DST_ALPHA, GL_SRC_ALPHA); break;
   case Xor:   glBlendFunc(GL_ONE_MINUS_DST_ALPHA, GL_ONE_MINUS_SRC_ALPHA); break;
   case Plus:  glBlendFunc(GL_ONE, GL_ONE); break;
   */

public:
   static std::string
   getEquationString( EEquation eq )
   {
      switch ( eq )
      {
         case Add: return "Add";
         case Sub: return "Sub";
         case ReverseSub: return "ReverseSub";
         case Min: return "Min";
         case Max: return "Max";
         default: return "None";
      }
   }

   static std::string
   getFunctionString( EFunction func )
   {
      switch ( func )
      {
         case SrcAlpha: return "SrcAlpha";
         case OneMinusSrcAlpha: return "OneMinusSrcAlpha";

         case Zero: return "Zero";
         case One: return "One";

         case DstAlpha: return "DstAlpha";
         case OneMinusDstAlpha: return "OneMinusDstAlpha";
         case SrcAlphaSaturate: return "SrcAlphaSaturate";

         case SrcColor: return "SrcColor";
         case OneMinusSrcColor: return "OneMinusSrcColor";
         case DstColor: return "DstColor";
         case OneMinusDstColor: return "OneMinusDstColor";

         case ConstantAlpha: return "ConstantAlpha";
         case ConstantColor: return "ConstantColor";
         case OneMinusConstantColor: return "OneMinusConstantColor";

         case BlendColor: return "BlendColor";
   //         case GL_SRC1_ALPHA_EXT: return Blend::Src1Alpha;
   //         case GL_ONE_MINUS_SRC1_ALPHA_EXT: return Blend::OneMinusSrc1Alpha;
   //         case GL_SRC1_COLOR_EXT: return Blend::Src1Color;
   //         case GL_ONE_MINUS_SRC1_COLOR_EXT: return Blend::OneMinusSrc1Color;
         default: return "None";
      }
   }

   static Blend
   disabled()
   {
      Blend blend;
      blend.enabled = false;
      blend.equation = Add;
      blend.src_a = One;
      blend.dst_a = One;
      blend.src_rgb = One;
      blend.dst_rgb = One;
      return blend;
   }

   static Blend
   alphaBlend()
   {
      // Final.rgb = fg.rgb * ( fg.a ) + ( 1-f.a) * bg.rgb
      Blend blend;
      blend.enabled = true;
      blend.equation = Add;
      blend.src_a = SrcAlpha;
      blend.dst_a = OneMinusSrcAlpha;
      blend.src_rgb = SrcColor;
      blend.dst_rgb = DstColor;
      return blend;
   }

   static Blend
   additive()
   {
      Blend blend;
      blend.enabled = true;
      blend.equation = Add;
      blend.src_a = One;
      blend.dst_a = One;
      blend.src_rgb = One;
      blend.dst_rgb = One;
      return blend;
   }

   Blend( bool enable = false )
      : enabled( enable )
      , equation( Add )
      , src_a( SrcAlpha )
      , dst_a( OneMinusSrcAlpha )
      , src_rgb( SrcColor )
      , dst_rgb( DstColor )
   {}

   Blend( Blend const & o )
      : enabled( o.enabled )
      , equation( o.equation )
      , src_a( o.src_a )
      , dst_a( o.dst_a )
      , src_rgb( o.src_rgb )
      , dst_rgb( o.dst_rgb )
   {}

   bool isEnabled() const { return enabled; }

   Blend&
   setEnabled( bool enable )
   {
      if ( enable ) { enabled = true; }
      else          { enabled = false; }
      return *this;
   }

   Blend&
   operator=( Blend const & o )
   {
      enabled = o.enabled;
      equation = o.equation;
      src_a = o.src_a;
      dst_a  = o.dst_a;
      return *this;
   }

   bool
   operator==( Blend const & o ) const
   {
      if ( o.enabled != enabled ) return false;
      if ( o.equation != equation ) return false;
      if ( o.src_a != src_a ) return false;
      if ( o.dst_a != dst_a ) return false;
      return true;
   }

   bool
   operator!=( Blend const & other ) const { return !( other == *this );   }

   std::string
   toString() const
   {
      std::ostringstream s;
      if ( enabled )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }

      s << ", equation(" << getEquationString( equation ) << ")";
      s << ", src_a(" << getFunctionString( src_a ) << ")";
      s << ", dst_a(" << getFunctionString( dst_a ) << ")";
      s << ", src_color(" << getFunctionString( src_rgb ) << ")";
      s << ", dst_color(" << getFunctionString( dst_rgb ) << ")";
      return s.str();
   }

};

} // end namespace gpu.
} // end namespace de.
