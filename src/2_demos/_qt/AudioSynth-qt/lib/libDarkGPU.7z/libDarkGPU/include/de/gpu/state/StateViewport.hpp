#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
// Viewport
// ===========================================================================
typedef Recti Viewport;

/*
// ===========================================================================
struct Viewport
// ===========================================================================
{
   Viewport( int dummy_for_SM3_Ctr = 0 )
      : rect(), n( 0.2f ), f( 3123.0f ) {}
   Viewport( int32_t x, int32_t y, int32_t w, int32_t h )
      : rect( x,y,w,h ), n( 0.2f ), f( 3123.0f ) {}
   bool isValid() const { return ( rect.w > 0 && rect.h > 0 ); }
   bool operator==( Viewport const & o ) const { return rect == o.rect; }
   bool operator!=( Viewport const & o ) const { return !( o == *this ); }
   std::string toString() const
   {
      std::ostringstream s;
      s << rect.toString()
         << ", n:" << n
         << ", f:" << f;
      return s.str();
   }
   Recti rect;
   float n, f; // DepthRange: near + far
};
*/

} // end namespace gpu.
} // end namespace de.
