#pragma once
// uses VisualDebugData
#include <de/gpu/Camera.hpp>
#include <de/gpu/TRS.hpp>
#include <de/gpu/Event.hpp>
#include <de/gpu/Mesh.hpp>
#include <de/gpu/ISceneNode.hpp>
//#include <de/gpu/Math3D.hpp>
//#include <de/gpu/Math3D_Quaternion.hpp>
//#include <de/gpu/Math3D_DualQuaternion.hpp>
//#include <de/gpu/MeshDebug.hpp>
namespace de {
namespace gpu {

class ISceneManager;
class IVideoDriver;

// =======================================================================
struct SMeshSceneNode : public ISceneNode
// =======================================================================
{
   SMeshSceneNode(
      SMesh::SharedPtr const & mesh,
      ISceneManager* smgr,
      ISceneNode* parent = nullptr,
      int id = -1 );

   SMeshSceneNode(
      ISceneManager* smgr,
      ISceneNode* parent = nullptr,
      int id = -1 );

   ~SMeshSceneNode() override;
   void render() override;
   SMesh::SharedPtr const & getMesh() const;
   SMesh::SharedPtr getMesh();
   void setMesh( SMesh::SharedPtr const & mesh );

   bool
   intersectRay( Ray3< T > const & ray, glm::tvec3< T > * outPosition = nullptr,
                 uint32_t* outBufferIndex = nullptr, uint32_t* outTriangleIndex = nullptr,
                 Triangle3< T >* outTriangle = nullptr ) const override;
   bool
   intersectRayWithBoundingBox( Ray3< T > const & ray, glm::tvec3< T > * hitPosition = nullptr,
                 uint32_t* hitMeshBufferIndex = nullptr ) const override;

   SceneNodeType::EType getNodeType() const override { return SceneNodeType::Mesh; }
   Box3f getBoundingBox() const override { return m_Mesh ? m_Mesh->getBoundingBox() : Box3f(); }
   std::string getName() const override { return m_Mesh ? m_Mesh->Name : ""; }
   void setName( std::string const & name ) override { if (m_Mesh) m_Mesh->setName( name ); }
   void setLighting( int illum ); // { if ( m_Mesh ) m_Mesh->setLighting( enable ); }
   void setFogEnable( bool enable ); // { if ( m_Mesh ) m_Mesh->setFogEnable( enable ); }
   void setWireframe( bool enable ); // { if ( m_Mesh ) m_Mesh->setWireframe( enable ); }
   void setCulling( Culling cull ); // { if ( m_Mesh ) m_Mesh->setCulling( culling ); }
   void setCulling( bool enable ); // { if ( m_Mesh ) m_Mesh->setCulling( enable ); }
   void setDepth( Depth depth ); // { if ( m_Mesh ) m_Mesh->setDepth( depth ); }
   void setTexture( int stage, TexRef const & tex ); // { if ( m_Mesh ) m_Mesh->setTexture( stage, tex ); }
   void setDebugData( VisualDebugData const & debugFlags ) override;
   uint32_t getBufferCount( int mode = 0 ) const override;
   uint64_t getVertexCount( int mode = 0 ) const override;
   uint64_t getIndexCount( int mode = 0 ) const override;
   uint64_t getByteCount( int mode = 0 ) const override;

   int getLighting() const { return m_Mesh ? m_Mesh->getLighting() : 0; }
//   int getFogEnable( bool enable ) { if ( m_Mesh ) m_Mesh->setFogEnable( enable ); }
//   int getWireframe( bool enable ) { if ( m_Mesh ) m_Mesh->setWireframe( enable ); }
//   int getCulling( Culling cull ) { if ( m_Mesh ) m_Mesh->setCulling( cull ); }
//   int getDepth( Depth depth ) { if ( m_Mesh ) m_Mesh->setDepth( depth ); }
//   int getTexture( int stage, TexRef const & tex ) { if ( m_Mesh ) m_Mesh->setTexture( stage, tex ); }
protected:
   void updateDebugMesh();

   DE_CREATE_LOGGER("de.gpu.SMeshSceneNode")
   SMesh::SharedPtr m_Mesh;
   bool m_IsDirtyDebugMesh;
   SMesh m_DebugMesh;
   //std::vector< Triangle3f > m_CollisionTriangles;
};

} // end namespace gpu.
} // end namespace de.
