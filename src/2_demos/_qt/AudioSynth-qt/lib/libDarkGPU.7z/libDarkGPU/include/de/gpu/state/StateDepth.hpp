#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {


// ===========================================================================
struct Depth
// ===========================================================================
{
   enum EFlags
   {
      Disabled = 0,
      Enabled = 1,
      ZWriteEnabled = 2,
   };

   enum EFunc
   {
      Less = 0,          // GL_LESS
      LessEqual,     // GL_LEQUAL
      Equal,         // GL_EQUAL
      Greater,       // GL_GREATER
      GreaterEqual,  // GL_GEQUAL
      NotEqual,      // GL_NOTEQUAL
      AlwaysPass,   // GL_ALWAYS
      Never,        // GL_NEVER
   };

   bool isEnabled() const { return flags & Enabled; }
   bool isZWriteEnabled() const { return flags & ZWriteEnabled; }
   EFunc getFunc() const { return EFunc( flags >> 2 ); }

   static std::string
   getString( EFunc const func )
   {
      // 1111 = F -> 1100 = C
      switch( func ) // delete last 2 bits
      {
         //case Disabled: return "Disabled";
         //case Enabled: return "Enabled";
         //case ZWriteEnabled: return "WriteMask";
         case Less: return "Less";
         case LessEqual: return "LessEqual";
         case Equal: return "Equal";
         case Greater: return "Greater";
         case GreaterEqual: return "GreaterEqual";
         case NotEqual: return "NotEqual";
         case AlwaysPass: return "AlwaysPass";
         case Never: return "Never";
         default: return "Unknown";
      }
   }

//   bool enabled;
//   bool writeMask;
//   EFunc depthFunc;
   uint8_t flags;

   Depth( bool testEnable = true, bool zWrite = true, EFunc zFunc = LessEqual )
      : flags( uint8_t( zFunc ) << 2 )
   {
      if ( testEnable ) flags |= Enabled;
      if ( zWrite ) flags |= ZWriteEnabled;
      //DE_DEBUG( "Depth create. state(",toString(),")")
   }

   static Depth disabled() { return Depth( false ); }
   static Depth alwaysPass() { return Depth( true, false, AlwaysPass ); }

   Depth& setEnabled( bool enable )
   {
      if ( enable ) { flags |= Enabled; }
      else          { flags &= ~Enabled; }
      return *this;
   }

   Depth& setZWriteEnabled( bool enable )
   {
      if ( enable ) { flags |= ZWriteEnabled; }
      else          { flags &= ~ZWriteEnabled; }
      return *this;
   }

   Depth& setFunc( EFunc func )
   {
      flags &= 0x03; // delete all func bits
      flags |= uint8_t( func << 2 ); // set all func bits
      return *this;
   }

   bool operator==( Depth const & o ) const
   {
      if ( o.flags != flags ) return false;
      return true;
   }
   bool operator!=( Depth const & o ) const { return !( o == *this ); }

   std::string
   toString() const
   {
      std::ostringstream s;
      if ( isEnabled() )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }

      s << ", zWrite(" << isZWriteEnabled() << "), "
           "depthfunc(" << getString( getFunc() ) << ")";

      return s.str();
   }


};


} // end namespace gpu.
} // end namespace de.
