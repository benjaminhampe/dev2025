#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
struct DepthRange // : near + far
// ===========================================================================
{
   DepthRange( int dummy_for_SM3_Ctr = 0 ) : n( 0.2f ), f( 3123.0f ) {}
   DepthRange( float _n, float _f ) : n( _n ), f( _f ) {}
   bool isValid() const { return true; }
   bool operator==( DepthRange const & o ) const { return n == o.n && f == o.f; }
   bool operator!=( DepthRange const & o ) const { return !( o == *this ); }
   std::string toString() const
   {
      std::ostringstream s;
      s << "near:" << n << ", far:" << f;
      return s.str();
   }
   float n, f;
};

} // end namespace gpu.
} // end namespace de.
