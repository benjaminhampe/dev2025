#pragma once
#include <de/gpu/FVF.hpp>

namespace de {
namespace gpu {

// ===========================================================================
struct Culling
// ===========================================================================
{
   enum ECullMode
   {
      None = 0,
      Back,
      Front,
      FrontAndBack,
      EModeCount
   };

   enum EWinding
   {
      CW = 0,
      CCW,
      EWindingCount
   };


   uint8_t cullMode;
   uint8_t winding;

//   static Culling enabled( bool on ) { return on ? enabledBack() : disabled(); }
//   static Culling enabledBack() { return Culling( ENABLED | BACK ); }
//   static Culling disabled() { return Culling(); }

   Culling( ECullMode mode = Back, EWinding wind = CW )
      : cullMode( mode )
      , winding( wind )
   {}

   static Culling disabled() { return Culling( None ); }

   bool isEnabled() const { return cullMode != None; }
   bool isFront() const { return cullMode == Front; }
   bool isBack() const { return cullMode == Back; }
   bool isFrontAndBack() const { return cullMode == FrontAndBack; }
   bool isCW() const { return winding == CW; }
   bool isCCW() const { return winding == CCW; }

   Culling& setMode( ECullMode mode )
   {
      cullMode = mode;
      return *this;
   }

   Culling& setWinding( EWinding wind )
   {
      winding = wind;
      return *this;
   }

   Culling& setEnabled( bool enable )
   {
      if ( enable ) { cullMode = Back; }
      else          { cullMode = None; }
      return *this;
   }

//   Culling& enable() { flags |= ENABLED; return *this; }
//   Culling& disable() { flags &= ~ENABLED; return *this; }
   Culling& cw() { winding = CW; return *this; }
   Culling& ccw() { winding = CCW; return *this; }
   Culling& back() { cullMode = Back; return *this; }
   Culling& front() { cullMode = Front; return *this; }
   Culling& frontAndBack() { cullMode = FrontAndBack; return *this; }

   bool
   operator== ( Culling const & o ) const
   {
      return ( o.cullMode == cullMode
            && o.winding == winding );
   }

   bool
   operator!= ( Culling const & o ) const
   {
      return ( o.cullMode != cullMode
            || o.winding != winding );
   }

   std::string
   toString() const
   {
      std::stringstream s;
           if ( cullMode == None ) { s << "None"; }
      else if ( cullMode == Back ) { s << "Back"; }
      else if ( cullMode == Front ) { s << "Front"; }
      else if ( cullMode == FrontAndBack ) { s << "FrontAndBack"; }
      s << ",";
      if ( isCCW() ) { s << "CCW"; } else { s << "CW"; }
      return s.str();
   }

};

/*
// ===========================================================================
struct Culling
// ===========================================================================
{
   enum ECullMode
   {
      ENABLED = 1, BACK = 1<<1, FRONT = 1<<2, FRONT_AND_BACK = BACK | FRONT,
      WIND_MATH = 1<<3, // if set its CCW, else CW ( clock )
      EModeCount
   };

   static Culling enabled( bool on ) { return on ? enabledBack() : disabled(); }
   static Culling enabledBack() { return Culling( ENABLED | BACK ); }
   static Culling disabled() { return Culling(); }

   Culling( uint_fast8_t _flags = BACK | WIND_MATH ) : flags( _flags ) {}

   bool isEnabled() const { return( flags & ENABLED ); }
   bool isFront() const { return( flags & FRONT ); }
   bool isBack() const { return( flags & BACK ); }
   bool isFrontAndBack() const { return( flags & (FRONT|BACK) ); }
   bool isCCW() const { return( flags & WIND_MATH ); }
   bool isCW() const { return !isCCW(); }

   Culling& setEnabled( bool enable )
   {
      if ( enable ) { flags |= ENABLED; }
      else          { flags &= ~ENABLED; }
      return *this;
   }

   Culling& enable() { flags |= ENABLED; return *this; }
   Culling& disable() { flags &= ~ENABLED; return *this; }
   Culling& ccw() { flags |= WIND_MATH; return *this; }
   Culling& cw() { flags &= ~WIND_MATH; return *this; }
   Culling& front() { flags |= FRONT; return *this; }
   Culling& frontAndBack() { flags |= (FRONT|BACK); return *this; }
   Culling& back() { flags |= BACK; return *this; }

   bool operator== ( Culling const & o ) const { return ( o.flags == flags ); }
   bool operator!= ( Culling const & o ) const { return ( o.flags != flags ); }

   std::string
   toString() const
   {
      std::stringstream s;
      if ( isEnabled() )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }
      s << ",";

      if ( isFront() && isBack() )
      { s << "FRONT_AND_BACK"; }
      else if ( isBack() )
      { s << "BACK"; }
      else if ( isFront() )
      { s << "FRONT"; }
      s << ",";

      if ( isCCW() ) { s << "CCW"; } else { s << "CW"; }

      return s.str();
   }

   uint_fast8_t flags;
};
*/


} // end namespace gpu.
} // end namespace de.
