#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
struct Clear
// ===========================================================================
{
   enum EComponent { ColorBit = 1, DepthBit = 2, StencilBit = 4, BitCount = 3 };
   Clear( int dummy = 0 )
      : enabled( true ), color( .1f, .2f, .3f, 1.0f ), depth( 1.0f ), stencil( 0 )
      , mask( ColorBit | DepthBit | StencilBit )
   {}
   Clear( glm::vec4 const & color_, float depth_ = 1.0f, uint8_t stencil_ = 0 )
      : enabled( true ), color( color_ ), depth( depth_ ), stencil( stencil_ )
      , mask( ColorBit | DepthBit | StencilBit )
   {}
   bool isEnabled() const { return enabled; }
   // Chain settings together.
   Clear & enable() { enabled = true; return *this; }
   Clear & disable() { enabled = false; return *this; }
   Clear & enableColor() { mask |= ColorBit; return *this; }
   Clear & disableColor() { mask &= ~ColorBit; return *this; }
   Clear & enableDepth() { mask |= DepthBit; return *this; }
   Clear & disableDepth() { mask &= ~DepthBit; return *this; }
   Clear & enableStencil() { mask |= StencilBit; return *this; }
   Clear & disableStencil() { mask &= ~StencilBit; return *this; }
   Clear & withColor() { mask |= ColorBit; return *this; }
   Clear & noColor() { mask &= ~ColorBit; return *this; }
   Clear & withDepth() { mask |= DepthBit; return *this; }
   Clear & noDepth() { mask &= ~DepthBit; return *this; }
   Clear & withStencil() { mask |= StencilBit; return *this; }
   Clear & noStencil() { mask &= ~StencilBit; return *this; }
   bool hasColorBit() const { return( mask & ColorBit ); }
   bool hasStencilBit() const { return( mask & StencilBit ); }
   bool hasDepthBit() const { return( mask & DepthBit ); }

   bool operator==( Clear const & o ) const
   {
      if ( o.enabled != enabled ) return false;
      if ( o.color != color ) return false;
      if ( o.depth != depth ) return false;
      if ( o.stencil != stencil ) return false;
      if ( o.mask != mask ) return false;
      return true;
   }

   bool operator!=( Clear const & o ) const { return !( o == *this ); }
   void setColor( glm::vec4 const & rgba ) { color = rgba; }
   void setColor( uint32_t rgba ) { color = RGBAf( rgba ); }
   void setDepth( float depthValue = 1.0f ) { depth = depthValue; }
   void setStencil( uint8_t stencilValue = 0 ) { stencil = stencilValue; }

   std::string
   toString() const
   {
      std::ostringstream s;
      if ( enabled )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }

      if ( mask & ColorBit ) { s << "|Color"; }
      if ( mask & DepthBit ) { s << "|Depth"; }
      if ( mask & StencilBit ) { s << "|Stencil"; }

      s << ", ClearColor(" << color << ")";
      s << ", ClearDepth(" << depth << ")";
      s << ", ClearStencil(" << int32_t( stencil ) << ")";

      return s.str();
   }

   bool enabled;
   glm::vec4 color;
   float depth;
   uint8_t stencil;
   uint32_t mask = 0;
};

} // end namespace gpu.
} // end namespace de.
