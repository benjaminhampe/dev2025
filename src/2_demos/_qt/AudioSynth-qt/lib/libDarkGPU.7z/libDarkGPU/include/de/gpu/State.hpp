#pragma once
#include <de/gpu/state/StateCommon.hpp>
#include <de/gpu/state/StateDepthRange.hpp>
#include <de/gpu/state/StateViewport.hpp>
#include <de/gpu/state/StateScissor.hpp>
#include <de/gpu/state/StateClear.hpp>
#include <de/gpu/state/StateCulling.hpp>
#include <de/gpu/state/StateDepth.hpp>
#include <de/gpu/state/StateStencil.hpp>
#include <de/gpu/state/StateBlend.hpp>
#include <de/gpu/state/StateRasterizerDiscard.hpp>
#include <de/gpu/state/StateLineWidth.hpp>
#include <de/gpu/state/StatePointSize.hpp>
#include <de/gpu/state/StatePolygonOffset.hpp>

namespace de {
namespace gpu {

// =======================================================================
struct State
// =======================================================================
{
   //Clear clear;
   //Viewport viewport;
   //Scissor scissor;
   //DepthRange depthRange;
   Culling culling;
   Depth depth;
   Stencil stencil;
   Blend blend;
   RasterizerDiscard rasterizerDiscard;
   LineWidth lineWidth;
   PointSize pointSize;
   PolygonOffset polygonOffset;

   State( int dummy = 0 ) {}

   State( State const & o )
      : culling( o.culling )
      , depth( o.depth )
      , stencil( o.stencil )
      , blend( o.blend )
      , rasterizerDiscard( o.rasterizerDiscard )
      , lineWidth( o.lineWidth )
      , pointSize( o.pointSize )
      , polygonOffset( o.polygonOffset )
   {}

   State&
   operator=( State const & o )
   {
   // clear = o.clear;
   // viewport = o.viewport;
   // scissor = o.scissor;
   // depthRange = o.depthRange;
      culling = o.culling;
      depth = o.depth;
      stencil = o.stencil;
      blend = o.blend;
      rasterizerDiscard = o.rasterizerDiscard;
      lineWidth = o.lineWidth;
      pointSize = o.pointSize;
      polygonOffset = o.polygonOffset;
   // m_Texturing = o.m_Texturing;
      return *this;
   }

   bool
   operator==( State const & o ) const
   {
   // if ( clear != o.clear ) return false;
   // if ( viewport != o.viewport ) return false;
   // if ( scissor != o.scissor ) return false;
   // if ( depthRange != o.depthRange ) return false;
      if ( culling != o.culling ) return false;
      if ( depth != o.depth ) return false;
      if ( stencil != o.stencil ) return false;
      if ( blend != o.blend ) return false;
      if ( rasterizerDiscard != o.rasterizerDiscard ) return false;
      if ( lineWidth != o.lineWidth ) return false;
      if ( pointSize != o.pointSize ) return false;
      if ( polygonOffset != o.polygonOffset ) return false;
   // if ( m_Texturing != o.m_Texturing ) return false;
      return true;
   }

   bool
   operator!= ( State const & rhs ) const { return !( *this == rhs ); }

   std::string
   toString() const
   {
      std::ostringstream s; s <<
      "Cull:" << (culling.isBack() ? 0 : 1) << "," << (culling.isBack() ? 0 : 1) << "|"
      "D" << (depth.isEnabled() ? 1 : 0) << "|"
      "S" << (stencil.isEnabled() ? 1 : 0) << "|"
      "B" << (blend.isEnabled() ? 1 : 0) << "|"
      "rasterizerDiscard:" << rasterizerDiscard.toString() << "|"
      "lineWidth:" << lineWidth.toString() << "|"
      "pointSize:" << pointSize.toString() << "|"
      "polygonOffset:" << polygonOffset.toString()
      ;
      return s.str();
   }
/*
   std::string
   toString() const
   {
      std::stringstream s; s <<
      //"clear:" << clear.toString() << "|"
      //"viewport:" << viewport.toString() << "|"
      //"scissor:" << scissor.toString() << "|"
      //"depthRange:" << depthRange.toString() << "|"
      "culling:" << culling.toString() << "|"
      "depth:" << depth.toString() << "|"
      "stencil:" << stencil.toString() << "|"
      "blend:" << blend.toString() << "|"
      "rasterizerDiscard:" << rasterizerDiscard.toString() << "|"
      "lineWidth:" << lineWidth.toString() << "|"
      "pointSize:" << pointSize.toString() << "|"
      "polygonOffset:" << polygonOffset.toString()
      ;
      return s.str();
   }
*/
};

} // end namespace gpu.
} // end namespace de.
