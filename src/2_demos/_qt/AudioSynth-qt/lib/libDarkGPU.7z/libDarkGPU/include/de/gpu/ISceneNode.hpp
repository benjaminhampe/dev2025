#pragma once
#include <de/gpu/Mesh.hpp>
#include <de/gpu/Camera.hpp>
#include <de/gpu/Event.hpp>
//#include <de/gpu/Math3D.hpp>
//#include <de/gpu/Math3D_Quaternion.hpp>
//#include <de/gpu/Math3D_DualQuaternion.hpp>
//#include <de/gpu/MeshDebug.hpp>
namespace de {
namespace gpu {

class ISceneManager;
class IVideoDriver;

// =======================================================================
struct SceneNodeType
// =======================================================================
{
   enum EType { User = 0, Mesh, Camera, SkyBox, Cube, Terrain, Plane, Water, ETypeCount };
};

// =======================================================================
struct ISceneNode
// =======================================================================
{
   typedef double T;
   typedef glm::tmat4x4< T > M4;
   typedef glm::tvec2< T > V2;
   typedef glm::tvec3< T > V3;
   typedef glm::tvec4< T > V4;
   typedef std::unique_ptr< ISceneNode > UniquePtr;
   typedef std::shared_ptr< ISceneNode > SharedPtr;
   typedef std::weak_ptr< ISceneNode > WeakPtr;

   DE_CREATE_LOGGER("de.gpu.ISceneNode")
   ISceneManager* m_SceneManager;
   ISceneNode* m_Parent;             //! Pointer to the parent
   int m_Id;               //! ID of the node.
   bool m_IsVisible;         //! Is the node visible?
   bool m_IsDirty;        //! Is dirty matrix
   bool m_IsCollisionEnabled;     //! Is enabled for interactivity
   //bool m_IsDebugObject; //! Is debug object?
   M4 m_AbsoluteTransform;   // Absolute TRS transformation of the node.
   V3 m_RelativeTranslation; // Relative Translation of the scene node.
   V3 m_RelativeRotation;    // Relative Rotation (euler angles) of the scene node.
   V3 m_RelativeScale;       // Relative Scale of the scene node.
   //AnimTimer m_AnimTime;
   std::vector< ISceneNode* > m_Children;   //! List of all children of this node
   VisualDebugData m_DebugData;
   std::string m_Name;

   //std::vector< Triangle3f > m_CollisionTriangles;

   ISceneNode( ISceneManager* smgr, ISceneNode* parent, int id = -1 )
      : m_SceneManager( smgr )
      , m_Parent( parent )
      , m_Id( id )
      , m_IsVisible( true )
      , m_IsDirty( true )
      , m_IsCollisionEnabled( true )
      , m_AbsoluteTransform(1)   // default ctr identity matrix.
      , m_RelativeTranslation(0,0,0)
      , m_RelativeRotation(0,0,0)
      , m_RelativeScale(1,1,1)
      , m_Children()
   {
   //   if ( m_SceneManager )
   //   {
   //      m_SceneManager->addSceneNode( this );
   //   }

      if ( m_Parent )
      {
         m_Parent->addChild( this );
      }

      updateAbsoluteTransform();
   }

   virtual ~ISceneNode()
   {
      removeAll();
      // delete all animators
      // m_TriangleSelector->drop();
   }

   virtual Box3f getBoundingBox() const = 0;
   virtual void render() = 0;
   virtual void onEvent( SEvent event ) {}
   virtual void onAnimate( double pts ) {}

   virtual Box3f getAbsoluteBoundingBox() const { return getBoundingBox().transformBox( m_AbsoluteTransform ); }
   virtual ISceneManager* getSceneManager() { return m_SceneManager; }

   // Returns the parent of this scene node
   virtual ISceneNode* getParent() const { return m_Parent; }
   // Changes the parent of the scene node.
   virtual void setParent( ISceneNode* newParent )
   {
      //grab();
      //removeFromParent();
      if ( m_Parent ) { m_Parent->removeChild( this );}
      m_Parent = newParent;
      if ( m_Parent ) { m_Parent->addChild(this); }
      //drop();
   }
   virtual SceneNodeType::EType getNodeType() const { return SceneNodeType::User; }
   virtual std::vector< ISceneNode* > const & getChildren() const { return m_Children; }
   virtual bool isCollisionEnabled() const { return m_IsCollisionEnabled; }
   virtual void setCollisionEnabled( bool enable ) { m_IsCollisionEnabled = enable; }
   virtual std::string getName() const { return m_Name; }
   virtual void setName( std::string const & name ) { m_Name = name; }
   virtual std::string toString() const { std::stringstream s; s << getName(); return s.str(); }
   //virtual void removeFromParent();
   virtual VisualDebugData const & getDebugData() const { return m_DebugData; }
   virtual VisualDebugData & getDebugData() { return m_DebugData; }
   virtual void setDebugData( VisualDebugData const & debugData ) { m_DebugData = debugData; }
   virtual uint32_t getVertexCount() const { return 0; }
   virtual uint32_t getIndexCount() const { return 0; }
   virtual uint32_t getByteCount() const { return 0; }
   virtual uint32_t     getBufferCount( int mode = 0 ) const { return 0; }
   virtual uint64_t     getVertexCount( int mode = 0 ) const { return 0; }
   virtual uint64_t     getIndexCount( int mode = 0 ) const { return 0; }
   virtual uint64_t     getByteCount( int mode = 0 ) const { return 0; }
   virtual M4 const &   getAbsoluteTransform() const { return m_AbsoluteTransform; }
   // Gets the absolute position of the node in world coordinates.
   virtual V3           getAbsolutePosition() const
   {
      T const * const m = glm::value_ptr( m_AbsoluteTransform );
      T x = m[ 12 ];
      T y = m[ 13 ];
      T z = m[ 14 ];
      //DE_DEBUG("AbsolutePosition = (",x,",",y,",",z,")")
      return { x, y, z };
   }

   // Returns whether the node should be visible (if all of its parents are visible).
   virtual bool         isVisible() const { return m_IsVisible; }
   // Check whether the node is truly visible, taking into accounts its parents' visibility
   virtual bool         isTrulyVisible() const
   {
      if ( !m_IsVisible ) return false;
      if ( !m_Parent ) return true;
      return m_Parent->isTrulyVisible();
   }
   // Sets if the node should be visible or not.
   virtual void         setVisible( bool isVisible ){ m_IsVisible = isVisible; }
   // Get the id of the scene node.
   virtual int          getId() const { return m_Id; }
   // Sets the id of the scene node.
   virtual void         setId( int id ) { m_Id = id; }
   // Gets the scale of the scene node relative to its parent.
   virtual V3 const &   getScale() const { return m_RelativeScale; }
   // Gets the rotation of the node relative to its parent in degrees.
   virtual V3 const &   getRotation() const { return m_RelativeRotation; }
   // Gets the position of the node relative to its parent.
   virtual V3 const &   getPosition() const { return m_RelativeTranslation; }
   // Sets the relative scale of the scene node.
   virtual void         setScale( V3 const & scale )
   {
      m_RelativeScale = scale; m_IsDirty = true; updateAbsoluteTransform();
   }
   // Sets the rotation of the node relative to its parent in degrees.
   virtual void         setRotation( V3 const & rotation )
   {
      m_RelativeRotation = rotation; m_IsDirty = true; updateAbsoluteTransform();
   }
   // Sets the position of the node relative to its parent.
   virtual void         setPosition( V3 const & pos )
   {
      m_RelativeTranslation = pos; m_IsDirty = true; updateAbsoluteTransform();
   }

   // Sets the relative scale of the scene node.
   virtual void         setScale( T x, T y, T z ) { setScale( V3(x,y,z) ); }
   // Sets the relative rotation of the scene node in degrees.
   virtual void         setRotation( T x, T y, T z ) { setRotation( V3(x,y,z) ); }
   // Sets the relative position of the scene node.
   virtual void         setPosition( T x, T y, T z ) { setPosition( V3(x,y,z) ); }


   // Updates the absolute position based on the relative and the parents position
   virtual void         updateAbsoluteTransform()
   {
      if ( !m_IsDirty ) return;

      if ( m_Parent )
      {
         m_AbsoluteTransform = m_Parent->getAbsoluteTransform() * getRelativeTransform();
      }
      else
      {
         m_AbsoluteTransform = getRelativeTransform();
      }
      m_IsDirty = false;
   }

   // Returns the relative transformation of the scene node.
   virtual M4           getRelativeTransform() const
   {
      M4 t = glm::translate( M4(1), m_RelativeTranslation );
      M4 rx = glm::rotate( glm::dmat4( 1.0 ), glm::radians( m_RelativeRotation.x ), { 1., 0., 0. } );
      M4 ry = glm::rotate( glm::dmat4( 1.0 ), glm::radians( m_RelativeRotation.y ), { 0., 1., 0. } );
      M4 rz = glm::rotate( glm::dmat4( 1.0 ), glm::radians( m_RelativeRotation.z ), { 0., 0., 1. } );
      M4 r = rz * ry * rx;
      // M4 r = Quat< T >::fromEulerAngles( m_RelativeRotation ).toMat4();
      M4 s = glm::scale( M4(1), m_RelativeScale );
      M4 mat = t * r * s;
      // DE_DEBUG( getName(), ", r(",r,")")
      // DE_DEBUG( getName(), ", t(",t,")")
      // DE_DEBUG( getName(), ", s(",s,")")
      // DE_DEBUG( getName(), ", mat(",mat,")")
      return mat;
   }

   // Removes all children of this scene node
   virtual void
   removeAll()
   {
      for ( size_t i = 0; i < m_Children.size(); ++i )
      {
         ISceneNode* node = m_Children[ i ];
         if ( node )
         {
            node->setParent( nullptr );
            //delete node;
            //node->drop();
         }
      }
      m_Children.clear();
   }

   // Removes a child from this scene node.
   virtual bool
   removeChild( ISceneNode* child )
   {
      for ( size_t i = 0; i < m_Children.size(); ++i )
      {
         if ( m_Children[ i ] == child )
         {
            m_Children[ i ]->m_Parent = nullptr;
   //            m_Children[ i ]->drop();
            m_Children.erase( m_Children.begin() + i );
            return true;
         }
      }
      return false;
   }


   // Adds a child to this scene node.
   void addChild( ISceneNode* child )
   {
      if ( !child || ( child == this ) ) return;
      //child->grab();
      child->setParent( nullptr ); // remove from old parent
      m_Children.push_back( child );
      child->setParent( this );
   }

   virtual bool intersectRay( Ray3< T > const & ray,
                 glm::tvec3< T > * hitPosition = nullptr,
                 uint32_t* hitBufferIndex = nullptr,
                 uint32_t* hitTriangleIndex = nullptr,
                 Triangle3< T >* hitTriangle = nullptr ) const { return false; }

   virtual bool
   intersectRayWithBoundingBox( Ray3< T > const & ray,
                 glm::tvec3< T > * hitPosition = nullptr,
                 uint32_t* hitMeshBufferIndex = nullptr ) const { return false; }
//   std::vector< Triangle3f > const & getCollisionTriangles() const { return m_CollisionTriangles; }
//   void setCollisionTriangles( std::vector< Triangle3f > const & triangles ) { m_CollisionTriangles = triangles; }
//   void createCollisionTriangles() {}

};

} // end namespace gpu.
} // end namespace de.





#if 0
ISceneNode::ISceneNode( ISceneManager* smgr, ISceneNode* parent, int id )
   : m_SceneManager( smgr )
   , m_Parent( parent )
   , m_Id( id )
   , m_IsVisible( true )
   , m_IsDirty( true )
   , m_IsCollisionEnabled( true )
   , m_AbsoluteTransform(1)   // default ctr identity matrix.
   , m_RelativeTranslation(0,0,0)
   , m_RelativeRotation(0,0,0)
   , m_RelativeScale(1,1,1)
   , m_Children()
{
//   if ( m_SceneManager )
//   {
//      m_SceneManager->addSceneNode( this );
//   }

   if ( m_Parent )
   {
      m_Parent->addChild( this );
   }

   updateAbsoluteTransform();
}

ISceneNode::~ISceneNode()
{
   removeAll();
   // delete all animators
   // m_TriangleSelector->drop();
}


ISceneManager*
ISceneNode::getSceneManager() { return m_SceneManager; }

std::string
ISceneNode::getName() const { return m_Name; }
void
ISceneNode::setName( std::string const & name ) { m_Name = name; }

std::string
ISceneNode::toString() const
{
   std::stringstream s;
   s << getName();
   return s.str();
}

bool
ISceneNode::isCollisionEnabled() const { return m_IsCollisionEnabled; }
void
ISceneNode::setCollisionEnabled( bool enable ) { m_IsCollisionEnabled = enable; }

VisualDebugData const &
ISceneNode::getDebugData() const { return m_DebugData; }
VisualDebugData &
ISceneNode::getDebugData() { return m_DebugData; }
void
ISceneNode::setDebugData( VisualDebugData const & debugData ) { m_DebugData = debugData; }

// Get the axis aligned, transformed and animated absolute bounding box of this node.
Box3f
ISceneNode::getAbsoluteBoundingBox() const
{
   return getBoundingBox().transformBox( m_AbsoluteTransform );
}

// Get the absolute transformation of the node. Is recalculated every OnAnimate()-call.
ISceneNode::M4 const &
ISceneNode::getAbsoluteTransform() const { return m_AbsoluteTransform; }

// Gets the absolute position of the node in world coordinates.
ISceneNode::V3
ISceneNode::getAbsolutePosition() const
{
   T const * const m = glm::value_ptr( m_AbsoluteTransform );
   T x = m[ 12 ];
   T y = m[ 13 ];
   T z = m[ 14 ];
   DE_DEBUG("AbsolutePosition = (",x,",",y,",",z,")")
   return { x, y, z };
}

// Updates the absolute position based on the relative and the parents position
void
ISceneNode::updateAbsoluteTransform()
{
   if ( !m_IsDirty ) return;

   if ( m_Parent )
   {
      m_AbsoluteTransform = m_Parent->getAbsoluteTransform() * getRelativeTransform();
   }
   else
   {
      m_AbsoluteTransform = getRelativeTransform();
   }
   m_IsDirty = false;
}

// Returns the relative transformation of the scene node.
ISceneNode::M4
ISceneNode::getRelativeTransform() const
{
   M4 t = glm::translate( M4(1), m_RelativeTranslation );
   M4 rx = glm::rotate( glm::dmat4( 1.0 ), glm::radians( m_RelativeRotation.x ), { 1., 0., 0. } );
   M4 ry = glm::rotate( glm::dmat4( 1.0 ), glm::radians( m_RelativeRotation.y ), { 0., 1., 0. } );
   M4 rz = glm::rotate( glm::dmat4( 1.0 ), glm::radians( m_RelativeRotation.z ), { 0., 0., 1. } );
   M4 r = rz * ry * rx;
   // M4 r = Quat< T >::fromEulerAngles( m_RelativeRotation ).toMat4();
   M4 s = glm::scale( M4(1), m_RelativeScale );
   M4 mat = t * r * s;
   // DE_DEBUG( getName(), ", r(",r,")")
   // DE_DEBUG( getName(), ", t(",t,")")
   // DE_DEBUG( getName(), ", s(",s,")")
   // DE_DEBUG( getName(), ", mat(",mat,")")
   return mat;
}

bool
ISceneNode::isVisible() const { return m_IsVisible; }

bool
ISceneNode::isTrulyVisible() const
{
   if ( !m_IsVisible ) return false;
   if ( !m_Parent ) return true;
   return m_Parent->isTrulyVisible();
}

void
ISceneNode::setVisible( bool isVisible ) { m_IsVisible = isVisible; }

int
ISceneNode::getId() const { return m_Id; }

void
ISceneNode::setId( int id ) { m_Id = id; }

ISceneNode::V3 const &
ISceneNode::getScale() const { return m_RelativeScale; }

ISceneNode::V3 const &
ISceneNode::getRotation() const { return m_RelativeRotation; }

ISceneNode::V3 const &
ISceneNode::getPosition() const { return m_RelativeTranslation; }

void
ISceneNode::setScale( V3 const & scale )
{
   m_RelativeScale = scale;
   m_IsDirty = true;
   updateAbsoluteTransform();
}

void
ISceneNode::setRotation( V3 const & rotation )
{
   m_RelativeRotation = rotation;
   m_IsDirty = true;
   updateAbsoluteTransform();
}

void
ISceneNode::setPosition( V3 const & pos )
{
   m_RelativeTranslation = pos;
   m_IsDirty = true;
   updateAbsoluteTransform();
}

void
ISceneNode::setScale( T x, T y, T z ) { setScale( V3(x,y,z) ); }

void
ISceneNode::setRotation( T x, T y, T z ) { setRotation( V3(x,y,z) ); }

void
ISceneNode::setPosition( T x, T y, T z ) { setPosition( V3(x,y,z) ); }

//   //! Removes this scene node from the scene
//   virtual void
//   removeFromParent()
//   {
//      if ( m_Parent )
//      {
//         m_Parent->removeChild( this );
//         m_Parent = nullptr;
//      }
//   }

void
ISceneNode::removeAll()
{
   for ( size_t i = 0; i < m_Children.size(); ++i )
   {
      ISceneNode* node = m_Children[ i ];
      if ( node )
      {
         node->setParent( nullptr );
         //delete node;
         //node->drop();
      }
   }
   m_Children.clear();
}

bool
ISceneNode::removeChild( ISceneNode* child )
{
   for ( size_t i = 0; i < m_Children.size(); ++i )
   {
      if ( m_Children[ i ] == child )
      {
         m_Children[ i ]->m_Parent = nullptr;
//            m_Children[ i ]->drop();
         m_Children.erase( m_Children.begin() + i );
         return true;
      }
   }
   return false;
}


ISceneNode*
ISceneNode::getParent() const { return m_Parent; }

void
ISceneNode::setParent( ISceneNode* newParent )
{
   //grab();
   //removeFromParent();
   if ( m_Parent )
   {
      m_Parent->removeChild( this );
   }

   m_Parent = newParent;

   if (m_Parent)
   {
      m_Parent->addChild(this);
   }
   //drop();
}

std::vector< ISceneNode* > const &
ISceneNode::getChildren() const { return m_Children; }

void
ISceneNode::addChild( ISceneNode* child )
{
   if ( !child || ( child == this ) ) return;
   //child->grab();
   child->setParent( nullptr ); // remove from old parent
   m_Children.push_back( child );
   child->setParent( this );
}


#endif
