#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// =======================================================================
struct PolygonOffset
// =======================================================================
{
   PolygonOffset(  int dummy = 0  )
      : enabled( false )
      , offsetFactor( 0.0f )
      , offsetUnits( 0.0f )
   {}

   PolygonOffset( bool enable, float offFactor, float offUnits )
      : enabled( enable )
      , offsetFactor( offFactor )
      , offsetUnits( offUnits )
   {}

   bool operator==( PolygonOffset const & other ) const
   {
      if ( other.enabled != enabled ) return false;
      if ( std::abs( other.offsetFactor - offsetFactor ) > 10.0f * std::numeric_limits< float >::epsilon() ) return false;
      if ( std::abs( other.offsetUnits - offsetUnits ) > 10.0f * std::numeric_limits< float >::epsilon() ) return false;
      return true;
   }
   bool operator!=( PolygonOffset const & other ) const { return !( other == *this ); }

   std::string
   toString() const
   {
      std::ostringstream s;
      if ( enabled )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }
      s << ", offsetFactor(" << offsetFactor << ")"
         ", offsetUnits(" << offsetUnits << ")";
      return s.str();
   }

   bool enabled;       // default: false.
   float offsetFactor; // default: -1.0f.
   float offsetUnits;  // default: -2.0f.
};

} // end namespace gpu.
} // end namespace de.
