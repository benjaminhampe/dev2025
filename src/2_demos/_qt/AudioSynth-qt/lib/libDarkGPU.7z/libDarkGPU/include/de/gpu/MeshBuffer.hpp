#pragma once
#include <de/gpu/S3DVertex.hpp>
#include <de/gpu/TMeshBuffer.hpp>

namespace de {
namespace gpu {

// ===========================================================================
// Standard MeshBuffer : S3DVertex
// ===========================================================================
struct SMeshBuffer : public TMeshBuffer< S3DVertex >
{
   /// @brief Constructor
   explicit SMeshBuffer( PrimitiveType::EType primType = PrimitiveType::Triangles );
   ~SMeshBuffer() override;
   bool upload( int mode = 1 ) override;
   void destroy() override;
   void draw( int mode = 0 ) override;
};

} // end namespace gpu.
} // end namespace de.



//   bool
//   load( std::string uri )
//   {
//      return false;
//   }

//   bool
//   save( std::string uri ) const
//   {
//      std::stringstream s;
//      s << "Saved Benni Mesh\n";
//      s << "fileName: " << m_Name << "\n";
//      s << "bufferCount: " << m_MeshBuffers << "\n";

//      for ( size_t i = 0; i < m_MeshBuffers.size(); ++i )
//      {
//         SMeshBuffer const * const p = m_MeshBuffers[ i ];
//         if ( !p ) continue;
//         s << "buffer[" << i << "] " << p->getName() << "\n";

//         for ( size_t v = 0; v < m_MeshBuffers.Vertsize(); ++i )
//         {
//            SMeshBuffer const * const p = m_MeshBuffers[ i ];
//            if ( !p ) continue;
//            s << "buffer[" << i << "] " << p->getName() << "\n";

//            p->Material.wireframe = enable;
//         }

//         p->Material.wireframe = enable;
//      }

//      s << "[material-count] " << m_MeshBuffers << "\n";
//      s << " )";
//      return false;
//   }
