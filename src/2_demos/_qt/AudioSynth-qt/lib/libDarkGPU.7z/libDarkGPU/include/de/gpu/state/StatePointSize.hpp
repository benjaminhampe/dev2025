#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// =======================================================================
struct PointSize
// =======================================================================
{
   PointSize( int dummy = 0 ) : m_Now( 0 ), m_Min( 0 ), m_Max( 0 ) {}
   bool isValid() const {
      if ( std::abs( m_Max - m_Min ) <= std::numeric_limits< float >::epsilon() ) return false;
      return true;
   }

   bool operator==( PointSize const & other ) const
   {
      if ( std::abs( other.m_Now - m_Now ) > std::numeric_limits< float >::epsilon() ) return false;
      //if ( std::abs( other.m_Min - m_Min ) > std::numeric_limits< float >::epsilon() ) return false;
      //if ( std::abs( other.m_Max - m_Max ) > std::numeric_limits< float >::epsilon() ) return false;
      return true;
   }

   bool operator!=( PointSize const & other ) const { return !( other == *this ); }

   std::string
   toString() const
   {
      std::ostringstream s;
      s << "current(" << m_Now << "), min(" << m_Min << "), max(" << m_Max << ")";
      return s.str();
   }

   float m_Now;
   float m_Min;
   float m_Max;
};

} // end namespace gpu.
} // end namespace de.
