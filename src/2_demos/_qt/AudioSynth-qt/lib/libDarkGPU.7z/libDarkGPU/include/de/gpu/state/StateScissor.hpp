#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
struct Scissor
// ===========================================================================
{
   Scissor( bool enable = false )
      : enabled( enable ), x(0), y(0), w(0), h(0)
   {}

   bool isValid() const { return w > 0 && h > 0; }

   bool operator==( Scissor const & o ) const
   {
      return ( o.enabled == enabled &&
               o.x == x &&
               o.y == y &&
               o.w == w &&
               o.h == h );
   }
   bool operator!=( Scissor const & o ) const { return !( o == *this ); }


   std::string
   toString() const
   {
      std::stringstream s;
      if ( enabled )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }
      s << ", x:" << x << ", y:" << y << ", w:" << w << ", h:" << h;
      return s.str();
   }

   bool enabled;
   int32_t x, y, w, h;
};

} // end namespace gpu.
} // end namespace de.
