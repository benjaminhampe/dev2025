#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// ===========================================================================
struct RasterizerDiscard
// ===========================================================================
{
   // RasterizerDiscard, this stuff is never than TnL
   // A special index indicates the restart of a trianglestrip.
   // always max index is used as special marker index.
   // Needs ofcourse an index buffer.
   // Which is a negative point for cache locatity due to another indirection layer.
   // Use with caution i would say. Available at versions greater OpenGL ES 3.0
   RasterizerDiscard( bool enable = false ) : enabled( enable ) {}
   bool operator==( RasterizerDiscard const & other ) const { return other.enabled == enabled; }
   bool operator!=( RasterizerDiscard const & o ) const { return !( o == *this ); }

   std::string
   toString() const
   {
      std::stringstream s;
      if ( enabled )
      {
         s << "ON";
      }
      else
      {
         s << "OFF";
      }
      return s.str();
   }

   bool enabled;
};

} // end namespace gpu.
} // end namespace de.
