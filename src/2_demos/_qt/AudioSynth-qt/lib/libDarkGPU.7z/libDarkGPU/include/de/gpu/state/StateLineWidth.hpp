#pragma once
#include "StateCommon.hpp"

namespace de {
namespace gpu {

// =======================================================================
struct LineWidth
// =======================================================================
{
   LineWidth( int dummy = 0 ) : m_Now( 1.0f ), m_Min( 1.0f ), m_Max( 100.0f ) {}

   bool isValid() const
   {
      if ( std::abs( m_Max - m_Min ) <= std::numeric_limits< float >::epsilon() ) return false;
      return true;
   }

   bool operator==( LineWidth const & other ) const
   {
      if ( std::abs( other.m_Now - m_Now ) > 10.0f * std::numeric_limits< float >::epsilon() ) return false;
      //if ( std::abs( other.m_Min - m_Min ) > 10.0f * std::numeric_limits< float >::epsilon() ) return false;
      //if ( std::abs( other.m_Max - m_Max ) > 10.0f * std::numeric_limits< float >::epsilon() ) return false;
      return true;
   }

   bool operator!=( LineWidth const & other ) const { return !( other == *this ); }

   std::string
   toString() const
   {
      std::ostringstream s;
      s << "current(" << m_Now << "), min(" << m_Min << "), max(" << m_Max << ")";
      return s.str();
   }

   float m_Now;
   float m_Min;
   float m_Max;
};

} // end namespace gpu.
} // end namespace de.
