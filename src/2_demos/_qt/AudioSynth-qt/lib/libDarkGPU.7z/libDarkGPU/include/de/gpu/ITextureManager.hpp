#pragma once
#include <de/gpu/ITexture.hpp>

namespace de {
namespace gpu {

// ===========================================================================
struct ITexManager
// ===========================================================================
{
   typedef std::string S;

   virtual ~ITexManager() = default;

// ###   TexUnitManager    ###
   virtual uint32_t getUnitCount() const = 0;
   virtual int32_t findUnit( uint32_t texId ) const = 0;

// ###   TexManager   ###
   virtual void init() = 0;
   virtual void dump() = 0;

   virtual TexRef getTexture2D( S const & name, SO const & so = SO(), bool keepImage = false ) = 0;
   virtual TexRef createTexture2D( S const & name, Image const & img, SO so = SO(), bool keepImage = false ) = 0;
   virtual bool has( S const & name ) const = 0;
   virtual Tex* findTexture( S const & name ) const = 0;
   virtual bool upload( Tex* tex, Image const & src ) = 0;
   virtual void clearTextures() = 0;
   virtual void updateTextures() = 0;
   virtual void removeTexture( Tex* tex ) = 0;
   virtual void removeTexture( S const & key ) = 0;
   // ###   OpenGL raw uint    ###
   virtual bool bindTexture2D( int stage, uint32_t texId ) = 0;
   virtual bool unbindTexture2D( uint32_t texId ) = 0;
   // AutoSelect a free tex unit and return its index for use in setSamplerUniform().
   virtual int bindTexture2D( uint32_t texId ) = 0;
   // ###   hl class Tex    ###
   virtual bool bindTexture( int stage, Tex* tex ) = 0; // call for high level class Tex
   virtual bool unbindTexture( Tex* tex ) = 0; // call for high level class Tex
   virtual int bindTexture( Tex* tex ) = 0;    // call for high level class Tex with more intelligence.

//   inline TexRef load2D( S const & uri, bool keepImage = true, SO so = SO() )
//   {
//      return load2D( uri, uri, keepImage, so );
//   }
//   inline TexRef add2D( Image const & img, bool keepImage = true, SO so = SO() )
//   {
//      return add2D( img.getUri(), img, keepImage, so );
//   }

};

} // end namespace gpu.
} // end namespace de.
