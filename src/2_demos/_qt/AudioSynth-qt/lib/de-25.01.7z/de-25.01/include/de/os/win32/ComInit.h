#pragma once

struct ComInit // Initialized from MainApp or MainWindow
{
   ComInit();
   ~ComInit();
};
