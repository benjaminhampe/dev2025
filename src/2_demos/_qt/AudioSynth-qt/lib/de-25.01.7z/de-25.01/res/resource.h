#pragma once

#define ID_ICON_DE_WIN1     101
//#define bbbb              102
//#define cccc              103

/*
#define IDR_MAINMENU        102
#define IDR_ACCELERATOR     103
#define IDD_ABOUTDIALOG     104
#define ID_FILE_EXIT        40001
#define ID_HELP_ABOUT       40002
*/

#ifndef IDC_STATIC
#define IDC_STATIC                   -1
#endif

  // ID für das Eingabefeld
  // ID für die OK-Schaltfläche
  // ID für die Abbrechen-Schaltfläche
#define PROMDLG_IDD         42001
#define PROMDLG_ID_EDIT     42002
#define PROMDLG_ID_OK       42003
#define PROMDLG_ID_CANCEL   42004

