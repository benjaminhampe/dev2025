//
// Created by Paul Walker on 12/19/21.
//

#include <juce_audio_plugin_client/CLAP/clap-juce-extensions.h>

namespace clap_juce_extensions
{
bool clap_properties::building_clap{false};
uint32_t clap_properties::clap_version_major{0}, clap_properties::clap_version_minor{0},
    clap_properties::clap_version_revision{0};

clap_properties::clap_properties() : is_clap{building_clap} {}

const clap_host* clap_juce_audio_processor_capabilities::clapHostStatic{nullptr};
} // namespace clap_juce_extensions