/* This is just debugging sandbox. */
#include "wav_common.c"

int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;

    return 0;
}
